﻿/*
 * All code (c)2012 Jay Basen all rights reserved
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.CrestronThread;										// For Threading

namespace Crestron_Shade_Automation_Manager
{
	public class gateway
	{
		#region Declarations
		private Object ThreadLock = new object();
		public string name;
		public string id;
		private Ethernet_CEN_RFGW_EX gw;
		#endregion

		#region Methods
		//****************************************************************************************
		// 
		//  gateway	-	constructor for ex gateway
		// 
		//****************************************************************************************
		public gateway(Ethernet_CEN_RFGW_EX gw, string name)
		{
			lock (ThreadLock)
			{
				this.gw = gw;													//save the link to the gateway
				this.id = "Ethernet" + gw.ID.ToString("x2");					//create id string for match with shade xml data
				this.id = this.id.ToLower();									//make all lower case for string comparison
				this.name = name;
			}
		}
		//****************************************************************************************
		// 
		//  get_gateway	-	returns the ex gateway
		// 
		//****************************************************************************************
		public Ethernet_CEN_RFGW_EX get_gateway()
		{
			lock (ThreadLock)
			{
				return gw;
			}
		}
		#endregion
	}
}