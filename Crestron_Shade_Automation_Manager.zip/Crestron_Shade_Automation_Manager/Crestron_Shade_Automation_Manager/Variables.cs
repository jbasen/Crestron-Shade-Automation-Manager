﻿/*
 * All code (c)2012 Jay Basen all rights reserved
 */
using System;
using System.Collections.Generic;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.CrestronLogger;
using Crestron_Shade_Automation_Manager;

namespace Shade_Automation_Manager
{
	class Variables
	{
		#region Declarations
		private static Object ThreadLock = new object();
		private static bool party_flag = false;									//true when a party is going on and automated events are disabled
		public static bool cloudy = false;										//true if cloudy outside, otherwise false
		public static bool away_flag = false;									//true if alarm set in away mode
		public static bool vacation_flag = false;								//true if homeowners are away
		public static room[] room_data;											//the collection of all rooms
		public static shade[] shade_data;										//the collection of all shades
		public static gateway[] gateway_data;									//the collection of all gateways
		public static Cresnet_C2N_SDC[] c2n_sdc;								//the collection of all shade hardwre
		public static Cresnet_C2N_SDC_DC[] c2n_sdc_dc;							//the collection of all shade hardwre
		public static Cresnet_CSM_QMT50_DCCN[] csm_qmt50_dccn;					//the collection of all shade hardwre
		public static RF_CSC_ACEX[] csc_acex;									//the collection of all shade hardware
		public static RF_CSC_DCEX[] csc_dcex;									//the collection of all shade hardware
		public static RF_CSC_DRPEX[] csc_drpex;									//the collection of all drape hardware
		public static Cresnet_CSC_ACCN[] csc_accn;								//the collection of all shade hardware
		public static Cresnet_CSC_DCCN[] csc_dccn;								//the collection of all shade hardware
		public static Cresnet_CSC_DRPCN[] csc_drpcn;							//the collection of all drape hardware
		public static shade_interface[] shade_hw;								//the collection of all shade interfaces
		public static List<timer_data> timer_list;								//list of timers to keep references alive and to 

		public static int default_room_setpoint = 70;
		public static int default_room_temperature = 70;
		public static double feet_into_room_for_glare = 3;						//glare if sun shining more than 3 feet into room
		public static double glare_azimuth = 60;								//glare if sun shining on an angle +/- this value
		public static double magnetic_declination_degrees = 16;					//difference between magnetic north and true north
		public static group_preference preference;								//preference for groups when shades in conflict
		public static Ethernet_Intersystem_Communications EISC_TO_SIMPL;			//EISC to Simplwin program
		
		//constants
		#endregion

		#region Methods
		//****************************************************************************************
		// 
		//  Set_Party_Flag	-	Sets the flag that there is a party going on
		// 
		//****************************************************************************************
		public static void Set_Party_Flag()
		{
			lock (ThreadLock)
			{
				party_flag = true;
			}
		}

		//****************************************************************************************
		// 
		//  Clear_Party_Flag	-	Clears the party flag and restores automated operation
		// 
		//****************************************************************************************
		public static void Clear_Party_Flag()
		{
			lock (ThreadLock)
			{
				party_flag = false;
			}
		}

		//****************************************************************************************
		// 
		//  Get_Party_Flag	-	returns the current state of the party flag for a room
		// 
		//****************************************************************************************
		public static bool Get_Party_Flag(room rm)
		{
			lock (ThreadLock)
			{
				if (rm.ignore_party_flag == true)
				{
					return false;
				}
				else
				{
					return party_flag;
				}
			}
		}

		//****************************************************************************************
		// 
		//  Set_Away_Flag	-	Sets the flag that there is a away going on
		// 
		//****************************************************************************************
		public static void Set_Away_Flag()
		{
			lock (ThreadLock)
			{
				away_flag = true;
			}
		}

		//****************************************************************************************
		// 
		//  Clear_Away_Flag	-	Clears the away flag and restores automated operation
		// 
		//****************************************************************************************
		public static void Clear_Away_Flag()
		{
			lock (ThreadLock)
			{
				away_flag = false;
			}
		}

		//****************************************************************************************
		// 
		//  Get_Away_Flag	-	returns the current state of the away flag for a room
		// 
		//****************************************************************************************
		public static bool Get_Away_Flag()
		{
			lock (ThreadLock)
			{
				return away_flag;
			}
		}

		//****************************************************************************************
		// 
		//  Set_Vacation_Flag	-	Sets the flag that there is a away going on
		// 
		//****************************************************************************************
		public static void Set_Vacation_Flag()
		{
			lock (ThreadLock)
			{
				vacation_flag = true;
			}
		}

		//****************************************************************************************
		// 
		//  Clear_Vacation_Flag	-	Clears the away flag and restores automated operation
		// 
		//****************************************************************************************
		public static void Clear_Vacation_Flag()
		{
			lock (ThreadLock)
			{
				vacation_flag = false;
			}
		}

		//****************************************************************************************
		// 
		//  Get_Vacation_Flag	-	returns the current state of the away flag for a room
		// 
		//****************************************************************************************
		public static bool Get_Vacation_Flag()
		{
			lock (ThreadLock)
			{
				return vacation_flag;
			}
		}
		//****************************************************************************************
		// 
		//  To_Option	-	converts a string to an option
		// 
		//****************************************************************************************
		public static options To_Option(string s)
		{
			string s1 = s.ToLower();

			if (s1 == "none")
			{
				return (options.none);
			}
			else if (s1 == "energy-save-optimal")
			{
				return (options.energy_save_optimal);
			}
			else if (s1 == "energy-save-aesthetics")
			{
				return (options.energy_save_aesthetics);
			}
			else if (s1 == "art-save-optimal")
			{
				return (options.art_save_optimal);
			}
			else if (s1 == "art-save-aesthetics")
			{
				return (options.energy_save_aesthetics);
			}
			else
			{
				Crestron.SimplSharp.ErrorLog.Error("To_Option:Invalid shade option - " + s + "\n\r");
				CrestronLogger.WriteToLog("To_Option:Invalid shade option - " + s + "\n\r", 0);
				return (options.none);
			}
		}

		//****************************************************************************************
		// 
		//  To_Action	-	converts a string to an action
		// 
		//****************************************************************************************
		public static actions To_Action(string s)
		{
			string s1 = s.ToLower();

			if (s1 == "none")
			{
				return (actions.none);
			}
			else if (s1 == "open")
			{
				return (actions.sun_open_full);
			}
			else if (s1 == "close")
			{
				return (actions.sun_close_full);
			}
			else if (s1 == "sun_open_full")
			{
				return (actions.sun_open_full);
			}
			else if (s1 == "sun_close_full")
			{
				return (actions.sun_close_full);
			}
			else if (s1 == "schedule_open_full")
			{
				return (actions.schedule_open_full);
			}
			else if (s1 == "schedule_close_full")
			{
				return (actions.schedule_close_full);
			}
			else if (s1 == "schedule_unlock")
			{
				return (actions.schedule_unlock);
			}
			else if (s1 == "manual_open_full")
			{
				return (actions.manual_open_full);
			}
			else if (s1 == "manual_close_full")
			{
				return (actions.manual_close_full);
			}
			else if (s1 == "manual_open")
			{
				return (actions.manual_open);
			}
			else if (s1 == "manual_close")
			{
				return (actions.manual_close);
			}
			else if (s1 == "manual_stop")
			{
				return (actions.manual_stop);
			}
			else if (s1 == "manual_unlock")
			{
				return (actions.manual_unlock);
			}
			else
			{
				Crestron.SimplSharp.ErrorLog.Error("To_Action:Invalid shade action - " + s + "\n\r");
				CrestronLogger.WriteToLog("To_Action:Invalid shade action - " + s + "\n\r", 0);
				return (actions.none);
			}
		}

		//****************************************************************************************
		// 
		//  Int_To_Mode	-	converts integer value to mode
		// 
		//****************************************************************************************
		public static modes Int_To_Mode(int i)
		{
			switch (i)										//translate join value to mode
			{
				case (1):
					return modes.heat;

				case (2):
					return modes.cool;

				case (3):
					return modes.auto;

				case (0):
					return modes.off;

				default:
					Crestron.SimplSharp.ErrorLog.Error("Int_To_Mode: invalid mode - " + i + "\n\r");
					CrestronLogger.WriteToLog("Int_To_Mode: invalid mode - " + i + "\n\r", 0);
					return modes.heat;
			}
		}

		//****************************************************************************************
		// 
		//  Int_To_Mode	-	converts integer value to mode
		// 
		//****************************************************************************************
		public static modes Int_To_Mode(uint i)
		{
			switch (i)										//translate join value to mode
			{
				case (1):
					return modes.heat;

				case (2):
					return modes.cool;

				case (3):
					return modes.auto;

				case (0):
					return modes.off;

				default:
					Crestron.SimplSharp.ErrorLog.Error("Int_To_Mode: invalid mode - " + i + "\n\r");
					CrestronLogger.WriteToLog("Int_To_Mode: invalid mode - " + i + "\n\r", 0);
					return modes.heat;
			}
		}

		//****************************************************************************************
		// 
		//  To_Group_Preference	-	converts string to group preference
		// 
		//****************************************************************************************
		public static group_preference To_Group_Preference(string s)
		{
			string s1 = s.ToLower();

			if (s1 == "all open")
			{
				return (group_preference.all_open);
			}
			else if (s1 == "all close")
			{
				return (group_preference.all_close);
			}
			else
			{
				Crestron.SimplSharp.ErrorLog.Error("To_Action:Invalid group preference - " + s + "\n\r");
				CrestronLogger.WriteToLog("To_Action:Invalid group preference - " + s + "\n\r", 0);
				return (group_preference.all_close);
			}
		}

		//****************************************************************************************
		// 
		//  Add_Console_Commands	-	Registers console commands for debugging
		// 
		//****************************************************************************************
		public static void Add_Console_Commands()
		{
			//Console Command Setup
			if (CrestronConsole.AddNewConsoleCommand(new SimplSharpProConsoleCmdFunction(ShadeShowShades), "ShadeShowShades",
				"prints the shades to the console or log - ShadeShowShades log|console", ConsoleAccessLevelEnum.AccessOperator) == false)
			{
				CrestronLogger.WriteToLog(string.Format("Shade_Automation_Manager-Console Command Setup: error creating ShadeShowShades\n\r"), 0);
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Shade_Automation_Manager-Console Command Setup: error creating ShadeShowShades\n\r"));
			}

			if (CrestronConsole.AddNewConsoleCommand(new SimplSharpProConsoleCmdFunction(ShadeShowTimers), "ShadeShowTimers",
				"Prints the timers to the console or log - ShadeShowTimers log|console", ConsoleAccessLevelEnum.AccessOperator) == false)
			{
				CrestronLogger.WriteToLog(string.Format("Shade_Automation_Manager-Console Command Setup: error creating ShadeShowTimers\n\r"), 0);
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Shade_Automation_Manager-Console Command Setup: error creating ShadeShowTimers\n\r"));
			}

			if (CrestronConsole.AddNewConsoleCommand(new SimplSharpProConsoleCmdFunction(ShadeShowHw), "ShadeShowHW",
				"Prints the hardware to the console or log - ShadeShowHW log|console", ConsoleAccessLevelEnum.AccessOperator) == false)
			{
				CrestronLogger.WriteToLog(string.Format("Shade_Automation_Manager-Console Command Setup: error creating ShadeShowHW\n\r"), 0);
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Shade_Automation_Manager-Console Command Setup: error creating ShadeShowHW\n\r"));
			}

			if (CrestronConsole.AddNewConsoleCommand(new SimplSharpProConsoleCmdFunction(ShadeShowGroups), "ShadeShowGroups",
				"Prints the shade groups to the console or log - ShadeShowGroups log|console", ConsoleAccessLevelEnum.AccessOperator) == false)
			{
				CrestronLogger.WriteToLog(string.Format("Shade_Automation_Manager-Console Command Setup: error creating ShadeShowHW\n\r"), 0);
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Shade_Automation_Manager-Console Command Setup: error creating ShadeShowHW\n\r"));
			}
		}

		//****************************************************************************************
		// 
		//  ShadeShowShades	-	Handler for console command
		// 
		//****************************************************************************************
		public static void ShadeShowShades(string CommandPrameters)
		{
			string s = CommandPrameters.ToLower();

			if (s == "log")
			{
				foreach (room rm in Variables.room_data)
				{
					CrestronLogger.WriteToLog("name = " + rm.name + "\n\r", 0);
					CrestronLogger.WriteToLog("note = " + rm.note + "\n\r", 0);
					CrestronLogger.WriteToLog("ignore_party_flag = " + rm.ignore_party_flag + "\n\r\n\r", 0);
					CrestronLogger.WriteToLog("close_when_away = " + rm.close_when_away + "\n\r\n\r", 0);

					rm.shade_list.ForEach(delegate(shade sh)
					{
						CrestronLogger.WriteToLog("name = " + sh.name + "\n\r", 0);
						CrestronLogger.WriteToLog("note = " + sh.note + "\n\r", 0);
						CrestronLogger.WriteToLog("east_horizon = " + sh.east_horizon + "\n\r", 0);
						CrestronLogger.WriteToLog("west_horizon = " + sh.west_horizon + "\n\r", 0);
						CrestronLogger.WriteToLog("angle_from_north = " + sh.angle_from_north + "\n\r", 0);
						CrestronLogger.WriteToLog("eave_height = " + sh.eave_height + "\n\r", 0);
						CrestronLogger.WriteToLog("eave_depth = " + sh.eave_depth + "\n\r", 0);
						CrestronLogger.WriteToLog("max_eave_depth_low = " + sh.max_eave_depth_low + "\n\r", 0);
						CrestronLogger.WriteToLog("max_eave_depth_high = " + sh.max_eave_depth_high + "\n\r", 0);
						CrestronLogger.WriteToLog("height_floor_to_sill = " + sh.height_floor_to_sill + "\n\r", 0);
						CrestronLogger.WriteToLog("window_height = " + sh.window_height + "\n\r", 0);
						CrestronLogger.WriteToLog("option = " + sh.option + "\n\r", 0);
						CrestronLogger.WriteToLog("timed_action = " + sh.timed_actions + "\n\r", 0);
						CrestronLogger.WriteToLog("sunrise_action = " + sh.sunrise_action + "\n\r", 0);
						CrestronLogger.WriteToLog("sunset_action = " + sh.sunset_action + "\n\r", 0);
						CrestronLogger.WriteToLog("close_on_glare = " + sh.close_on_glare + "\n\r", 0);
						CrestronLogger.WriteToLog("serial_join = " + sh.serial_join + "\n\r", 0);
						CrestronLogger.WriteToLog("analog_join = " + sh.analog_join + "\n\r", 0);
						CrestronLogger.WriteToLog("group_name = " + sh.group_name + "\n\r", 0);
						CrestronLogger.WriteToLog("hardware_address = " + sh.hardware_address + "\n\r\n\r", 0);
					});
				}
			}
			else if (s == "console")
			{
				foreach (room rm in Variables.room_data)
				{
					CrestronConsole.ConsoleCommandResponse("name = " + rm.name + "\n\r");
					CrestronConsole.ConsoleCommandResponse("note = " + rm.note + "\n\r");
					CrestronConsole.ConsoleCommandResponse("ignore_party_flag = " + rm.ignore_party_flag + "\n\r");
					CrestronConsole.ConsoleCommandResponse("close_when_away = " + rm.close_when_away + "\n\r\n\r");

					rm.shade_list.ForEach(delegate(shade sh)
					{
						CrestronConsole.ConsoleCommandResponse("name = " + sh.name + "\n\r");
						CrestronConsole.ConsoleCommandResponse("note = " + sh.note + "\n\r");
						CrestronConsole.ConsoleCommandResponse("east_horizon = " + sh.east_horizon + "\n\r");
						CrestronConsole.ConsoleCommandResponse("west_horizon = " + sh.west_horizon + "\n\r");
						CrestronConsole.ConsoleCommandResponse("angle_from_north = " + sh.angle_from_north + "\n\r");
						CrestronConsole.ConsoleCommandResponse("eave_height = " + sh.eave_height + "\n\r");
						CrestronConsole.ConsoleCommandResponse("eave_depth = " + sh.eave_depth + "\n\r");
						CrestronConsole.ConsoleCommandResponse("max_eave_depth_low = " + sh.max_eave_depth_low + "\n\r");
						CrestronConsole.ConsoleCommandResponse("max_eave_depth_high = " + sh.max_eave_depth_high + "\n\r");
						CrestronConsole.ConsoleCommandResponse("height_floor_to_sill = " + sh.height_floor_to_sill + "\n\r");
						CrestronConsole.ConsoleCommandResponse("window_height = " + sh.window_height + "\n\r");
						CrestronConsole.ConsoleCommandResponse("option = " + sh.option + "\n\r");
						CrestronConsole.ConsoleCommandResponse("timed_action = " + sh.timed_actions + "\n\r");
						CrestronConsole.ConsoleCommandResponse("sunrise_action = " + sh.sunrise_action + "\n\r");
						CrestronConsole.ConsoleCommandResponse("sunset_action = " + sh.sunset_action + "\n\r");
						CrestronConsole.ConsoleCommandResponse("close_on_glare = " + sh.close_on_glare + "\n\r");
						CrestronConsole.ConsoleCommandResponse("serial_join = " + sh.serial_join + "\n\r");
						CrestronConsole.ConsoleCommandResponse("analog_join = " + sh.analog_join + "\n\r");
						CrestronConsole.ConsoleCommandResponse("group_name = " + sh.group_name + "\n\r");
						CrestronConsole.ConsoleCommandResponse("hardware_address = " + sh.hardware_address + "\n\r\n\r");
					});
				}
			}
			else
			{
				CrestronConsole.ConsoleCommandResponse("ShadeShowShades - illegal parameter " + CommandPrameters + "\n\r");
				CrestronConsole.ConsoleCommandResponse("ShadeShadeShades - proper form is: ShadeShowShades log|console\n\r");
			}
		}

		//****************************************************************************************
		// 
		//  ShadeShowTimers	-	Handler for console command
		// 
		//****************************************************************************************
		public static void ShadeShowTimers(string CommandPrameters)
		{
			string s = CommandPrameters.ToLower();

			if (s == "log")
			{
				CrestronLogger.WriteToLog("\n\rTimer List\n\r\n\r", 0);

				timer_list.ForEach(delegate(timer_data t)
				{
					CrestronLogger.WriteToLog("\n\rshade name: " + t.Get_Timer_Shade().name + "\n\r", 0);
					CrestronLogger.WriteToLog("action: " + t.Get_Timer_Action() + "\n\r", 0);
					CrestronLogger.WriteToLog("Time: " + t.Get_Expiration_Hour().ToString("G2") + ":" + t.Get_Expiration_Minute().ToString("G2") + "\n\r\n\r", 0);
				});
			}
			else if (s == "console")
			{
				CrestronConsole.ConsoleCommandResponse("\n\rTimer List\n\r\n\r");

				timer_list.ForEach(delegate(timer_data t)
				{
					CrestronConsole.ConsoleCommandResponse("\n\rshade name: " + t.Get_Timer_Shade().name + "\n\r");
					CrestronConsole.ConsoleCommandResponse("action: " + t.Get_Timer_Action() + "\n\r");
					CrestronConsole.ConsoleCommandResponse("Time: " + t.Get_Expiration_Hour().ToString("G2") + ":" + t.Get_Expiration_Minute().ToString("G2") + "\n\r\n\r");
				});
			}
			else
			{
				CrestronConsole.ConsoleCommandResponse("ShadeShowTimers - illegal parameter " + CommandPrameters + "\n\r");
				CrestronConsole.ConsoleCommandResponse("ShadeShowTimers - proper form is: ShadeShowTimers log|console\n\r");
			}
		}

		//****************************************************************************************
		// 
		//  ShadeShowHw	-	Handler for console command
		// 
		//****************************************************************************************
		public static void ShadeShowHw(string CommandPrameters)
		{
			string s = CommandPrameters.ToLower();

			if (s == "log")
			{
				CrestronLogger.WriteToLog("\n\rShade Hardware\n\r\n\r", 0);

				foreach (Cresnet_C2N_SDC s1 in Variables.c2n_sdc)
				{
					CrestronLogger.WriteToLog("\n\rc2n_sdc: id= " + s1.ID.ToString("x2") + "\n\r", 0);
				}

				foreach (Cresnet_C2N_SDC_DC s1 in Variables.c2n_sdc_dc)
				{
					CrestronLogger.WriteToLog("\n\rc2n_sdc_dc: id= " + s1.ID.ToString("x2") + "\n\r", 0);
				}

				foreach (shade_interface i in Variables.shade_hw)
				{
					CrestronLogger.WriteToLog("\n\rshade_interface: id = " + i.id + "\n\r", 0);
					CrestronLogger.WriteToLog("shade_interface: shade = " + i.shade.name + "\n\r", 0);
				}
			}
			else if (s == "console")
			{
				CrestronConsole.ConsoleCommandResponse("\n\rShade Hardware\n\r\n\r");

				foreach (Cresnet_C2N_SDC s1 in Variables.c2n_sdc)
				{
					CrestronConsole.ConsoleCommandResponse("\n\rc2n_sdc: id= " + s1.ID.ToString("x2") + "\n\r");
				}

				foreach (shade_interface i in Variables.shade_hw)
				{
					CrestronConsole.ConsoleCommandResponse("\n\rshade_interface: id = " + i.id + "\n\r");
					CrestronConsole.ConsoleCommandResponse("shade_interface: shade = " + i.shade.name + "\n\r");
				}
			}
			else
			{
				CrestronConsole.ConsoleCommandResponse("ShadeShowHw - illegal parameter " + CommandPrameters + "\n\r");
				CrestronConsole.ConsoleCommandResponse("ShadeShowHw - proper form is: ShadeShowHw log|console\n\r");
			}
		}

		//****************************************************************************************
		// 
		//  ShadeShowGroups	-	Handler for console command
		// 
		//****************************************************************************************
		public static void ShadeShowGroups(string CommandPrameters)
		{
			string s = CommandPrameters.ToLower();

			if (s == "log")
			{
				CrestronLogger.WriteToLog("\n\rShade Groups\n\r\n\r", 0);

				Shade_Group.shade_group_list.ForEach(delegate(Shade_Group grp)	//walk through each group
				{
					CrestronLogger.WriteToLog("Group: " + grp.name + "\n\r", 0);
					grp.shade_list.ForEach(delegate(shade sh)					//walk through each shade in the group
					{
						CrestronLogger.WriteToLog("Shade: " + sh.name + "\n\r", 0);
					});
					CrestronLogger.WriteToLog("\n\r", 0);						//extra line after each group
				});
			}
			else if (s == "console")
			{
				CrestronConsole.ConsoleCommandResponse("\n\rShade Groups\n\r\n\r");

				Shade_Group.shade_group_list.ForEach(delegate(Shade_Group grp)	//walk through each group
				{
					CrestronConsole.ConsoleCommandResponse("Group: " + grp.name + "\n\r");

					grp.shade_list.ForEach(delegate(shade sh)					//walk through each shade in the group
					{
						CrestronConsole.ConsoleCommandResponse("Shade: " + sh.name + "\n\r");
					});
					CrestronConsole.ConsoleCommandResponse("\n\r");				//extra line after each group
				});


			}
			else
			{
				CrestronConsole.ConsoleCommandResponse("ShadesShowGroups - illegal parameter " + CommandPrameters + "\n\r");
				CrestronConsole.ConsoleCommandResponse("ShadesShowGroups - proper form is: ShadesShowGroups log|console\n\r");
			}
		}

		//****************************************************************************************
		// 
		//  true_north_to_magnetic_north	-	Convert true north to magnetic north
		// 
		//****************************************************************************************
		public static double true_north_to_magnetic_north(double true_north)
		{
			true_north -= Variables.magnetic_declination_degrees;

			if (true_north < 0)
			{
				true_north += 360;
			}
			else if (true_north >= 360)
			{
				true_north -= 360;
			}
			return true_north;
		}

		//****************************************************************************************
		// 
		//  EISC_Serial_Output	-	Sets the serial output to the specified string
		// 
		//****************************************************************************************
		public static void EISC_Serial_Output(uint join, string s)
		{
			try
			{
				if (EISC_TO_SIMPL.IsOnline == true)								//make sure EISC is online 
				{
					EISC_TO_SIMPL.SerialInput[join] = s;							//output string to the EISC
				}
			}
			catch (Exception e)													//manage errors
			{
				Crestron.SimplSharp.ErrorLog.Error(string.Format("EISC_Serial_Output: " + e + "\n\r"));
				CrestronLogger.WriteToLog("EISC_Serial_Output: " + e + "\n\r", 0);
			}
		}

		//****************************************************************************************
		// 
		//  EISC_Analog_Output	-	Sets the analog output to the specified string
		// 
		//****************************************************************************************
		public static void EISC_Analog_Output(uint join, ushort value)
		{
			try
			{
				if (EISC_TO_SIMPL.IsOnline == true)								//make sure EISC is online 
				{
					EISC_TO_SIMPL.AnalogInput[join] = value;						//output string to the EISC
				}
			}
			catch (Exception e)													//manage errors
			{
				Crestron.SimplSharp.ErrorLog.Error(string.Format("EISC_Serial_Output: " + e + "\n\r"));
				CrestronLogger.WriteToLog("EISC_Serial_Output: " + e + "\n\r", 0);
			}
		}
	
		#endregion
	}
}