﻿/*
 * All code (c)2012 Jay Basen all rights reserved
 */
using System;
using System.Collections.Generic;
using System.Text;
using Crestron.SimplSharp;

namespace Shade_Automation_Manager
{
	public class timer_data														//data passed to a timer
	{
		#region Declarations
		private shade sh;														//the shade the timer should act on
		private actions act;													//what action should be taken
		private int expiration_hour;											//hour when timer expires				
		private int expiration_minute;											//minute when timer expires
		#endregion

		#region Methods
		//****************************************************************************************
		// 
		//  timer_data	-	constuctor
		// 
		//****************************************************************************************
		public timer_data(shade Sh, actions Act, int Hour, int Minute)			//constructor
		{
			this.sh = Sh;
			this.act = Act;
			this.expiration_hour = Hour;
			this.expiration_minute = Minute;
		}

		//****************************************************************************************
		// 
		//  Get_Timer_Shade	-	returns shade
		// 
		//****************************************************************************************
		public shade Get_Timer_Shade()
		{
			return sh;
		}

		//****************************************************************************************
		// 
		//  Get_Timer_Action	-	returns action
		// 
		//****************************************************************************************
		public actions Get_Timer_Action()
		{
			return act;
		}

		//****************************************************************************************
		// 
		//  Get_Expiration_Hour	-	returns expiration hour
		// 
		//****************************************************************************************
		public int Get_Expiration_Hour()
		{
			return expiration_hour;
		}

		//****************************************************************************************
		// 
		//  Get_Expiration_Minute	-	returns expration minute
		// 
		//****************************************************************************************
		public int Get_Expiration_Minute()
		{
			return expiration_minute;
		}
		#endregion
	}
}