﻿/*
 * All code (c)2012 Jay Basen all rights reserved
 */
using System;
using System.Collections.Generic;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.CrestronLogger;

namespace Shade_Automation_Manager
{
	public class room
	{
		#region Declarations
		private Object ThreadLock = new object();
		public string name;														//room name
		public string note;														//free form note from xml
		public uint temperature_join;											//join number for thermostat feedback of current temperature
		public uint setpoint_join;												//join number for thermostat feedback of current setpoint
		public uint thermostat_mode_join;										//join number for thermostat feedback of current mode
		int current_temperature;
		int current_setpoint;
		modes current_thermostat_mode;
		public bool ignore_party_flag;											//if true, continue automated shade movements during a party
		public bool close_when_away;											//if true, close windows in room when away or vacation flag set
		public List<shade> shade_list;											//list of shades in a room

		#endregion

		#region Methods
		//****************************************************************************************
		// 
		//  room	-	constructor
		// 
		//****************************************************************************************
		public room()
		{
			try
			{
				name = "";
				temperature_join = 0;
				setpoint_join = 0;
				thermostat_mode_join = 0;
				ignore_party_flag = false;
				shade_list = new List<shade>();
			}
			catch (Exception e)
			{
				Crestron.SimplSharp.ErrorLog.Error(string.Format("room constructor: " + e + "\n\r"));
				CrestronLogger.WriteToLog("room constructor: " + e + "\n\r", 0);
			}
		}

		//****************************************************************************************
		// 
		//  Restore_Shades_After_Party_or_Away	-	restores shades to where they should be after a party
		//											disabled automated movements or the away flag has been set
		// 
		//****************************************************************************************
		public void Restore_Shades_After_Party_or_Away()
		{
			shade_list.ForEach(delegate(shade sh)								//loop through each shade in the room
			{
				sh.Restore_Shade_After_Party_or_Away();							//restore the shade to the last automated event
			});
		}

		//****************************************************************************************
		// 
		//  Motion_In_Room	-	Don't let manual shade timers expire when people are in a room
		// 
		//****************************************************************************************
		public void Motion_In_Room()
		{
			shade_list.ForEach(delegate(shade sh)								//loop through each shade in the room
			{
				sh.Motion_In_Room();											//Don't let the manual shade timer expire
			});
		}

		//****************************************************************************************
		// 
		//  Get_Room_Setpoint	-	returns the themostat setpoint for a room
		// 
		//****************************************************************************************
		public int Get_Room_Setpoint()
		{
			lock (ThreadLock)
			{
				//check if alarm set or homeowners are on vacation
				if ((Variables.Get_Away_Flag() == true) || (Variables.Get_Vacation_Flag() == true))
				{
					//return default when away flag or vacation flag set
					//so shades regulate based on normal temperature
					//not thermostat setback temperature
					return Variables.default_room_setpoint;
				}
				else
				{
					if (this.current_thermostat_mode == modes.off)
					{
						return Variables.default_room_setpoint;					//return default when thermostat is off
					}
					else
					{
						return current_setpoint;								// return setpoint for this room
					}
				}
			}
		}

		//****************************************************************************************
		// 
		//  Set_Room_Setpoint	-	saves the themostat setpoint for a room
		// 
		//****************************************************************************************
		public void Set_Room_Setpoint(int sp)
		{
			lock (ThreadLock)
			{
				current_setpoint = sp;
			}
		}

		//****************************************************************************************
		// 
		//  Get_Room_Temperature	-	returns the themostat temperature for a room
		// 
		//****************************************************************************************
		public int Get_Room_Temperature()
		{
			lock (ThreadLock)
			{
				return current_temperature;										// return setpoint for this room
			}
		}

		//****************************************************************************************
		// 
		//  Set_Room_Temperature	-	saves the themostat temperature for a room
		// 
		//****************************************************************************************
		public void Set_Room_Temperature(int temp)
		{
			lock (ThreadLock)
			{
				current_temperature = temp;
			}
		}

		//****************************************************************************************
		// 
		//  Get_Room_Thermostat_Mode	-	returns the themostat mode for a room
		// 
		//****************************************************************************************
		public modes Get_Room_Thermostat_Mode()
		{
			lock (ThreadLock)
			{
				return current_thermostat_mode;
			}
		}

		//****************************************************************************************
		// 
		//  Set_Room_Thermostat_Mode	-	saves the themostat mode for a room
		// 
		//****************************************************************************************
		public void Set_Room_Thermostat_Mode(modes m)
		{
			lock (ThreadLock)
			{
				current_thermostat_mode = m;
			}
		}
		#endregion
	}
}