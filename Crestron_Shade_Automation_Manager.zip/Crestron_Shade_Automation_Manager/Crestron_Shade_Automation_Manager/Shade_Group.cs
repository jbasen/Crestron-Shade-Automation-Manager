﻿/*
 * All code (c)2012 Jay Basen all rights reserved
 */
using System;
using System.Collections.Generic;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.CrestronLogger;

namespace Shade_Automation_Manager
{
	public class Shade_Group
	{
		#region Declarations
		public string name;														//name of the group
		public List<shade> shade_list;											//list of shades in a room
		public static List<Shade_Group> shade_group_list;						//list of shade groups for group movements																		//traverse for debugging
		#endregion

		#region Methods
		//****************************************************************************************
		// 
		//  Create_Group_List	-	Create the static group list
		// 
		//****************************************************************************************
		static public void Create_Group_List()
		{
			//Allocate memory for group list
			try
			{
				shade_group_list = new List<Shade_Group>();
			}
			catch (Exception e)
			{
				CrestronLogger.WriteToLog(string.Format("Create_Group_List alloate Shade_Group: " + e + "\n\r"), 0);
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Create_Group_List alloate Shade_Group: " + e + "\n\r"));
			}
		}
		
		//****************************************************************************************
		// 
		//  Shade_Group	-	Constructor
		// 
		//****************************************************************************************
		public Shade_Group(shade sh)
		{
			try
			{
				name = sh.group_name;
				shade_list = new List<shade>();
				shade_list.Add(sh);
			}
			catch (Exception e)
			{
				Crestron.SimplSharp.ErrorLog.Error(string.Format("shade_group constructor: " + e + "\n\r"));
				CrestronLogger.WriteToLog("shade_group constructor: " + e + "\n\r", 0);
			}
		}

		//****************************************************************************************
		// 
		//  add	-	add shade to group list
		// 
		//****************************************************************************************
		static public void add(shade sh)
		{
			bool found_it = false;

			if (sh.group_name != "none")										//see if this shade is in a group
			{
				try
				{
					shade_group_list.ForEach(delegate(Shade_Group grp)			//walk through each group
					{
						if (grp.name == sh.group_name)							//is this the right group for this shade?
						{
							//found the group
							grp.shade_list.Add(sh);								//add the shade to the group list
							found_it = true;									//done
							return;
						}
					});

					//couldn't match the group name of this shade to any current group
					//create a new group

					if (found_it == false)										//logic based on code still getting here after return
					{
						Shade_Group new_group = new Shade_Group(sh);
						shade_group_list.Add(new_group);
					}
				}
				catch (Exception e)
				{
					Crestron.SimplSharp.ErrorLog.Error(string.Format("shade_group add: " + e + "\n\r"));
					CrestronLogger.WriteToLog("shade_group add: " + e + "\n\r", 0);
				}
			}
		}
		//****************************************************************************************
		// 
		//  validate	-	valdiates all shades in a group have the same option
		// 
		//****************************************************************************************
		static public void validate()
		{
			options option;														//temporary storage for group option

			shade_group_list.ForEach(delegate(Shade_Group grp)					//walk through each group
			{
				option = options.undefined;										//set for first time through shade loop
				grp.shade_list.ForEach(delegate(shade sh)						//walk through each shade in the group
				{
					if (option == options.undefined)							//check if first time 
					{
						option = sh.option;										//save the option for the first shade in the group
					}
					else
					{
						if (option != sh.option)
						{
							//error - all shades in a group must have the same option
							Crestron.SimplSharp.ErrorLog.Error(string.Format("shade_group validate: Shade " + sh.name + 
								" in group " + grp.name + " with option " + sh.option + "\n\r"));
							CrestronLogger.WriteToLog("shade_group validate: Shade " + sh.name +
								" in group " + grp.name + " with option " + sh.option + "\n\r", 0);
						}
					}
				});
			});
		}
		//****************************************************************************************
		// 
		//  evaluate_group_actions	-	walk through all the groups and then the shades in each
		//								group.  Look at the actions that have been determined for
		//								the individual shade and make them operate as a group.
		// 
		//****************************************************************************************
		static public void evaluate_group_actions()
		{
			actions action;

			shade_group_list.ForEach(delegate(Shade_Group grp)					//walk through each group
			{
				action = actions.none;											//set for first time through shade loop
				//first walk through each shade in the group and figure out
				//what the correct action to take on all shades in the group
				grp.shade_list.ForEach(delegate(shade sh)						//walk through each shade in the group
				{
					if ((sh.group_action != actions.none)						//if shade set to none or shade same as  
						&& (sh.group_action != action))							//current action for group, skip
					{
						if (action == actions.none)								//if first time through, just save what the shade is set for
						{
							action = sh.group_action;
						}
						else
						{
							//if action agrees with prefrence - over ride currently selected action for group.
							if ((Variables.preference == group_preference.all_open)
								&& (sh.group_action == actions.sun_open_full))
							{
								CrestronLogger.WriteToLog("Over-riding shade action - Open Shade\n\r", 5);
								action = actions.sun_open_full;
							}
							else if ((Variables.preference == group_preference.all_close)
								&& (sh.group_action == actions.sun_close_full))
							{
								CrestronLogger.WriteToLog("Over-riding shade action - Close Shade\n\r", 5);
								action = actions.sun_close_full;
							}
							else
							{
								//do nothing shade action doesn't agree with preference so don't force
							}
						}
					}
				});
				//second, walk through all shades in the group and
				//perform the same action one very shade
				grp.shade_list.ForEach(delegate(shade sh)								//walk through each shade in the group
				{
					if (action == actions.none)
					{
						CrestronLogger.WriteToLog("Group - No Shade Action\n\r", 5);
					}
					else if (action == actions.sun_close_full)
					{
						CrestronLogger.WriteToLog("Group - Close Shade\n\r", 5);
						sh.Shade_Move(actions.sun_close_full);							//close the shade
					}
					else if (action == actions.sun_open_full)
					{
						CrestronLogger.WriteToLog("Group - Open Shade\n\r", 5);
						sh.Shade_Move(actions.sun_open_full);							//open the shade
					}
					else
					{
						CrestronLogger.WriteToLog("evaluate_group_actions: Error - Undefined shade action\n\r", 5);
					}
				});
			});
		}
		//****************************************************************************************
		// 
		//  find_group	-	find a group by name
		// 
		//****************************************************************************************
		static public Shade_Group find_group(string name)
		{
			SimplSharpString s;
			Shade_Group found_group = null;

			shade_group_list.ForEach(delegate(Shade_Group grp)					//walk through each group
			{
				s = grp.name.ToLower();											//convert to lower case for comparison

				if (s.ToString() == name)										//see if this is the group that matches the name we are looking for
				{
					found_group = grp;											//save the group to pass back
				}
			});
			return found_group;													//return group or null
		}
		//****************************************************************************************
		// 
		//  group_action	-	perform an action on all shades in a group
		// 
		//****************************************************************************************
		public void group_action(actions action)
		{
			shade_list.ForEach(delegate(shade sh)								//walk through each shade in the group
			{
				sh.Shade_Move(action);											//apply the action to the shade
			});
		}
		#endregion
	}
}
