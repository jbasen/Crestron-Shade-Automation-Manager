﻿/*
 * All code (c)2012 Jay Basen all rights reserved
 */
using System;
using System.Collections.Generic;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.CrestronLogger;

namespace Shade_Automation_Manager
{
	public class shade
	{
		#region Declarations
		public int id;															//unique shade id
		public string name;														//name of shade
		public string note;														//free form string from xml
		public double east_horizon;												//angle to east that sun must rise above to be on the window
		public double west_horizon;												//angle to the west that sun must be above to be on the window
		public double angle_from_north;											//window angle from the north
		public double eave_height;												//height of eave measured from bottom of the window in feet
		public double eave_depth;												//depth of eave in feet
		public double max_eave_depth_low;										//max depth toward low sun azimuth angles (feet)
		public double max_eave_depth_high;										//max depth toward high sun azimuth angles (feet)
		public double height_floor_to_sill;										//height from floor to window sill (feet)
		public double window_height;											//height of the window (feet)
		public options option;													//"art_save", etc
		private bool hold_after_schedule_event;									//true if shade has been opened or closed by a scheduled event
		private bool hold_after_manual_movement;								//true if shade has been opened or closed manually
		public string timed_actions;											//list of timed actions in the format time-action,time-action i.e. 10:00 AM-open
		public actions sunrise_action;											//action to take at sunrise
		public actions sunset_action;											//action to take at sunset
		public room room;														//the room the shade is in
		public string group_name;												//name of the group that the shade is in or "none"
		public actions group_action;											//storage for action that needs to be evaluated in terms of what actions the 
																				//entire shade group will take
		public string hardware_address;											//address of the hardware this shade is connected to for control
																				//i.e. Cresnet7A:1 where 7A is the cresnet address of an sdc and 1 is the sdc port
		public bool close_on_glare;												//if true, close shade when glare in room from sun through window
		public uint serial_join;												//serial join for reporting status through EISC
		public uint analog_join;												//analog join for reporting status through EISC
		public shade_interface hardware_interface;								//link to hardware
		private actions last_action;											//last automated action on the shade so we can play catchup after
																				//automation is restored
		CTimer manual_lock_timer;												//timer to release lock after manual shade movement
		private Object ThreadLock;

		const long shade_lock_timer_duration = 3600000;							//1 hour in msec

		#endregion

		#region Methods
		//****************************************************************************************
		// 
		//  shade	-	constructor
		// 
		//****************************************************************************************
		public shade()															//constructor
		{
			ThreadLock = new object();

			id = 0;
			name = "";
			east_horizon = 0;
			west_horizon = 0;
			angle_from_north = 0;
			eave_height = 0;
			eave_depth = 0;
			max_eave_depth_low = 0;
			max_eave_depth_high = 0;
			option = options.energy_save_aesthetics;
			hold_after_schedule_event = false;
			hold_after_manual_movement = false;
			timed_actions = "";
			sunrise_action = actions.none;
			sunset_action = actions.none;
			room = null;
			hardware_address = "";
			hardware_interface = null;
			last_action = actions.none;
			manual_lock_timer = null;
			group_name = "";
		}

		//****************************************************************************************
		// 
		//  ~shade	-	destructor
		// 
		//****************************************************************************************
		~shade()																//destructor
		{
		}

		//****************************************************************************************
		// 
		//  Shade_Move	-	operate shades based on selected action
		// 
		//****************************************************************************************
		public void Shade_Move(actions act)
		{
			lock (ThreadLock)
			{
				switch (act)
				{
					case (actions.none):
						break;

					case (actions.sun_open_full):
						Save_Last_Event(act);									//save the last automated event
						if ((Variables.Get_Party_Flag(room) == false)			//hold off if there is a party going on
							&& (hold_after_schedule_event == false)				//hold off if there was a schduled movement
							&& (hold_after_manual_movement == false)			//hold off if there was manual movement
							&& (!((room.close_when_away == true)				//hold off if this room is set to close when
							&&((Variables.Get_Away_Flag() == true)				//away flag or vacation flag is set
							|| (Variables.Get_Vacation_Flag() == true)))))
						{
							hardware_interface.Open_Full();						//call the hardware interface to open the shade
						}
						break;

					case (actions.sun_close_full):
						Save_Last_Event(act);									//save the last automated event
						if (((Variables.Get_Party_Flag(room) == false)			//hold off if there is a party going on
							&& (hold_after_schedule_event == false)				//hold off if there was a schduled movement
							&& (hold_after_manual_movement == false))			//hold off if there was manual movement
							&& (!((room.close_when_away == true)				//hold off if this room is set to close when
							&&((Variables.Get_Away_Flag() == true)				//away flag or vacation flag is set
							|| (Variables.Get_Vacation_Flag() == true)))))
						{
							hardware_interface.Close_Full();					//call the hardware interface to open the shade
						}
						break;

					case (actions.schedule_open_full):
						Save_Last_Event(act);									//save the last automated event
						if (((Variables.Get_Party_Flag(room) == false)			//hold off if there is a party going on
							&& (hold_after_manual_movement == false))			//hold off if there was manual movement
							&& (!((room.close_when_away == true)				//hold off if this room is set to close when
							&&((Variables.Get_Away_Flag() == true)				//away flag or vacation flag is set
							|| (Variables.Get_Vacation_Flag() == true)))))
						{
							hardware_interface.Open_Full();						//call the hardware interface to open the shade
						}
						hold_after_schedule_event = true;						//disable sun angle movements
						break;

					case (actions.schedule_close_full):
						Save_Last_Event(act);									//save the last automated event
						if (((Variables.Get_Party_Flag(room) == false)			//hold off if there is a party going on
							&& (hold_after_manual_movement == false))			//hold off if there was manual movement
							&& (!((room.close_when_away == true)				//hold off if this room is set to close when
							&&((Variables.Get_Away_Flag() == true)				//away flag or vacation flag is set
							|| (Variables.Get_Vacation_Flag() == true)))))
						{
							hardware_interface.Close_Full();					//call the hardware interface to open the shade
						}
						hold_after_schedule_event = true;						//disable sun angle movements
						break;

					case (actions.schedule_unlock):
						hold_after_schedule_event = false;						//enable sun angle movements
						break;

					case (actions.manual_open_full):
						hardware_interface.Open_Full();							//call the hardware interface to open the shade
						hold_after_manual_movement = true;						//enable sun angle movements
						Manual_Operation_Timer();								//start the timer to unlock automated movements after 2 hours
						break;

					case (actions.manual_close_full):
						hardware_interface.Close_Full();						//call the hardware interface to close the shade
						hold_after_manual_movement = true;						//enable sun angle movements
						Manual_Operation_Timer();								//start the timer to unlock automated movements after 2 hours
						break;

					case (actions.manual_open):
						hardware_interface.Open_Momentary();					//call the hardware interface to open the shade
						hold_after_manual_movement = true;						//enable sun angle movements
						Manual_Operation_Timer();								//start the timer to unlock automated movements after 2 hours
						break;

					case (actions.manual_close):
						hardware_interface.Close_Momentary();					//call the hardware interface to close the shade
						hold_after_manual_movement = true;						//enable sun angle movements
						Manual_Operation_Timer();								//start the timer to unlock automated movements after 2 hours
						break;

					case (actions.manual_stop):
						hardware_interface.Stop();								//call the hardware interface to stop the shade
						hold_after_manual_movement = true;						//enable sun angle movements
						Manual_Operation_Timer();								//start the timer to unlock automated movements after 2 hours
						break;

					case (actions.manual_unlock):
						hold_after_manual_movement = false;						//enable sun angle movements
						if (manual_lock_timer != null)
						{
							manual_lock_timer.Stop();
						}
						break;

					case (actions.away_close):
						hardware_interface.Close_Full();						//call the hardware interface to close the shade
						break;

					default:
						Crestron.SimplSharp.ErrorLog.Error("Shade_Move: invalid action " + act + "\n\r");
						CrestronLogger.WriteToLog("Shade_Move: invalid action " + act + "\n\r", 0);
						break;
				}
			}
		}
		//****************************************************************************************
		// 
		//  Save_Last_Event	-	saves the last shade movement command
		// 
		//****************************************************************************************
		public void Save_Last_Event(actions act)
		{
			switch (act)
			{
				case (actions.sun_open_full):
				case (actions.sun_close_full):
					if (hold_after_schedule_event == false)
					{
						last_action = act;
					}
					break;

				case (actions.schedule_open_full):
				case (actions.schedule_close_full):
					last_action = act;
					break;

				default:
					break;
			}
		}
		//****************************************************************************************
		// 
		//  Restore_Shade_After_Party_or_Away	-	restores shade to proper state after a party
		//											or the away flag has been set
		// 
		//****************************************************************************************
		public void Restore_Shade_After_Party_or_Away()
		{
			//when the party flag is cleared it assumes that prior manual movements
			//were part of the party setup so it clears the manual movement hold to
			//restore going back to automation in those rooms where the party flag
			//kept automated movements from occurring
			lock (ThreadLock)
			{
				if ((Variables.Get_Party_Flag(room) == true)					//if any flag is set, don't continue
					|| (Variables.Get_Away_Flag() == true)
					|| (Variables.Get_Vacation_Flag() == true))
				{
					return;
				}

				if (room.ignore_party_flag == false)
				{
					hold_after_manual_movement = false;
				}

				switch (last_action)
				{
					case (actions.none):
						break;

					case (actions.sun_open_full):
						if ((hold_after_schedule_event == false)				//hold off if there was a schduled movement
							&& (hold_after_manual_movement == false))			//hold off if there was manual movement
						{
							hardware_interface.Open_Full();						//call the hardware interface to open the shade
						}
						break;

					case (actions.sun_close_full):
						if ((hold_after_schedule_event == false)				//hold off if there was a schduled movement
							&& (hold_after_manual_movement == false))			//hold off if there was manual movement
						{
							hardware_interface.Close_Full();					//call the hardware interface to open the shade
						}
						break;

					case (actions.schedule_open_full):
						if (hold_after_manual_movement == false)				//hold off if there was manual movement
						{
							hardware_interface.Open_Full();						//call the hardware interface to open the shade
						}
						hold_after_schedule_event = true;						//disable sun angle movements
						break;

					case (actions.schedule_close_full):
						if (hold_after_manual_movement == false)				//hold off if there was manual movement
						{
							hardware_interface.Close_Full();					//call the hardware interface to open the shade
						}
						hold_after_schedule_event = true;						//disable sun angle movements
						break;

					default:
						break;
				}
			}
		}

		//****************************************************************************************
		// 
		//  Start_Shade_Lock_Timer	-	starts/restarts shade lock timer after manual movement
		// 
		//****************************************************************************************
		private void Manual_Operation_Timer()
		{
			lock (ThreadLock)
			{
				try
				{
					if (manual_lock_timer == null)
					{
						manual_lock_timer = new CTimer(Manual_Operation_Timer_Callback, this, shade_lock_timer_duration, 0);
					}
					else
					{
						manual_lock_timer.Reset(shade_lock_timer_duration);
					}
				}
				catch (Exception e)
				{
					Crestron.SimplSharp.ErrorLog.Error(string.Format("Manual_Operation_Timer: " + e + "\n\r"));
					CrestronLogger.WriteToLog("Manual_Operation_Timer: " + e + "\n\r", 0);
				}
			}
		}

		//****************************************************************************************
		// 
		//  Shade_Lock_Timer_Callback	-	called when shade lock timer expires
		// 
		//****************************************************************************************
		private void Manual_Operation_Timer_Callback(object obj)
		{
			((shade)obj).hold_after_manual_movement = false;					//enable sun angle movements
		}

		//****************************************************************************************
		// 
		//  Motion_In_Room	-	Don't let manual shade timers expire when people are in a room
		// 
		//****************************************************************************************
		public void Motion_In_Room()
		{
			lock (ThreadLock)
			{
				if (hold_after_manual_movement == true)
				{
					Manual_Operation_Timer();
				}
			}
		}
		#endregion
	}
}