﻿/*
 * All code (c)2012 Jay Basen all rights reserved
 */
using System;
using System.Collections.Generic;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.CrestronLogger;
using Crestron.SimplSharp.CrestronThread;										// For Threading

namespace Shade_Automation_Manager
{
	public class shade_interface												//acts to virtualize the hardware interface for the shade class
	{
		#region Declarations
		private Thread FW_Thread;
		private Object ThreadLock = new object();
		public string id;														//formatted string in the format of hardware address:port - i.e.
																				//Cresent7A:1 for Cresnet id 7A, SDC device 1.
		private Cresnet_C2N_SDC sdc;											//link to shade hardware interface
		private Cresnet_C2N_SDC_DC sdc_dc;										//link to shade hardware interface
		private Cresnet_CSM_QMT50_DCCN qmt50_dccn;								//link to shade hardware interface
		private RF_CSC_ACEX csc_acex;											//link to shade hardware interface
		private RF_CSC_DCEX csc_dcex;											//link to shade hardware interface
		private RF_CSC_DRPEX csc_drpex;											//link to drape hardware interface
		private Cresnet_CSC_ACCN csc_accn;										//link to shade hardware interface
		private Cresnet_CSC_DCCN csc_dccn;										//link to shade hardware interface
		private Cresnet_CSC_DRPCN csc_drpcn;									//link to drape hardware interface
		private int port;														//port id on multi-port controller
		private shade_hardware_type type;										//type of hardware shade interface is talking to
		public shade shade;														//link to shade controlled by this shade interface
		const ushort shade_jog_increment = 100;									//position change for a crestron shade when jogging
		#endregion

		#region Methods
		//****************************************************************************************
		// 
		//  shade_interface	-	constructor for sdc type shade
		// 
		//****************************************************************************************
		public shade_interface(Cresnet_C2N_SDC sdc, int port)
		{
			lock (ThreadLock)
			{
				this.sdc = sdc;													//save the link to the sdc
				this.id = "Cresnet" + sdc.ID.ToString("x2") + ":" + port;		//create id string for match with shade xml data
				this.id = this.id.ToLower();									//make all lower case for string comparison
				this.port = port;												//save which port we are connected to for 2 port sdc control
				this.type = shade_hardware_type.sdc;							//save the hardware type
				this.shade = null;												//no link between shade and shade controller
			}
		}

		//****************************************************************************************
		// 
		//  shade_interface	-	constructor for sdc_dc type shade
		// 
		//****************************************************************************************
		public shade_interface(Cresnet_C2N_SDC_DC sdc_dc, int port)
		{
			lock (ThreadLock)
			{
				this.sdc_dc = sdc_dc;											//save the link to the sdc
				this.id = "Cresnet" + sdc_dc.ID.ToString("x2") + ":" + port;	//create id string for match with shade xml data
				this.id = this.id.ToLower();									//make all lower case for string comparison
				this.port = port;												//save which port we are connected to for 2 port sdc control
				this.type = shade_hardware_type.sdc_dc;							//save the hardware type
				this.shade = null;												//no link between shade and shade controller
			}
		}

		//****************************************************************************************
		// 
		//  shade_interface	-	constructor for csm_qmt50_dccn type shade
		// 
		//****************************************************************************************
		public shade_interface(Cresnet_CSM_QMT50_DCCN csm_qmt50_dccn)
		{
			lock (ThreadLock)
			{
				this.qmt50_dccn = csm_qmt50_dccn;								//save the link to the hardware
				this.id = "Cresnet" + csm_qmt50_dccn.ID.ToString("x2");			//create id string for match with shade xml data
				this.id = this.id.ToLower();									//make all lower case for string comparison
				this.type = shade_hardware_type.qmt50_dccn;						//save the hardware type
				this.shade = null;												//no link between shade and shade controller
			}
		}

		//****************************************************************************************
		// 
		//  shade_interface	-	constructor for csc_acex type shade
		// 
		//****************************************************************************************
		public shade_interface(RF_CSC_ACEX csc_acex)
		{
			lock (ThreadLock)
			{
				this.csc_acex = csc_acex;										//save the link to the hardware
				this.id = "EX" + csc_acex.ID.ToString("x2");					//create id string for match with shade xml data
				this.id = this.id.ToLower();									//make all lower case for string comparison
				this.type = shade_hardware_type.csc_acex;						//save the hardware type
				this.shade = null;												//no link between shade and shade controller
			}
		}

		//****************************************************************************************
		// 
		//  shade_interface	-	constructor for csc_dcex type shade
		// 
		//****************************************************************************************
		public shade_interface(RF_CSC_DCEX csc_dcex)
		{
			lock (ThreadLock)
			{
				this.csc_dcex = csc_dcex;										//save the link to the hardware
				this.id = "EX" + csc_dcex.ID.ToString("x2");					//create id string for match with shade xml data
				this.id = this.id.ToLower();									//make all lower case for string comparison
				this.type = shade_hardware_type.csc_dcex;						//save the hardware type
				this.shade = null;												//no link between shade and shade controller
			}
		}

		//****************************************************************************************
		// 
		//  shade_interface	-	constructor for csc_drpex type drape
		// 
		//****************************************************************************************
		public shade_interface(RF_CSC_DRPEX csc_drpex)
		{
			lock (ThreadLock)
			{
				this.csc_drpex = csc_drpex;										//save the link to the hardware
				this.id = "EX" + csc_drpex.ID.ToString("x2");					//create id string for match with shade xml data
				this.id = this.id.ToLower();									//make all lower case for string comparison
				this.type = shade_hardware_type.csc_drpex;						//save the hardware type
				this.shade = null;												//no link between shade and shade controller
			}
		}

		//****************************************************************************************
		// 
		//  shade_interface	-	constructor for csc_accn type shade
		// 
		//****************************************************************************************
		public shade_interface(Cresnet_CSC_ACCN csc_accn)
		{
			lock (ThreadLock)
			{
				this.csc_accn = csc_accn;										//save the link to the hardware
				this.id = "Cresnet" + csc_accn.ID.ToString("x2");				//create id string for match with shade xml data
				this.id = this.id.ToLower();									//make all lower case for string comparison
				this.type = shade_hardware_type.csc_accn;						//save the hardware type
				this.shade = null;												//no link between shade and shade controller
			}
		}

		//****************************************************************************************
		// 
		//  shade_interface	-	constructor for csc_dccn type shade
		// 
		//****************************************************************************************
		public shade_interface(Cresnet_CSC_DCCN csc_dccn)
		{
			lock (ThreadLock)
			{
				this.csc_dccn = csc_dccn;										//save the link to the hardware
				this.id = "Cresnet" + csc_dccn.ID.ToString("x2");				//create id string for match with shade xml data
				this.id = this.id.ToLower();									//make all lower case for string comparison
				this.type = shade_hardware_type.csc_dccn;						//save the hardware type
				this.shade = null;												//no link between shade and shade controller
			}
		}

		//****************************************************************************************
		// 
		//  shade_interface	-	constructor for csc_drpcn type drape
		// 
		//****************************************************************************************
		public shade_interface(Cresnet_CSC_DRPCN csc_drpcn)
		{
			lock (ThreadLock)
			{
				this.csc_drpcn = csc_drpcn;										//save the link to the hardware
				this.id = "Cresnet" + csc_drpcn.ID.ToString("x2");				//create id string for match with shade xml data
				this.id = this.id.ToLower();									//make all lower case for string comparison
				this.type = shade_hardware_type.csc_drpcn;						//save the hardware type
				this.shade = null;												//no link between shade and shade controller
			}
		}

		//****************************************************************************************
		// 
		//  Set_Shade	-	saves which shade the shade interface is controlling
		// 
		//****************************************************************************************
		public void Set_Shade(shade sh)
		{
			shade = sh;
		}

		//****************************************************************************************
		// 
		//  Open_Full	-	fully open the shade
		// 
		//****************************************************************************************
		public void Open_Full()
		{
			lock (ThreadLock)
			{
				if (type == shade_hardware_type.sdc)							//check if we are connected to an sdc
				{
					if (sdc.IsOnline == true)
					{
						if (port == 1)											//check if we are talking to the first port of the sdc
						{
							sdc.Sh1_OpenFull = true;
							sdc.Sh1_OpenFull = false;
						}
						else if (port == 2)										//check if we are talking to the second port of the sdc
						{
							sdc.Sh2_OpenFull = true;
							sdc.Sh2_OpenFull = false;
						}
						else													//invalid port
						{
							Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-open_full: invalid sdc port\n\r");
							CrestronLogger.WriteToLog("Error: class shade_interface-open_full: invalid sdc port\n\r", 5);
							return;
						}
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-open_full: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-open_full: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.sdc_dc)					//check if we are connected to an sdc_dc
				{
					if (sdc_dc.IsOnline == true)
					{
						if (port == 1)											//check if we are talking to the first port of the sdc_dc
						{
							sdc_dc.Sh1_OpenFull = true;
							sdc_dc.Sh1_OpenFull = false;
						}
						else if (port == 2)										//check if we are talking to the second port of the sdc_dc
						{
							sdc_dc.Sh2_OpenFull = true;
							sdc_dc.Sh2_OpenFull = false;
						}
						else													//invalid port
						{
							Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-open_full: invalid sdc_dc port\n\r");
							CrestronLogger.WriteToLog("Error: class shade_interface-open_full: invalid sdc_dc port\n\r", 5);
							return;
						}
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-open_full: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-open_full: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.qmt50_dccn)				//check if we are connected to an qmt50_dccn
				{
					if (qmt50_dccn.IsOnline == true)
					{
						qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Open = true;
						qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Open = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-open_full: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-open_full: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_acex)				//check if we are connected to a csc_acex
				{
					if (csc_acex.IsOnline == true)
					{
						csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Open = true;
						csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Open = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-open_full: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-open_full: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_dcex)				//check if we are connected to a csc_dcex
				{
					if (csc_dcex.IsOnline == true)
					{
						csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Open = true;
						csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Open = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-open_full: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-open_full: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_drpex)				//check if we are connected to a csc_drpex
				{
					if (csc_drpex.IsOnline == true)
					{
						csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Open = true;
						csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Open = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-open_full: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-open_full: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_accn)				//check if we are connected to an csc_accn
				{
					if (csc_accn.IsOnline == true)
					{
						csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Open = true;
						csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Open = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-open_full: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-open_full: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_dccn)				//check if we are connected to an csc_dccn
				{
					if (csc_dccn.IsOnline == true)
					{
						csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Open = true;
						csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Open = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-open_full: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-open_full: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_drpcn)				//check if we are connected to an csc_drpcn
				{
					if (csc_drpcn.IsOnline == true)
					{
						csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Open = true;
						csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Open = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-open_full: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-open_full: shade controller offline\n\r", 5);
						return;
					}
				}
				else															//unsupported hardware
				{
					Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-open_full: invalid hardware type\n\r");
					CrestronLogger.WriteToLog("Error: class shade_interface-open_full: invalid hardware type\n\r", 5);
					return;
				}

				Variables.EISC_Analog_Output(shade.analog_join, ushort.MinValue);//report that shade is fully open
			}
		}

		//****************************************************************************************
		// 
		//  Close_Full	-	fully close the shade
		// 
		//****************************************************************************************
		public void Close_Full()
		{
			lock (ThreadLock)
			{
				if (type == shade_hardware_type.sdc)							//check if we are connected to an sdc
				{
					if (sdc.IsOnline == true)
					{
						if (port == 1)											//check if we are talking to the first port of the sdc
						{
							sdc.Sh1_CloseFull = true;
							sdc.Sh1_CloseFull = false;
						}
						else if (port == 2)										//check if we are talking to the second port of the sdc
						{
							sdc.Sh2_CloseFull = true;
							sdc.Sh2_CloseFull = false;
						}
						else													//invalid port
						{
							Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-close_full: invalid sdc port\n\r");
							CrestronLogger.WriteToLog("Error: class shade_interface-close_full: invalid sdc port\n\r", 5);
							return;
						}
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-close_full: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-close_full: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.sdc_dc)					//check if we are connected to an sdc_dc
				{
					if (sdc_dc.IsOnline == true)
					{
						if (port == 1)											//check if we are talking to the first port of the sdc_dc
						{
							sdc_dc.Sh1_CloseFull = true;
							sdc_dc.Sh1_CloseFull = false;
						}
						else if (port == 2)										//check if we are talking to the second port of the sdc_dc
						{
							sdc_dc.Sh2_CloseFull = true;
							sdc_dc.Sh2_CloseFull = false;
						}
						else													//invalid port
						{
							Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-close_full: invalid sdc_dc port\n\r");
							CrestronLogger.WriteToLog("Error: class shade_interface-close_full: invalid sdc_dc port\n\r", 5);
							return;
						}
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-close_full: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-close_full: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.qmt50_dccn)				//check if we are connected to an qmt50_dccn
				{
					if (qmt50_dccn.IsOnline == true)
					{
						qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Close = true;
						qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Close = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-close_full: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-close_full: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_acex)				//check if we are connected to a csc_acex
				{
					if (csc_acex.IsOnline == true)
					{
						csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Close = true;
						csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Close = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-close_full: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-close_full: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_dcex)				//check if we are connected to a csc_dcex
				{
					if (csc_dcex.IsOnline == true)
					{
						csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Close = true;
						csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Close = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-close_full: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-close_full: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_drpex)				//check if we are connected to a csc_drpex
				{
					if (csc_drpex.IsOnline == true)
					{
						csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Close = true;
						csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Close = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-close_full: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-close_full: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_accn)				//check if we are connected to an csc_accn
				{
					if (csc_accn.IsOnline == true)
					{
						csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Close = true;
						csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Close = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-close_full: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-close_full: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_dccn)				//check if we are connected to an csc_dccn
				{
					if (csc_dccn.IsOnline == true)
					{
						csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Close = true;
						csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Close = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-close_full: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-close_full: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_drpcn)				//check if we are connected to an csc_drpcn
				{
					if (csc_drpcn.IsOnline == true)
					{
						csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Close = true;
						csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Close = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-close_full: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-close_full: shade controller offline\n\r", 5);
						return;
					}
				}
				else															//unsupported hardware
				{
					Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-close_full: invalid hardware type\n\r");
					CrestronLogger.WriteToLog("Error: class shade_interface-close_full: invalid hardware type\n\r", 5);
					return;
				}

				Variables.EISC_Analog_Output(shade.analog_join, ushort.MaxValue);//report that shade is fully closed
			}
		}

		//****************************************************************************************
		// 
		//  Open_Momentary	-	open shade until stop command
		// 
		//****************************************************************************************
		public void Open_Momentary()
		{
			lock (ThreadLock)
			{
				if (type == shade_hardware_type.sdc)							//check if we are connected to an sdc
				{
					if (sdc.IsOnline == true)
					{
						if (port == 1)											//check if we are talking to the first port of the sdc
						{
							sdc.Sh1_OpenMomentary = true;
							sdc.Sh1_OpenMomentary = false;
						}
						else if (port == 2)										//check if we are talking to the second port of the sdc
						{
							sdc.Sh2_OpenMomentary = true;
							sdc.Sh2_OpenMomentary = false;
						}
						else													//invalid port
						{
							Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Open_Momentary: invalid sdc port\n\r");
							CrestronLogger.WriteToLog("Error: class shade_interface-Open_Momentary: invalid sdc port\n\r", 5);
							return;
						}
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Open_Momentary: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-Open_Momentary: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.sdc_dc)					//check if we are connected to an sdc_dc
				{
					if (sdc_dc.IsOnline == true)
					{
						if (port == 1)											//check if we are talking to the first port of the sdc_dc
						{
							sdc_dc.Sh1_OpenMomentary = true;
							sdc_dc.Sh1_OpenMomentary = false;
						}
						else if (port == 2)										//check if we are talking to the second port of the sdc_dc
						{
							sdc_dc.Sh2_OpenMomentary = true;
							sdc_dc.Sh2_OpenMomentary = false;
						}
						else													//invalid port
						{
							Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Open_Momentary: invalid sdc_dc port\n\r");
							CrestronLogger.WriteToLog("Error: class shade_interface-Open_Momentary: invalid sdc_dc port\n\r", 5);
							return;
						}
					}
					else if (type == shade_hardware_type.qmt50_dccn)				//check if we are connected to an qmt50_dccn
					{
						if (qmt50_dccn.IsOnline == true)
						{
							qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Raise = true;
							qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Raise = false;
						}
						else														//shade hardware offline
						{
							Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-open_Momentary: shade controller offline\n\r");
							CrestronLogger.WriteToLog("Error: class shade_interface-open_Momentary: shade controller offline\n\r", 5);
							return;
						}
					}
					else if (type == shade_hardware_type.csc_acex)				//check if we are connected to a csc_acex
					{
						if (csc_acex.IsOnline == true)
						{
							csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Raise = true;
							csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Raise = false;
						}
						else														//shade hardware offline
						{
							Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-raise: shade controller offline\n\r");
							CrestronLogger.WriteToLog("Error: class shade_interface-raise: shade controller offline\n\r", 5);
							return;
						}
					}
					else if (type == shade_hardware_type.csc_dcex)				//check if we are connected to a csc_dcex
					{
						if (csc_dcex.IsOnline == true)
						{
							csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Raise = true;
							csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Raise = false;
						}
						else														//shade hardware offline
						{
							Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-raise: shade controller offline\n\r");
							CrestronLogger.WriteToLog("Error: class shade_interface-raise: shade controller offline\n\r", 5);
							return;
						}
					}
					else if (type == shade_hardware_type.csc_drpex)				//check if we are connected to a csc_drpex
					{
						if (csc_drpex.IsOnline == true)
						{
							csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Raise = true;
							csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Raise = false;
						}
						else														//shade hardware offline
						{
							Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-raise: shade controller offline\n\r");
							CrestronLogger.WriteToLog("Error: class shade_interface-raise: shade controller offline\n\r", 5);
							return;
						}
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Open_Momentary: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-Open_Momentary: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_accn)				//check if we are connected to an csc_accn
				{
					if (csc_accn.IsOnline == true)
					{
						csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Raise = true;
						csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Raise = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-open_Momentary: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-open_Momentary: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_dccn)				//check if we are connected to an csc_dccn
				{
					if (csc_dccn.IsOnline == true)
					{
						csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Raise = true;
						csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Raise = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-open_Momentary: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-open_Momentary: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_drpcn)				//check if we are connected to an csc_drpcn
				{
					if (csc_drpcn.IsOnline == true)
					{
						csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Raise = true;
						csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Raise = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-open_Momentary: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-open_Momentary: shade controller offline\n\r", 5);
						return;
					}
				}
				else															//unsupported hardware
				{
					Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Open_Momentary: invalid hardware type\n\r");
					CrestronLogger.WriteToLog("Error: class shade_interface-Open_Momentary: invalid hardware type\n\r", 5);
					return;
				}
			}
		}

		//****************************************************************************************
		// 
		//  Close_Momentary	-	close shade until stop command
		// 
		//****************************************************************************************
		public void Close_Momentary()
		{
			lock (ThreadLock)
			{
				if (type == shade_hardware_type.sdc)							//check if we are connected to an sdc
				{
					if (sdc.IsOnline == true)
					{
						if (port == 1)											//check if we are talking to the first port of the sdc
						{
							sdc.Sh1_CloseMomentary = true;
							sdc.Sh1_CloseMomentary = false;
						}
						else if (port == 2)										//check if we are talking to the second port of the sdc
						{
							sdc.Sh2_CloseMomentary = true;
							sdc.Sh2_CloseMomentary = false;
						}
						else													//invalid port
						{
							Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Close_Momentary: invalid sdc port\n\r");
							CrestronLogger.WriteToLog("Error: class shade_interface-Close_Momentary: invalid sdc port\n\r", 5);
							return;
						}
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Close_Momentary: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-Close_Momentary: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.sdc_dc)					//check if we are connected to an sdc_dc
				{
					if (sdc_dc.IsOnline == true)
					{
						if (port == 1)											//check if we are talking to the first port of the sdc_dc
						{
							sdc_dc.Sh1_CloseMomentary = true;
							sdc_dc.Sh1_CloseMomentary = false;
						}
						else if (port == 2)										//check if we are talking to the second port of the sdc_dc
						{
							sdc_dc.Sh2_CloseMomentary = true;
							sdc_dc.Sh2_CloseMomentary = false;
						}
						else													//invalid port
						{
							Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Close_Momentary: invalid sdc_dc port\n\r");
							CrestronLogger.WriteToLog("Error: class shade_interface-Close_Momentary: invalid sdc_dc port\n\r", 5);
							return;
						}
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Close_Momentary: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-Close_Momentary: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.qmt50_dccn)				//check if we are connected to an qmt50_dccn
				{
					if (qmt50_dccn.IsOnline == true)
					{
						qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Lower = true;
						qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Lower = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-close_momentary: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-close_momentary: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_acex)				//check if we are connected to a csc_acex
				{
					if (csc_acex.IsOnline == true)
					{
						csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Lower = true;
						csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Lower = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-lower: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-lower: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_dcex)				//check if we are connected to a csc_dcex
				{
					if (csc_dcex.IsOnline == true)
					{
						csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Lower = true;
						csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Lower = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-lower: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-lower: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_drpex)				//check if we are connected to a csc_drpex
				{
					if (csc_drpex.IsOnline == true)
					{
						csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Lower = true;
						csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Lower = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-lower: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-lower: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_accn)				//check if we are connected to an csc_accn
				{
					if (csc_accn.IsOnline == true)
					{
						csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Lower = true;
						csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Lower = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-close_momentary: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-close_momentary: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_dccn)				//check if we are connected to an csc_dccn
				{
					if (csc_dccn.IsOnline == true)
					{
						csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Lower = true;
						csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Lower = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-close_momentary: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-close_momentary: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_drpcn)				//check if we are connected to an csc_drpcn
				{
					if (csc_drpcn.IsOnline == true)
					{
						csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Lower = true;
						csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Lower = false;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-close_momentary: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-close_momentary: shade controller offline\n\r", 5);
						return;
					}
				}
				else															//unsupported hardware
				{
					Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Close_Momentary: invalid hardware type\n\r");
					CrestronLogger.WriteToLog("Error: class shade_interface-Close_Momentary: invalid hardware type\n\r", 5);
					return;
				}
			}
		}

		//****************************************************************************************
		// 
		//  Stop	-	stops shade movement
		// 
		//****************************************************************************************
		public void Stop()
		{
			ushort position;

			lock (ThreadLock)
			{
				if (type == shade_hardware_type.sdc)							//check if we are connected to an sdc
				{
					if (sdc.IsOnline == true)
					{
						if (port == 1)											//check if we are talking to the first port of the sdc
						{
							sdc.Sh1_Stop = true;
							sdc.Sh1_Stop = false;
						}
						else if (port == 2)										//check if we are talking to the second port of the sdc
						{
							sdc.Sh2_Stop = true;
							sdc.Sh2_Stop = false;
						}
						else													//invalid port
						{
							Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Stop: invalid sdc port\n\r");
							CrestronLogger.WriteToLog("Error: class shade_interface-Stop: invalid sdc port\n\r", 5);
							return;
						}
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Stop: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-Stop: shade controller offline\n\r", 5);
						return;
					}
					position = ushort.MaxValue / 2;								//we can't tell where the shade is so just report as in the middle
				}
				else if (type == shade_hardware_type.sdc_dc)					//check if we are connected to an sdc_dc
				{
					if (sdc_dc.IsOnline == true)
					{
						if (port == 1)											//check if we are talking to the first port of the sdc_dc
						{
							sdc_dc.Sh1_Stop = true;
							sdc_dc.Sh1_Stop = false;
						}
						else if (port == 2)										//check if we are talking to the second port of the sdc_dc
						{
							sdc_dc.Sh2_Stop = true;
							sdc_dc.Sh2_Stop = false;
						}
						else													//invalid port
						{
							Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Stop: invalid sdc_dc port\n\r");
							CrestronLogger.WriteToLog("Error: class shade_interface-Stop: invalid sdc_dc port\n\r", 5);
							return;
						}
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Stop: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-Stop: shade controller offline\n\r", 5);
						return;
					}
					position = ushort.MaxValue / 2;								//we can't tell where the shade is so just report as in the middle
				}
				else if (type == shade_hardware_type.qmt50_dccn)				//check if we are connected to an qmt50_dccn
				{
					if (qmt50_dccn.IsOnline == true)
					{
						qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Stop = true;
						qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Stop = false;
						position = qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Position_FB;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-stop: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-stop: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_acex)				//check if we are connected to a csc_acex
				{
					if (csc_acex.IsOnline == true)
					{
						csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Stop = true;
						csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Stop = false;
						position = csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Position_FB;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-stop: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-stop: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_dcex)				//check if we are connected to a csc_dcex
				{
					if (csc_dcex.IsOnline == true)
					{
						csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Stop = true;
						csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Stop = false;
						position = csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Position_FB;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-stop: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-stop: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_drpex)				//check if we are connected to a csc_drpex
				{
					if (csc_drpex.IsOnline == true)
					{
						csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Stop = true;
						csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Stop = false;
						position = csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Position_FB;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-stop: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-stop: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_accn)				//check if we are connected to an csc_accn
				{
					if (csc_accn.IsOnline == true)
					{
						csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Stop = true;
						csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Stop = false;
						position = csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Position_FB;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-stop: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-stop: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_dccn)				//check if we are connected to an csc_dccn
				{
					if (csc_dccn.IsOnline == true)
					{
						csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Stop = true;
						csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Stop = false;
						position = csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Position_FB;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-stop: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-stop: shade controller offline\n\r", 5);
						return;
					}
				}
				else if (type == shade_hardware_type.csc_drpcn)				//check if we are connected to an csc_drpcn
				{
					if (csc_drpcn.IsOnline == true)
					{
						csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Stop = true;
						csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Stop = false;
						position = csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Position_FB;
					}
					else														//shade hardware offline
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-stop: shade controller offline\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-stop: shade controller offline\n\r", 5);
						return;
					}
				}
				else															//unsupported hardware
				{
					Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Stop: invalid hardware type\n\r");
					CrestronLogger.WriteToLog("Error: class shade_interface-Stop: invalid hardware type\n\r", 5);
					return;
				}

				Variables.EISC_Analog_Output(shade.analog_join, position);//report shade position when stopped
			}
		}

		//****************************************************************************************
		// 
		//  Flick_Warn - Jogs the shade as visible warning to the homeowner of a change in status
		// 
		//****************************************************************************************
		public void Flick_Warn()
		{
			lock (ThreadLock)
			{
				FW_Thread = new Thread(Flick_Warn_Thread, null, Thread.ThreadStartOptions.CreateSuspended);
				FW_Thread.Start();
			}
		}

		//****************************************************************************************
		// 
		//  Flick_Warn_Thread	-	thread to perform Flick_Warn.  Jog both directions in case shade is
		//							fully opened or fully closed
		// 
		//****************************************************************************************
		private object Flick_Warn_Thread(object unused)
		{
			CurrentThread.Priority = Thread.ThreadPriority.LowestPriority;

			if (type == shade_hardware_type.sdc)								//check if we are connected to an sdc
			{
				if (sdc.IsOnline == true)
				{
					if (port == 1)												//check if we are talking to the first port of the sdc
					{
						sdc.Sh1_OpenJog = true;
						sdc.Sh1_OpenJog = false;
						Thread.Sleep(50);
						sdc.Sh1_CloseJog = true;
						sdc.Sh1_CloseJog = false;
						Thread.Sleep(50);
						sdc.Sh1_CloseJog = true;
						sdc.Sh1_CloseJog = false;
						Thread.Sleep(50);
						sdc.Sh1_OpenJog = true;
						sdc.Sh1_OpenJog = false;
					}
					else if (port == 2)											//check if we are talking to the second port of the sdc
					{
						sdc.Sh2_OpenJog = true;
						sdc.Sh2_OpenJog = false;
						Thread.Sleep(50);
						sdc.Sh2_CloseJog = true;
						sdc.Sh2_CloseJog = false;
						Thread.Sleep(50);
						sdc.Sh2_CloseJog = true;
						sdc.Sh2_CloseJog = false;
						Thread.Sleep(50);
						sdc.Sh2_OpenJog = true;
						sdc.Sh2_OpenJog = false;
					}
					else														//invalid port
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Flick_Warn_Thread: invalid sdc port\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-Flick_Warn_Thread: invalid sdc port\n\r", 5);
					}
				}
				else															//shade hardware offline
				{
					Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Flick_Warn_Thread: shade controller offline\n\r");
					CrestronLogger.WriteToLog("Error: class shade_interface-Flick_Warn_Thread: shade controller offline\n\r", 5);
				}
			}
			else if (type == shade_hardware_type.sdc_dc)						//check if we are connected to an sdc_dc
			{
				if (sdc_dc.IsOnline == true)
				{
					if (port == 1)												//check if we are talking to the first port of the sdc_dc
					{
						sdc_dc.Sh1_OpenJog = true;
						sdc_dc.Sh1_OpenJog = false;
						Thread.Sleep(50);
						sdc_dc.Sh1_CloseJog = true;
						sdc_dc.Sh1_CloseJog = false;
						Thread.Sleep(50);
						sdc_dc.Sh1_CloseJog = true;
						sdc_dc.Sh1_CloseJog = false;
						Thread.Sleep(50);
						sdc_dc.Sh1_OpenJog = true;
						sdc_dc.Sh1_OpenJog = false;
					}
					else if (port == 2)											//check if we are talking to the second port of the sdc_dc
					{
						sdc_dc.Sh2_OpenJog = true;
						sdc_dc.Sh2_OpenJog = false;
						Thread.Sleep(50);
						sdc_dc.Sh2_CloseJog = true;
						sdc_dc.Sh2_CloseJog = false;
						Thread.Sleep(50);
						sdc_dc.Sh2_CloseJog = true;
						sdc_dc.Sh2_CloseJog = false;
						Thread.Sleep(50);
						sdc_dc.Sh2_OpenJog = true;
						sdc_dc.Sh2_OpenJog = false;
					}
					else														//invalid port
					{
						Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Flick_Warn_Thread: invalid sdc_dc port\n\r");
						CrestronLogger.WriteToLog("Error: class shade_interface-Flick_Warn_Thread: invalid sdc_dc port\n\r", 5);
					}
				}
				else															//shade hardware offline
				{
					Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Flick_Warn_Thread: shade controller offline\n\r");
					CrestronLogger.WriteToLog("Error: class shade_interface-Flick_Warn_Thread: shade controller offline\n\r", 5);
				}
			}
			else if (type == shade_hardware_type.qmt50_dccn)					//check if we are connected to an qmt50_dccn
			{
				if (qmt50_dccn.IsOnline == true)
				{

					if (qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Position_FB > shade_jog_increment)//see if we are totally closed
					{	//open then close
						qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Set_Position = (ushort)
							(qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Position_FB + shade_jog_increment);
						Thread.Sleep(100);
						qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Set_Position = (ushort)
							(qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Position_FB - shade_jog_increment);
					}
					else
					{	//close then open
						qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Set_Position = (ushort)
							(qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Position_FB - shade_jog_increment);
						Thread.Sleep(100);
						qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Set_Position = (ushort)
							(qmt50_dccn.CSM_QMT50_DCCN_Shade_Controls_Slot_1.Position_FB + shade_jog_increment);
					}
				}
				else															//shade hardware offline
				{
					Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-stop: shade controller offline\n\r");
					CrestronLogger.WriteToLog("Error: class shade_interface-stop: shade controller offline\n\r", 5);
				}
			}
			else if (type == shade_hardware_type.csc_acex)				//check if we are connected to a csc_acex
			{
				if (csc_acex.IsOnline == true)
				{
					if (csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Position_FB > shade_jog_increment)//see if we are totally closed
					{	//open then close
						csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Set_Position = (ushort)
							(csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Position_FB + shade_jog_increment);
						Thread.Sleep(100);
						csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Set_Position = (ushort)
							(csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Position_FB - shade_jog_increment);
					}
					else
					{	//close then open
						csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Set_Position = (ushort)
							(csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Position_FB - shade_jog_increment);
						Thread.Sleep(100);
						csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Set_Position = (ushort)
							(csc_acex.CSC_ACEX_Shade_Controls_Slot_1.Position_FB + shade_jog_increment);
					}
				}
				else														//shade hardware offline
				{
					Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-flickwarn: shade controller offline\n\r");
					CrestronLogger.WriteToLog("Error: class shade_interface-flickwarn: shade controller offline\n\r", 5);
				}
			}
			else if (type == shade_hardware_type.csc_dcex)				//check if we are connected to a csc_dcex
			{
				if (csc_dcex.IsOnline == true)
				{
					if (csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Position_FB > shade_jog_increment)//see if we are totally closed
					{	//open then close
						csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Set_Position = (ushort)
							(csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Position_FB + shade_jog_increment);
						Thread.Sleep(100);
						csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Set_Position = (ushort)
							(csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Position_FB - shade_jog_increment);
					}
					else
					{	//close then open
						csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Set_Position = (ushort)
							(csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Position_FB - shade_jog_increment);
						Thread.Sleep(100);
						csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Set_Position = (ushort)
							(csc_dcex.CSC_DCEX_Shade_Controls_Slot_1.Position_FB + shade_jog_increment);
					}
				}
				else														//shade hardware offline
				{
					Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-flickwarn: shade controller offline\n\r");
					CrestronLogger.WriteToLog("Error: class shade_interface-flickwarn: shade controller offline\n\r", 5);
				}
			}
			else if (type == shade_hardware_type.csc_drpex)				//check if we are connected to a csc_drpex
			{
				if (csc_drpex.IsOnline == true)
				{
					if (csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Position_FB > shade_jog_increment)//see if we are totally closed
					{	//open then close
						csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Set_Position = (ushort)
							(csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Position_FB + shade_jog_increment);
						Thread.Sleep(100);
						csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Set_Position = (ushort)
							(csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Position_FB - shade_jog_increment);
					}
					else
					{	//close then open
						csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Set_Position = (ushort)
							(csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Position_FB - shade_jog_increment);
						Thread.Sleep(100);
						csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Set_Position = (ushort)
							(csc_drpex.CSC_DRPEX_Drapery_Controls_Slot_1.Position_FB + shade_jog_increment);
					}
				}
				else														//shade hardware offline
				{
					Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-flickwarn: shade controller offline\n\r");
					CrestronLogger.WriteToLog("Error: class shade_interface-flickwarn: shade controller offline\n\r", 5);
				}
			}
			else if (type == shade_hardware_type.csc_accn)					//check if we are connected to an csc_accn
			{
				if (csc_accn.IsOnline == true)
				{

					if (csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Position_FB > shade_jog_increment)//see if we are totally closed
					{	//open then close
						csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Set_Position = (ushort)
							(csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Position_FB + shade_jog_increment);
						Thread.Sleep(100);
						csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Set_Position = (ushort)
							(csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Position_FB - shade_jog_increment);
					}
					else
					{	//close then open
						csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Set_Position = (ushort)
							(csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Position_FB - shade_jog_increment);
						Thread.Sleep(100);
						csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Set_Position = (ushort)
							(csc_accn.CSC_ACCN_Shade_Controls_Slot_1.Position_FB + shade_jog_increment);
					}
				}
				else															//shade hardware offline
				{
					Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-stop: shade controller offline\n\r");
					CrestronLogger.WriteToLog("Error: class shade_interface-stop: shade controller offline\n\r", 5);
				}
			}
			else if (type == shade_hardware_type.csc_dccn)					//check if we are connected to an csc_dccn
			{
				if (csc_dccn.IsOnline == true)
				{

					if (csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Position_FB > shade_jog_increment)//see if we are totally closed
					{	//open then close
						csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Set_Position = (ushort)
							(csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Position_FB + shade_jog_increment);
						Thread.Sleep(100);
						csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Set_Position = (ushort)
							(csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Position_FB - shade_jog_increment);
					}
					else
					{	//close then open
						csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Set_Position = (ushort)
							(csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Position_FB - shade_jog_increment);
						Thread.Sleep(100);
						csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Set_Position = (ushort)
							(csc_dccn.CSC_DCCN_Shade_Controls_Slot_1.Position_FB + shade_jog_increment);
					}
				}
				else															//shade hardware offline
				{
					Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-stop: shade controller offline\n\r");
					CrestronLogger.WriteToLog("Error: class shade_interface-stop: shade controller offline\n\r", 5);
				}
			}
			else if (type == shade_hardware_type.csc_drpcn)					//check if we are connected to an csc_drpcn
			{
				if (csc_drpcn.IsOnline == true)
				{

					if (csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Position_FB > shade_jog_increment)//see if we are totally closed
					{	//open then close
						csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Set_Position = (ushort)
							(csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Position_FB + shade_jog_increment);
						Thread.Sleep(100);
						csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Set_Position = (ushort)
							(csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Position_FB - shade_jog_increment);
					}
					else
					{	//close then open
						csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Set_Position = (ushort)
							(csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Position_FB - shade_jog_increment);
						Thread.Sleep(100);
						csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Set_Position = (ushort)
							(csc_drpcn.CSC_DRPCN_Drapery_Controls_Slot_1.Position_FB + shade_jog_increment);
					}
				}
				else															//shade hardware offline
				{
					Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-stop: shade controller offline\n\r");
					CrestronLogger.WriteToLog("Error: class shade_interface-stop: shade controller offline\n\r", 5);
				}
			}
			else																//unsupported hardware
			{
				Crestron.SimplSharp.ErrorLog.Error("Error: class shade_interface-Flick_Warn_Thread: invalid hardware type\n\r");
				CrestronLogger.WriteToLog("Error: class shade_interface-Flick_Warn_Thread: invalid hardware type\n\r", 5);
			}
			return null;
		}
		#endregion
	}
}