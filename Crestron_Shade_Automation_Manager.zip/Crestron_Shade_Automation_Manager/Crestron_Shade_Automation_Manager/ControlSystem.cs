﻿/*
 * All code (c)2012 Jay Basen all rights reserved
 */
using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using Crestron.SimplSharp;
using Crestron.SimplSharp.CrestronThread;										// For Threading
using Crestron.SimplSharp.CrestronIO;											// For File I/O
using Crestron.SimplSharp.CrestronSockets;										// For Sockets
using Crestron.SimplSharp.CrestronXml;
using Crestron.SimplSharp.CrestronXmlLinq;
using Crestron.SimplSharp.CrestronLogger;
using Crestron_Shade_Automation_Manager;

namespace Shade_Automation_Manager
{
	#region enum
	public enum modes { off, heat, cool, auto };								//hvac modes

	public enum actions
	{
		none,								//no action to take
		sun_open_full,						//fully open shade based on sun angle calculation
		sun_close_full,						//fully close shade based on sun angle calculation
		schedule_open_full,					//fully open shade based on scheduled event
		schedule_close_full,				//fully close shade based on scheduled event
		schedule_unlock,					//set that shade can be returned to automated operation after scheduled operations
		manual_open_full,					//fully open shade based on manual operation
		manual_close_full,					//fully close shade based on manaual operation
		manual_open,						//open shade based on manual operation
		manual_close,						//close shade based on manual operation
		manual_stop,						//stop shade motion based on manual operation
		manual_unlock,						//set that shade can be returned to automated operation after manual operations
		away_close							//close when away or vacation flag set
	};
																				
	public enum options 
	{
		undefined,							//no option defined
		none,								//no automated movements of shade
		energy_save_optimal,				//open/close shade to take advantage of the sun but close for insulation whenever possible
		energy_save_aesthetics,				//open/close shade to take advantage of the sun but open for view whenever possible
		art_save_optimal,					//close whenever sun on window, otherwise open whether it is cloudy or not
		art_save_aesthetics					//close whenever sun on window, otherwise close if it is sunny and open if cloudy
	};
																				
	public enum shade_hardware_type { sdc, sdc_dc, qmt50_dccn, csc_acex, csc_dcex, 
		csc_drpex, csc_accn, csc_dccn, csc_drpcn};

	public enum group_preference { all_open, all_close };
	#endregion

	public class Shade_Automation_Manager : CrestronControlSystem
	{
		#region Declarations
		private Thread ConnectThread;
		double forecast_high_temperature = 72;
		CTimer one_am_timer = null;
		CTimer sunrise_timer = null;
		CTimer sunset_timer = null;
		bool System_Running = false;											//true after system is up and running in steady state

		//constants
		const double radians = Math.PI / 180;
		const long day_in_milliseconds = 86400000;								//24 hours * 60 minutes * 60 seconds * 1000 msec
		const double thermostat_deadband = 2;
		const string xml_data_file = "\\RM\\Main\\shade_data.xml";
		

		double latitude, longitude;

		#endregion

		#region Methods
		//****************************************************************************************
		// 
		//  Shade_Automation_Manager	-	Constructor
		// 
		//****************************************************************************************
		public Shade_Automation_Manager()
			: base()
		{
			Thread.MaxNumberOfUserThreads = 100;

			#region Logging
			//setup logging
			try
			{
				CrestronLogger.Initialize(7);
			}
			catch (Exception e)
			{
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Shade_Automation_Manager-LoggerError: " + e + "\n\r"));
			}
			#endregion

			#region Gateway
			try
			{
				if (this.SupportsInternalRFGateway)										//Check if the control system includes an ex gateway
				{
				}
			}
			catch (Exception e)
			{
				CrestronLogger.WriteToLog(string.Format("Shade_Automation_Manager-SDC Setup: " + e + "\n\r"), 0);
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Shade_Automation_Manager-SDC Setup: " + e + "\n\r"));
			}
			#endregion

			#region Ethernet
			//create EISC
			if (this.SupportsEthernet)
			{
				Variables.EISC_TO_SIMPL = new Ethernet_Intersystem_Communications(0x6, "127.0.0.2", this);
				if (Variables.EISC_TO_SIMPL.Register() == DeviceRegistrationUnRegistrationResponse.Success)
				{
					//Successful registration
					Variables.EISC_TO_SIMPL.OnSignalChange += new JoinChangeEvent(EISC_OnSignalChange);
				}
				else
				{
					//Registration failed for some reason
					Crestron.SimplSharp.ErrorLog.Error(string.Format("Unable to Register EISC MC3: {0}", Variables.EISC_TO_SIMPL.DeviceRegistrationFailureString));
				}
			}
			#endregion

			#region Cresnet
			//SDC Setup
			try
			{
				if (this.SupportsCresnet)										//Check if the control system supports Cresnet
				{
				}
			}
			catch (Exception e)
			{
				CrestronLogger.WriteToLog(string.Format("Shade_Automation_Manager-SDC Setup: " + e + "\n\r"), 0);
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Shade_Automation_Manager-SDC Setup: " + e + "\n\r"));
			}
			#endregion

			#region Console_Commands
			Variables.Add_Console_Commands();
			#endregion
		}

		//****************************************************************************************
		// 
		//  InitializeSystem	-	System Initialization
		// 
		//****************************************************************************************
		public override void InitializeSystem()
		{

			#region Start Main Worker Thread
			//start the shade management system main worker thread
			try
			{
				ConnectThread = new Thread(Main_Worker_Thread, null, Thread.ThreadStartOptions.CreateSuspended);
				ConnectThread.Start();
			}
			catch (Exception e)
			{
				CrestronLogger.WriteToLog(string.Format("Shade_Automation_Manager-Can't create main worker thread: " + e + "\n\r"), 0);
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Shade_Automation_Manager-Can't create main worker thread: " + e + "\n\r"));
			}
			#endregion

			return;
		}

		//****************************************************************************************
		// 
		//  EISC_OnSignalChange	-	EISC Change Manager
		// 
		//****************************************************************************************
		void EISC_OnSignalChange(CrestronDevice currentDevice, SignalEventArgs args)
		{
			if (currentDevice == Variables.EISC_TO_SIMPL)
			{
				//Determine if the join is digital or analog.
				switch (args.JoinSignalType)
				{
					case (SignalTypeEnum.Digital):
						//Check if the digital join experienced a rising or falling event.
						switch (args.JoinNumber)
						{
							case (1):											//set/clear party flag
								if (args.DigitalValue == true)					//Press
								{
									Variables.Set_Party_Flag();					//set that party in progress
								}
								else
								{
									Variables.Clear_Party_Flag();				//set that party has ended
									if (System_Running == true)					//only do this after system is up and running
									{
										foreach (room rm in Variables.room_data)//loop through each room
										{
											rm.Restore_Shades_After_Party_or_Away();
										}
									}
									else
									{
										CrestronLogger.WriteToLog("EISC: Party Flag set/reset - System not running yet\n\r", 5);
									}
								}
								break;

							case (2):											//set/clear cloudy flag
								if (args.DigitalValue == true)					//Press
								{
									Variables.cloudy = true;					//set that it is cloudy outside
								}
								else											//Release
								{
									Variables.cloudy = false;					//set that it is clear
								}

								if (System_Running == true)						//only do this after system is up and running
								{
									foreach (room rm in Variables.room_data)	//loop through all the rooms
									{
										Room_Temperature_Or_Setpoint_Change(rm);//update shade automation
									}
								}
								else
								{
									CrestronLogger.WriteToLog("EISC: cloudy/sunny - System not running yet\n\r", 5);
								}
								break;

							case (3):											//set/clear away flag
								if (args.DigitalValue == true)					//Press
								{
									Variables.Set_Away_Flag();					//set that alarm system in away mode
									if (System_Running == true)
									{
										close_shades_when_away();				//close shades in rooms set to for closure
									}
								}
								else											//Release
								{
									Variables.Clear_Away_Flag();				//set that it is clear
									if (System_Running == true)					//only do this after system is up and running
									{
										foreach (room rm in Variables.room_data)//loop through each room
										{
											rm.Restore_Shades_After_Party_or_Away();
										}
									}
									else
									{
										CrestronLogger.WriteToLog("EISC: Party Flag set/reset - System not running yet\n\r", 5);
									}
								}
								break;

							case (4):											//set/clear vacation flag
								if (args.DigitalValue == true)					//Press
								{
									Variables.Set_Vacation_Flag();				//set that homeowners are away
									if (System_Running == true)
									{
										close_shades_when_away();				//close shades in rooms set to for closure
									}
								}
								else											//Release
								{
									Variables.Clear_Vacation_Flag();			//set that it is clear
									if (System_Running == true)					//only do this after system is up and running
									{
										foreach (room rm in Variables.room_data)//loop through each room
										{
											rm.Restore_Shades_After_Party_or_Away();
										}
									}
									else
									{
										CrestronLogger.WriteToLog("EISC: Party Flag set/reset - System not running yet\n\r", 5);
									}
								}
								break;
						}
						break;

					case (SignalTypeEnum.Analog):
						switch (args.JoinNumber)
						{
							case (1):
								forecast_high_temperature = args.AnalogValue;
								CrestronLogger.WriteToLog("forecast_high_temperature: " + forecast_high_temperature + "\n\r", 5);
								if (System_Running == true)						//only do this after system is up and running
								{
									foreach (room rm in Variables.room_data)	//loop through all the rooms
									{
										Room_Temperature_Or_Setpoint_Change(rm);//update shade automation
									}
								}
								else
								{
									CrestronLogger.WriteToLog("EISC: Temperature Change - System not running yet\n\r", 5);
								}
								break;

							default:											//if there isn't a specific case then this is thermostat mode, temp or sp change
								CrestronLogger.WriteToLog("EISC - temp or setpoint change - join:" + args.JoinNumber + "\n\r", 5);
								Analog_Join_Change_Manager(args.JoinNumber, args.AnalogValue);
								break;
						}
						break;

					case (SignalTypeEnum.Serial):
						switch (args.JoinNumber)
						{
							case (1):
								//parse and act on commands for manual control, motion detector movement in rooms, etc.
								if (System_Running == true)						//only do this after system is up and running
								{
									Parse_Commands(args.SerialValue);
								}
								else
								{
									CrestronLogger.WriteToLog("EISC: Command Received - System not running yet\n\r", 5);
								}
								break;
						}
						break;
				 }
			}
		}

		//****************************************************************************************
		// 
		//  Analog_Join_Change_Manager	-	Handler for console command
		// 
		//****************************************************************************************
		void Analog_Join_Change_Manager(uint join_number, uint value)
		{
			//don't act on data until system is up and running in a steady state
			if (System_Running == false)
			{
				return;
			}

			foreach (room rm in Variables.room_data)							//look through each room
			{
				if (rm.temperature_join == join_number)							//see if the join that changed was for the temperature for this room
				{
					if (rm.Get_Room_Temperature() != value)						//check if the value is actually different
					{
						rm.Set_Room_Temperature((int) value);					//save the new value

						if (System_Running == true)								//only do this after system is up and running
						{
							Room_Temperature_Or_Setpoint_Change(rm);			//update shade automation
						}
						else
						{
							CrestronLogger.WriteToLog("EISC: Setpoint Change - System not running yet\n\r", 5);
						}
					}
				}
				else if (rm.setpoint_join == join_number)						//see if the join that changed was for the setpoint for this room
				{
					if (rm.Get_Room_Setpoint() != value)						//check if the value is actually different
					{
						rm.Set_Room_Setpoint((int)value);						//save the new value

						if (System_Running == true)								//only do this after system is up and running
						{
							Room_Temperature_Or_Setpoint_Change(rm);			//update shade automation
						}
						else
						{
							CrestronLogger.WriteToLog("EISC: Setpoint Change - System not running yet\n\r", 5);
						}
					}
				}
				else if (rm.thermostat_mode_join == join_number)				//see if the join that changed was for the mode for this room
				{
					modes m = Variables.Int_To_Mode(value);
					if (rm.Get_Room_Thermostat_Mode() != m)
					{
						rm.Set_Room_Thermostat_Mode(m);

						if (System_Running == true)								//only do this after system is up and running
						{
							Room_Temperature_Or_Setpoint_Change(rm);			//update shade automation
						}
						else
						{
							CrestronLogger.WriteToLog("EISC: Thermostat mode Change - System not running yet\n\r", 5);
						}
					}
				}
				else
				{
					continue;
				}
			}
		}

		//****************************************************************************************
		// 
		//  Main_Worker_Thread	-	Primary thread evaluating sun angle vs shades
		// 
		//****************************************************************************************
		private object Main_Worker_Thread(object unused)
		{
			double azimuth, elevation;
			Boolean daytime;

			CurrentThread.Priority = Thread.ThreadPriority.LowestPriority;

			//delay one minute to let simplwin program get going and for thermostat data, etc.
			//to be valid
			Thread.Sleep(60 * 1000);

			//create shade group list
			Shade_Group.Create_Group_List();

			#region Read XML and Schedule Timers
			//Allocate memory for timer list
			try
			{
				Variables.timer_list = new List<timer_data>();
			}
			catch (Exception e)
			{
				CrestronLogger.WriteToLog(string.Format("Shade_Automation_Manager alloate Timer_List: " + e + "\n\r"), 0);
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Shade_Automation_Manager alloate Timer_List: " + e + "\n\r"));
			}

			//read data from xml file
			try
			{
				Read_XML_Data();
			}
			catch (Exception e)
			{
				CrestronLogger.WriteToLog(string.Format("Shade_Automation_Manager read_xml_data: " + e + "\n\r"), 0);
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Shade_Automation_Manager read_xml_data: " + e + "\n\r"));
			}

			//Parse actions from the XML file and schedule timers
			try
			{
				foreach (shade sh in Variables.shade_data)
				{
					Parse_Shade_Action_Times(sh);
				}
			}
			catch (Exception e)
			{
				CrestronLogger.WriteToLog(string.Format("Shade_Automation_Manager parse_shade_action_times: " + e + "\n\r"), 0);
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Shade_Automation_Manager parse_shade_action_times: " + e + "\n\r"));
			}

			//Schedule Sunrise, Sunset Timers, and Midnight Timers
			try
			{
				Schedule_Sunrise_Sunset_Timers(DateTime.Now, latitude, longitude);
				Schedule_One_AM_Timer();

			}
			catch (Exception e)
			{
				CrestronLogger.WriteToLog(string.Format("Shade_Automation_Manager Schedule_Sunrise_Sunset_Timers: " + e + "\n\r"), 0);
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Shade_Automation_Manager Schedule_Sunrise_Sunset_Timers: " + e + "\n\r"));
			}
			#endregion

			#region Start Timer Thread
			//start the thread that checks and executes the timers
			try
			{
				ConnectThread = new Thread(Timer_Thread, null, Thread.ThreadStartOptions.CreateSuspended);
				ConnectThread.Start();
			}
			catch (Exception e)
			{
				CrestronLogger.WriteToLog(string.Format("Shade_Automation_Manager-Can't create timer thread: " + e + "\n\r"), 0);
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Shade_Automation_Manager-Can't create timer thread: " + e + "\n\r"));
			}
			#endregion

			//Set that system is up and running in steady state
			System_Running = true;

			while (true)
			{
				CrestronLogger.WriteToLog("\n\r\n\r", 5);
				CrestronLogger.WriteToLog("Thread1 Loop\n\r\n\r", 5);

				//calculate angle to the sun
				try
				{
					Sun_Angle_Calc(latitude, longitude, out daytime, out azimuth, out elevation);

					//loop through all shades and compare to sun angle
					if (daytime == true)										//only perform evaluation during daytime
					{
						foreach (shade sh in Variables.shade_data)
						{
							CrestronLogger.WriteToLog("\n\r\n\r", 5);
							sh.group_action = actions.none;						//clear group action before evaluating what to do
							Evaluate_Shade_Action(sh, azimuth, elevation);		//decide if shade should be opened or closed
						}
						Shade_Group.evaluate_group_actions();					//perform shade movements for groups.
					}
					else
					{
						CrestronLogger.WriteToLog("\n\r\n\r", 5);
						CrestronLogger.WriteToLog("Night - no angle/elevation evaluation\n\r", 5);
					}
				}
				catch (Exception e)
				{
					Crestron.SimplSharp.ErrorLog.Error(string.Format("Thread1: " + e + "\n\r"));
					CrestronLogger.WriteToLog("Thread1: " + e + "\n\r", 0);
					continue;
				}

				//add extra blank line for clarity
				CrestronLogger.WriteToLog("\n\r\n\r", 5);

				//delay for 15 minutes and then repeat
				Thread.Sleep(15 * 60 * 1000);
				//Thread.Sleep(60 * 1000);//tester 1 minute
			}
		}

		//****************************************************************************************
		// 
		//  Read_XML_Data - read configuration data from xml file
		// 
		//****************************************************************************************
		private void Read_XML_Data()
		{
			SimplSharpString s;
			int i;
			int ex_gateway_count = 0;
			int c2n_sdc_count = 0; 
			int c2n_sdc_dc_count = 0;
			int csm_qmt50_dccn_count = 0;
			int csc_acex_count = 0;
			int csc_dcex_count = 0;
			int csc_drpex_count = 0;
			int csc_accn_count = 0;
			int csc_dccn_count = 0;
			int csc_drpcn_count = 0;
			XElement c2n_sdc_hw = null;
			XElement c2n_sdc_dc_hw = null;
			XElement csm_qmt50_dccn_hw = null;
			XElement csc_acex_hw = null;
			XElement csc_dcex_hw = null;
			XElement csc_drpex_hw = null;
			XElement csc_accn_hw = null;
			XElement csc_dccn_hw = null;
			XElement csc_drpcn_hw = null;
			XElement ex_gateway_hw = null;

			try
			{
				CrestronLogger.WriteToLog("Read_XML_Data: Reading XML Data File\n\r", 7);

				//open xml file
				XDocument doc;
				FileStream fs = new FileStream(xml_data_file, FileMode.Open, FileAccess.Read);
				XmlReader xr = new XmlReader(fs);
				xr.MoveToContent();
				doc = XDocument.Load(xr);

				#region Read General Information
				XElement generalElement = doc
					.Element("ShadeInformation")
					.Element("GeneralInformation");

				latitude = Convert.ToDouble(generalElement.Element("latitude").Value);
				CrestronLogger.WriteToLog("Read_XML_Data: latitude = " + latitude + "\n\r", 7);
	
				longitude = Convert.ToDouble(generalElement.Element("longitude").Value);
				CrestronLogger.WriteToLog("Read_XML_Data: longitude = " + longitude + "\n\r", 7);

				Variables.magnetic_declination_degrees = Convert.ToDouble(generalElement.Element("magnetic_declination_degrees").Value);
				CrestronLogger.WriteToLog("Read_XML_Data: magnetic_declination_degrees = " + Variables.magnetic_declination_degrees + "\n\r", 7);

				Variables.default_room_setpoint = Convert.ToInt32(generalElement.Element("default_room_setpoint").Value);
				CrestronLogger.WriteToLog("Read_XML_Data: default_room_setpoint = " + Variables.default_room_setpoint + "\n\r", 7);

				Variables.default_room_temperature = Convert.ToInt32(generalElement.Element("default_room_temperature").Value);
				CrestronLogger.WriteToLog("Read_XML_Data: default_room_temperature = " + Variables.default_room_temperature + "\n\r", 7);

				Variables.feet_into_room_for_glare = Convert.ToDouble(generalElement.Element("feet_into_room_for_glare").Value);
				CrestronLogger.WriteToLog("Read_XML_Data: feet_into_room_for_glare = " + Variables.feet_into_room_for_glare + "\n\r", 7);

				Variables.glare_azimuth = Convert.ToDouble(generalElement.Element("glare_azimuth").Value);
				CrestronLogger.WriteToLog("Read_XML_Data: glare_azimuth = " + Variables.glare_azimuth + "\n\r", 7);

				Variables.preference = Variables.To_Group_Preference(generalElement.Element("group_preference").Value);
				CrestronLogger.WriteToLog("Read_XML_Data: option = " + Variables.preference + "\n\r", 7);

				#endregion

				#region Count Shade Hardware to allocate interfaces
				//first we have to count the number of shade hardware devices so
				//we can allocate memory for them
				if (this.SupportsEthernet)										//Check if the control system supports Ethernet
				{
					#region EX_GATEWAY
					//Find root element for ex gateway hardware infomation
					ex_gateway_hw = doc
						.Element("ShadeInformation")
						.Element("Hardware")
						.Element("cen_rfgw_ex");

					//Count the number of ex gateways in the file
					if (ex_gateway_hw != null)
					{
						ex_gateway_count = ex_gateway_hw.Elements().Count();
						CrestronLogger.WriteToLog("Read_XML_Data: cen_rfgw_ex = " + ex_gateway_count + "\n\r", 7);
					}
					else
					{
						ex_gateway_count = 0;
					}
					#endregion

					#region CSC_ACEX
					//Find root element for csc_acex hardware infomation
					csc_acex_hw = doc
						.Element("ShadeInformation")
						.Element("Hardware")
						.Element("csc_acex");

					//Count the number of shade controllers in the file
					if (csc_acex_hw != null)
					{
						csc_acex_count = csc_acex_hw.Elements().Count();
						CrestronLogger.WriteToLog("Read_XML_Data: csc_acex = " + csc_acex_count + "\n\r", 7);
					}
					else
					{
						csc_acex_count = 0;
					}
					#endregion

					#region CSC_DCEX
					//Find root element for csc_acex hardware infomation
					csc_dcex_hw = doc
						.Element("ShadeInformation")
						.Element("Hardware")
						.Element("csc_dcex");

					//Count the number of shade controllers in the file
					if (csc_dcex_hw != null)
					{
						csc_dcex_count = csc_dcex_hw.Elements().Count();
						CrestronLogger.WriteToLog("Read_XML_Data: csc_dcex = " + csc_dcex_count + "\n\r", 7);
					}
					else
					{
						csc_dcex_count = 0;
					}
					#endregion

					#region CSC_DRPEX
					//Find root element for csc_acex hardware infomation
					csc_drpex_hw = doc
						.Element("ShadeInformation")
						.Element("Hardware")
						.Element("csc_drpex");

					//Count the number of shade controllers in the file
					if (csc_drpex_hw != null)
					{
						csc_drpex_count = csc_drpex_hw.Elements().Count();
						CrestronLogger.WriteToLog("Read_XML_Data: csc_drpex = " + csc_drpex_count + "\n\r", 7);
					}
					else
					{
						csc_drpex_count = 0;
					}
					#endregion

					//TODO: Add Support for other ethernet hardware types here
				}

				if (this.SupportsCresnet)										//Check if the control system supports Cresnet
				{
					#region C2N_SDC
					//Find root element for c2n-sdc hardware infomation
					c2n_sdc_hw = doc
						.Element("ShadeInformation")
						.Element("Hardware")
						.Element("c2n_sdc");

					//Count the number of shade controllers in the file
					if (c2n_sdc_hw != null)
					{
						c2n_sdc_count = c2n_sdc_hw.Elements().Count();
						CrestronLogger.WriteToLog("Read_XML_Data: c2n_sdc_count = " + c2n_sdc_count + "\n\r", 7);
					}
					else
					{
						c2n_sdc_count = 0;
					}
					#endregion

					#region C2N_SDC_DC
					//Find root element for c2n-sdc-dc hardware infomation
					c2n_sdc_dc_hw = doc
						.Element("ShadeInformation")
						.Element("Hardware")
						.Element("c2n_sdc_dc");

					//Count the number of shade controllers in the file
					if (c2n_sdc_dc_hw != null)
					{
						c2n_sdc_dc_count = c2n_sdc_dc_hw.Elements().Count();
						CrestronLogger.WriteToLog("Read_XML_Data: c2n_sdc_dc_count = " + c2n_sdc_dc_count + "\n\r", 7);
					}
					else
					{
						c2n_sdc_dc_count = 0;
					}
					#endregion

					#region CSM_QMT50_DCCN
					//Find root element for csm_qmt50_dccn hardware infomation
					csm_qmt50_dccn_hw = doc
						.Element("ShadeInformation")
						.Element("Hardware")
						.Element("csm_qmt50_dccn");

					//Count the number of shade controllers in the file
					if (csm_qmt50_dccn_hw != null)
					{
						csm_qmt50_dccn_count = csm_qmt50_dccn_hw.Elements().Count();
						CrestronLogger.WriteToLog("Read_XML_Data: csm_qmt50_dccn_count = " + csm_qmt50_dccn_count + "\n\r", 7);
					}
					else
					{
						csm_qmt50_dccn_count = 0;
					}
					#endregion

					#region CSC_ACCN
					//Find root element for csc_accn hardware infomation
					csc_accn_hw = doc
						.Element("ShadeInformation")
						.Element("Hardware")
						.Element("csc_accn");

					//Count the number of shade controllers in the file
					if (csc_accn_hw != null)
					{
						csc_accn_count = csc_accn_hw.Elements().Count();
						CrestronLogger.WriteToLog("Read_XML_Data: csc_accn_count = " + csc_accn_count + "\n\r", 7);
					}
					else
					{
						csc_accn_count = 0;
					}
					#endregion

					#region CSC_DCCN
					//Find root element for csc_dccn hardware infomation
					csc_dccn_hw = doc
						.Element("ShadeInformation")
						.Element("Hardware")
						.Element("csc_dccn");

					//Count the number of shade controllers in the file
					if (csc_dccn_hw != null)
					{
						csc_dccn_count = csc_dccn_hw.Elements().Count();
						CrestronLogger.WriteToLog("Read_XML_Data: csc_dccn_count = " + csc_dccn_count + "\n\r", 7);
					}
					else
					{
						csc_dccn_count = 0;
					}
					#endregion

					#region CSC_DRPCN
					//Find root element for csc_drpcn hardware infomation
					csc_drpcn_hw = doc
						.Element("ShadeInformation")
						.Element("Hardware")
						.Element("csc_drpcn");

					//Count the number of shade controllers in the file
					if (csc_drpcn_hw != null)
					{
						csc_drpcn_count = csc_drpcn_hw.Elements().Count();
						CrestronLogger.WriteToLog("Read_XML_Data: csc_drpcn_count = " + csc_drpcn_count + "\n\r", 7);
					}
					else
					{
						csc_drpcn_count = 0;
					}
					#endregion

					//TODO: Add Support for other cresnet hardware types here
				}

				//allocate memory for the shade interfaces based on the amount of hardware found
				int shade_interface_count = (c2n_sdc_count * 2) + (c2n_sdc_dc_count * 2)
					+ csm_qmt50_dccn_count + csc_acex_count + csc_dcex_count + csc_drpex_count
					+ csc_accn_count + csc_dccn_count + csc_drpcn_count;
				Variables.shade_hw = new shade_interface[shade_interface_count];//each sdc can control 2 shades
				#endregion

				#region Setup hardware interfaces
				if (this.SupportsEthernet)										//Check if the control system supports Ethernet
				{
					#region EX_GATEWAY
					if (ex_gateway_count > 0)
					{
						Variables.gateway_data = new gateway[ex_gateway_count];	//create the memory to hold the data

						//Create the list
						IEnumerable<XElement> ex_gateway_list = ex_gateway_hw.Elements();

						i = 0;													//set to first array entry
						foreach (XElement ex_gateway_device in ex_gateway_list)	//loop through xml elements
						{
							//read id from xml file
							s = ex_gateway_device.Element("id").Value;				//read id from xml
							uint adr = Convert.ToUInt32(s.ToString(), 16);			//parse hex value in the string

							s = ex_gateway_device.Element("name").Value;			//read the name from the xml

							//Create an instance of gateway
							Ethernet_CEN_RFGW_EX ex = new Ethernet_CEN_RFGW_EX(adr, this);

							CrestronLogger.WriteToLog("gateway i = " + i + " id = " + adr + " name = " + s.ToString() + "\n\r", 7);

							//Register the device or mark an error in the control system's log if registration fails.
							if (ex.Register() == DeviceRegistrationUnRegistrationResponse.Success)
							{
								Variables.gateway_data[i] = new gateway(ex, s.ToString());//create ex gateway
								CrestronLogger.WriteToLog("registered gateway i = " + i + " id = " + Variables.gateway_data[i].id +
									" name = " + Variables.gateway_data[i].name + "\n\r", 7);
							}
							else
							{
								Crestron.SimplSharp.ErrorLog.Error(String.Format("Failed to register device at IPID {0:X2}", ex.ID));
							}

							i++;												//next device
						}
					}
					#endregion

					#region CSC_ACEX
					if (csc_acex_count > 0)										//check if there were any of these hardware inerfaces
					{															//in the xml file
						//Create the memory to hold the data
						Variables.csc_acex = new RF_CSC_ACEX[csc_acex_count];

						//Create the list
						IEnumerable<XElement> csc_acex_list = csc_acex_hw.Elements();

						i = 0;													//set to first array entry
						foreach (XElement csc_acex_device in csc_acex_list)		//loop through xml elements
						{
							//read id from xml file
							s = csc_acex_device.Element("id").Value;			//read id from xml
							uint adr = Convert.ToUInt32(s.ToString(), 16);		//parse hex value in the string

							s = csc_acex_device.Element("gateway").Value.ToLower();//get gateway name

							if (s.ToString() == "internal")
							{
								if (this.SupportsInternalRFGateway)
								{
									CrestronLogger.WriteToLog("adding CSC_ACEX id " + adr + " to internal gateway\n\r", 7);
									Variables.csc_acex[i] = new RF_CSC_ACEX(adr, this);
									Variables.shade_hw[i] = new shade_interface(Variables.csc_acex[i]);//create shade interface to shade
								}
								else
								{
									Crestron.SimplSharp.ErrorLog.Error(String.Format("Can't create CSC_ACEX ID {0:X2} - specified to attach to internal gateway on processor without one\r\n", adr));
								}
							}
							else
							{
								gateway gw = find_gateway(s.ToString());		//search for gateway by name
								if (gw == null)									//check if gateway not in list
								{
									Crestron.SimplSharp.ErrorLog.Error(String.Format("Unable to locate gateway " + s.ToString() + " for csc_acex ID {0:X2}", Variables.csc_acex[i].ID));
								}
								else
								{
									CrestronLogger.WriteToLog("adding CSC_ACEX id " + adr + " to gateway " + gw.id + "\n\r", 7);
									Variables.csc_acex[i] = new RF_CSC_ACEX(adr, gw.get_gateway());
									Variables.shade_hw[i] = new shade_interface(Variables.csc_acex[i]);//create shade interface to shade
								}
							}
							i++;												//next device
						}
					}
					#endregion

					#region CSC_DCEX
					if (csc_dcex_count > 0)										//check if there were any of these hardware inerfaces
					{															//in the xml file
						//Create the memory to hold the data
						Variables.csc_dcex = new RF_CSC_DCEX[csc_dcex_count];

						//Create the list
						IEnumerable<XElement> csc_dcex_list = csc_dcex_hw.Elements();

						i = 0;													//set to first array entry
						foreach (XElement csc_dcex_device in csc_dcex_list)		//loop through xml elements
						{
							//read id from xml file
							s = csc_dcex_device.Element("id").Value;			//read id from xml
							uint adr = Convert.ToUInt32(s.ToString(), 16);		//parse hex value in the string

							s = csc_dcex_device.Element("gateway").Value.ToLower();//get gateway name
							if (s.ToString() == "internal")
							{
								if (this.SupportsInternalRFGateway)
								{
									CrestronLogger.WriteToLog("adding CSC_DCEX id " + adr + " to internal gateway\n\r", 7);
									Variables.csc_dcex[i] = new RF_CSC_DCEX(adr, this);
									Variables.shade_hw[i] = new shade_interface(Variables.csc_dcex[i]);//create shade interface to shade
								}
								else
								{
									Crestron.SimplSharp.ErrorLog.Error(String.Format("Can't create CSC_DCEX ID {0:X2} - specified to attach to internal gateway on processor without one\r\n", adr));
								}
							}
							else
							{
								gateway gw = find_gateway(s.ToString());		//search for gateway by name
								if (gw == null)									//check if gateway not in list
								{
									Crestron.SimplSharp.ErrorLog.Error(String.Format("Unable to locate gateway " + s.ToString() + " for csc_dcex ID {0:X2}", Variables.csc_dcex[i].ID));
								}
								else
								{
									CrestronLogger.WriteToLog("adding CSC_DCEX id " + adr + " to gateway " + gw.id + "\n\r", 7);
									Variables.csc_dcex[i] = new RF_CSC_DCEX(adr, gw.get_gateway());
									Variables.shade_hw[i] = new shade_interface(Variables.csc_dcex[i]);//create shade interface to shade
								}
							}
							i++;												//next device
						}
					}
					#endregion

					#region CSC_DRPEX
					if (csc_drpex_count > 0)										//check if there were any of these hardware inerfaces
					{															//in the xml file
						//Create the memory to hold the data
						Variables.csc_drpex = new RF_CSC_DRPEX[csc_drpex_count];

						//Create the list
						IEnumerable<XElement> csc_drpex_list = csc_drpex_hw.Elements();

						i = 0;													//set to first array entry
						foreach (XElement csc_drpex_device in csc_drpex_list)		//loop through xml elements
						{
							//read id from xml file
							s = csc_drpex_device.Element("id").Value;			//read id from xml
							uint adr = Convert.ToUInt32(s.ToString(), 16);		//parse hex value in the string

							s = csc_drpex_device.Element("gateway").Value.ToLower();//get gateway name
							if (s.ToString() == "internal")
							{
								if (this.SupportsInternalRFGateway)
								{
									CrestronLogger.WriteToLog("adding CSC_DRPEX id " + adr + " to internal gateway\n\r", 7);
									Variables.csc_drpex[i] = new RF_CSC_DRPEX(adr, this);
									Variables.shade_hw[i] = new shade_interface(Variables.csc_drpex[i]);//create shade interface to shade
								}
								else
								{
									Crestron.SimplSharp.ErrorLog.Error(String.Format("Can't create CSC_DRPEX ID {0:X2} - specified to attach to internal gateway on processor without one\r\n", adr));
								}
							}
							else
							{
								gateway gw = find_gateway(s.ToString());		//search for gateway by name
								if (gw == null)									//check if gateway not in list
								{
									Crestron.SimplSharp.ErrorLog.Error(String.Format("Unable to locate gateway " + s.ToString() + " for csc_drpex ID {0:X2}", Variables.csc_drpex[i].ID));
								}
								else
								{
									CrestronLogger.WriteToLog("adding CSC_DRPEX id " + adr + " to gateway " + gw.id + "\n\r", 7);
									Variables.csc_drpex[i] = new RF_CSC_DRPEX(adr, gw.get_gateway());
									Variables.shade_hw[i] = new shade_interface(Variables.csc_drpex[i]);//create shade interface to shade
								}
							}
							i++;												//next device
						}
					}
					#endregion

					//TODO: Add Support for other ethernet hardware types here
				}

				if (this.SupportsCresnet)										//Check if the control system supports Cresnet
				{
					#region C2N-SDC
					if (c2n_sdc_count > 0)										//Check if there were any of these hardware interfaces
					{															//in the xml file
						//Create the memory to hold the data
						Variables.c2n_sdc = new Cresnet_C2N_SDC[c2n_sdc_count];

						//Create the list
						IEnumerable<XElement> c2n_sdc_list = c2n_sdc_hw.Elements();

						i = 0;													//set to first array entry
						foreach (XElement c2n_sdc_device in c2n_sdc_list)		//loop through xml elements
						{
							//read id from xml file
							s = c2n_sdc_device.Element("id").Value;				//read id from xml
							uint adr = Convert.ToUInt32(s.ToString(), 16);		//parse hex value in the string

							//Create an instance of device at specfied Cresent id
							Variables.c2n_sdc[i] = new Cresnet_C2N_SDC(adr, this);

							//Register the device or mark an error in the control system's log if registration fails.
							if (Variables.c2n_sdc[i].Register() == DeviceRegistrationUnRegistrationResponse.Success)
							{
								Variables.shade_hw[i * 2] = new shade_interface(Variables.c2n_sdc[i], 1);//create shade interface to shade on port 1 of sdc
								Variables.shade_hw[(i * 2) + 1] = new shade_interface(Variables.c2n_sdc[i], 2);//create shade interface to shade on port 2 of sdc
							}
							else
							{
								Crestron.SimplSharp.ErrorLog.Error(String.Format("Failed to register device at ID {0:X2}", Variables.c2n_sdc[i].ID));
							}

							i++;												//next device
						}
					}
					#endregion

					#region C2N-SDC-DC
					if (c2n_sdc_dc_count > 0)									//check if there were any of these hardware inerfaces
					{															//in the xml file
						//Create the memory to hold the data
						Variables.c2n_sdc_dc = new Cresnet_C2N_SDC_DC[c2n_sdc_dc_count];

						//Create the list
						IEnumerable<XElement> c2n_sdc_dc_list = c2n_sdc_dc_hw.Elements();

						i = 0;													//set to first array entry
						foreach (XElement c2n_sdc_dc_device in c2n_sdc_dc_list)	//loop through xml elements
						{
							//read id from xml file
							s = c2n_sdc_dc_device.Element("id").Value;			//read id from xml
							uint adr = Convert.ToUInt32(s.ToString(), 16);		//parse hex value in the string

							//Create an instance of device at specfied Cresent id
							Variables.c2n_sdc_dc[i] = new Cresnet_C2N_SDC_DC(adr, this);

							//Register the device or mark an error in the control system's log if registration fails.
							if (Variables.c2n_sdc_dc[i].Register() == DeviceRegistrationUnRegistrationResponse.Success)
							{
								Variables.shade_hw[i * 2] = new shade_interface(Variables.c2n_sdc_dc[i], 1);//create shade interface to shade on port 1 of sdc
								Variables.shade_hw[(i * 2) + 1] = new shade_interface(Variables.c2n_sdc_dc[i], 2);//create shade interface to shade on port 2 of sdc
							}
							else
							{
								Crestron.SimplSharp.ErrorLog.Error(String.Format("Failed to register device at ID {0:X2}", Variables.c2n_sdc_dc[i].ID));
							}

							i++;												//next device
						}
					}
					#endregion

					#region CSM_QMT50_DCCN
					if (csm_qmt50_dccn_count > 0)								//check if there were any of these hardware inerfaces
					{															//in the xml file
						//Create the memory to hold the data
						Variables.csm_qmt50_dccn = new Cresnet_CSM_QMT50_DCCN[csm_qmt50_dccn_count];

						//Create the list
						IEnumerable<XElement> csm_qmt50_dccn_list = csm_qmt50_dccn_hw.Elements();

						i = 0;													//set to first array entry
						foreach (XElement csm_qmt50_dccn_device in csm_qmt50_dccn_list)	//loop through xml elements
						{
							//read id from xml file
							s = csm_qmt50_dccn_device.Element("id").Value;		//read id from xml
							uint adr = Convert.ToUInt32(s.ToString(), 16);		//parse hex value in the string

							//Create an instance of device at specfied Cresent id
							Variables.csm_qmt50_dccn[i] = new Cresnet_CSM_QMT50_DCCN(adr, this);

							//Register the device or mark an error in the control system's log if registration fails.
							if (Variables.csm_qmt50_dccn[i].Register() == DeviceRegistrationUnRegistrationResponse.Success)
							{
								Variables.shade_hw[i] = new shade_interface(Variables.csm_qmt50_dccn[i]);//create shade interface to shade on port 1 of sdc
							}
							else
							{
								Crestron.SimplSharp.ErrorLog.Error(String.Format("Failed to register device at ID {0:X2}", Variables.csm_qmt50_dccn[i].ID));
							}

							i++;												//next device
						}
					}
					#endregion

					#region CSC_ACCN
					if (csc_accn_count > 0)										//check if there were any of these hardware inerfaces
					{															//in the xml file
						//Create the memory to hold the data
						Variables.csc_accn = new Cresnet_CSC_ACCN[csc_accn_count];

						//Create the list
						IEnumerable<XElement> csc_accn_list = csc_accn_hw.Elements();

						i = 0;													//set to first array entry
						foreach (XElement csc_accn_device in csc_accn_list)		//loop through xml elements
						{
							//read id from xml file
							s = csc_accn_device.Element("id").Value;			//read id from xml
							uint adr = Convert.ToUInt32(s.ToString(), 16);		//parse hex value in the string

							//Create an instance of device at specfied Cresent id
							Variables.csc_accn[i] = new Cresnet_CSC_ACCN(adr, this);

							//Register the device or mark an error in the control system's log if registration fails.
							if (Variables.csc_accn[i].Register() == DeviceRegistrationUnRegistrationResponse.Success)
							{
								Variables.shade_hw[i] = new shade_interface(Variables.csc_accn[i]);//create shade interface to shade on port 1 of sdc
							}
							else
							{
								Crestron.SimplSharp.ErrorLog.Error(String.Format("Failed to register device at ID {0:X2}", Variables.csc_accn[i].ID));
							}

							i++;												//next device
						}
					}
					#endregion

					#region CSC_DCCN
					if (csc_dccn_count > 0)										//check if there were any of these hardware inerfaces
					{															//in the xml file
						//Create the memory to hold the data
						Variables.csc_dccn = new Cresnet_CSC_DCCN[csc_dccn_count];

						//Create the list
						IEnumerable<XElement> csc_dccn_list = csc_dccn_hw.Elements();

						i = 0;													//set to first array entry
						foreach (XElement csc_dccn_device in csc_dccn_list)		//loop through xml elements
						{
							//read id from xml file
							s = csc_dccn_device.Element("id").Value;			//read id from xml
							uint adr = Convert.ToUInt32(s.ToString(), 16);		//parse hex value in the string

							//Create an instance of device at specfied Cresent id
							Variables.csc_dccn[i] = new Cresnet_CSC_DCCN(adr, this);

							//Register the device or mark an error in the control system's log if registration fails.
							if (Variables.csc_dccn[i].Register() == DeviceRegistrationUnRegistrationResponse.Success)
							{
								Variables.shade_hw[i] = new shade_interface(Variables.csc_dccn[i]);//create shade interface to shade on port 1 of sdc
							}
							else
							{
								Crestron.SimplSharp.ErrorLog.Error(String.Format("Failed to register device at ID {0:X2}", Variables.csc_dccn[i].ID));
							}

							i++;												//next device
						}
					}
					#endregion

					#region CSC_DRPCN
					if (csc_drpcn_count > 0)									//check if there were any of these hardware inerfaces
					{															//in the xml file
						//Create the memory to hold the data
						Variables.csc_drpcn = new Cresnet_CSC_DRPCN[csc_drpcn_count];

						//Create the list
						IEnumerable<XElement> csc_drpcn_list = csc_drpcn_hw.Elements();

						i = 0;													//set to first array entry
						foreach (XElement csc_drpcn_device in csc_drpcn_list)	//loop through xml elements
						{
							//read id from xml file
							s = csc_drpcn_device.Element("id").Value;			//read id from xml
							uint adr = Convert.ToUInt32(s.ToString(), 16);		//parse hex value in the string

							//Create an instance of device at specfied Cresent id
							Variables.csc_drpcn[i] = new Cresnet_CSC_DRPCN(adr, this);

							//Register the device or mark an error in the control system's log if registration fails.
							if (Variables.csc_drpcn[i].Register() == DeviceRegistrationUnRegistrationResponse.Success)
							{
								Variables.shade_hw[i] = new shade_interface(Variables.csc_drpcn[i]);//create shade interface to shade on port 1 of sdc
							}
							else
							{
								Crestron.SimplSharp.ErrorLog.Error(String.Format("Failed to register device at ID {0:X2}", Variables.csc_drpcn[i].ID));
							}

							i++;												//next device
						}
					}
					#endregion

					//TODO: Add Support for other cresenet hardware types here
				}
				#endregion

				#region Read Room and Shade Data
				//Find root element for data for each room
				XElement root_room = doc
					.Element("ShadeInformation")
					.Element("Rooms");

				//count the number of rooms
				int r_count = root_room.Elements().Count();
				CrestronLogger.WriteToLog("Read_XML_Data: r_count = " + r_count + "\n\r", 7);

				//allocate storage for data
				Variables.room_data = new room[r_count];

				IEnumerable<XElement> rooms = root_room.Elements();

				//count total number of shades
				int s_count = 0;												//initialize counter for loop
				foreach (XElement rm in rooms)									//loop through xml elements
				{
					//Find root element for data for each shade in the room
					XElement root_shade = rm.Element("Shades");

					//count the number of shades in the room
					s_count += root_shade.Elements().Count();

				}
				//allocate storage for data
				Variables.shade_data = new shade[s_count];
				CrestronLogger.WriteToLog("Read_XML_Data:  Shade count = " + s_count + "\n\r", 7);


				int k = 0;														//initialize index counter
				int j = 0;														//initialize index counter
				foreach (XElement rm in rooms)									//loop through xml elements
				{
					//create instance of room
					Variables.room_data[k] = new room();

					//read data elements from xml file and add them to the object instance
					Variables.room_data[k].name = rm.Element("name").Value;
					CrestronLogger.WriteToLog("Read_XML_Data: room name = " + Variables.room_data[k].name + "\n\r", 7);

					Variables.room_data[k].note = rm.Element("note").Value;
					CrestronLogger.WriteToLog("Read_XML_Data: note = " + Variables.room_data[k].note + "\n\r", 7);

					Variables.room_data[k].temperature_join = Convert.ToUInt32(rm.Element("temperature_join").Value);
					CrestronLogger.WriteToLog("Read_XML_Data: room temprature_join = " + Variables.room_data[k].temperature_join + "\n\r", 7);

					//Get current temperature from EISC
					if ((Variables.EISC_TO_SIMPL.IsOnline == true) 				//check if EISC is online & join # is valid
						&& (Variables.room_data[k].temperature_join != 0))
					{
						Variables.room_data[k].Set_Room_Temperature(Variables.EISC_TO_SIMPL.AnalogOutput[Variables.room_data[k].temperature_join]);
					}
					else
					{
						Crestron.SimplSharp.ErrorLog.Error("Read_XML_Data: EISC Offline or invalid join for room = " + Variables.room_data[k].name +
							"thermostat temperature join =" + Variables.room_data[k].temperature_join + "\n\r");
						CrestronLogger.WriteToLog("Read_XML_Data: EISC Offline or invalid join for room = " + Variables.room_data[k].name +
							"thermostat temperature join =" + Variables.room_data[k].temperature_join + "\n\r", 0);
						Variables.room_data[k].Set_Room_Temperature(Variables.default_room_temperature);
					}

					Variables.room_data[k].setpoint_join = Convert.ToUInt32(rm.Element("setpoint_join").Value);
					CrestronLogger.WriteToLog("Read_XML_Data: room setpoint_join = " + Variables.room_data[k].setpoint_join + "\n\r", 7);

					//Get current setpoint from EISC
					if ((Variables.EISC_TO_SIMPL.IsOnline == true) 				//check if EISC is online & join # is valid
						&& (Variables.room_data[k].setpoint_join != 0))
					{
						Variables.room_data[k].Set_Room_Setpoint(Variables.EISC_TO_SIMPL.AnalogOutput[Variables.room_data[k].setpoint_join]);
					}
					else
					{
						Crestron.SimplSharp.ErrorLog.Error("Read_XML_Data: EISC Offline or invalid join for room = " + Variables.room_data[k].name +
							"thermostat setpoint join =" + Variables.room_data[k].setpoint_join + "\n\r");
						CrestronLogger.WriteToLog("Read_XML_Data: EISC Offline or invalid join for room = " + Variables.room_data[k].name +
							"thermostat setpoint join =" + Variables.room_data[k].setpoint_join + "\n\r", 0);
						Variables.room_data[k].Set_Room_Setpoint(Variables.default_room_setpoint);
					}

					Variables.room_data[k].thermostat_mode_join = Convert.ToUInt32(rm.Element("thermostat_mode_join").Value);
					CrestronLogger.WriteToLog("Read_XML_Data: room thermostat_mode_join = " + Variables.room_data[k].thermostat_mode_join + "\n\r", 7);

					//Get current thermostat mode from EISC
					if ((Variables.EISC_TO_SIMPL.IsOnline == true)						//check if EISC is online & join # is valid
						&& (Variables.room_data[k].thermostat_mode_join != 0))
					{
						Variables.room_data[k].Set_Room_Thermostat_Mode(Variables.Int_To_Mode(Variables.EISC_TO_SIMPL.AnalogOutput[Variables.room_data[k].thermostat_mode_join]));
					}
					else																//EISC NOT online
					{
						Crestron.SimplSharp.ErrorLog.Error("Read_XML_Data: EISC Offline or invalid join for room = " + Variables.room_data[k].name +
							"thermostat mode join =" + Variables.room_data[k].thermostat_mode_join + "\n\r");
						CrestronLogger.WriteToLog("Read_XML_Data: EISC Offline or invalid join for room = " + Variables.room_data[k].name +
							"thermostat mode join =" + Variables.room_data[k].thermostat_mode_join + "\n\r", 0);
						Variables.room_data[k].Set_Room_Thermostat_Mode(modes.heat);												//return default when can't communicate with simplwin program
					}


					Variables.room_data[k].ignore_party_flag = Convert.ToBoolean(rm.Element("ignore_party_flag").Value);
					CrestronLogger.WriteToLog("Read_XML_Data: room ignore_party_flag = " + Variables.room_data[k].ignore_party_flag + "\n\r", 7);

					Variables.room_data[k].close_when_away = Convert.ToBoolean(rm.Element("close_when_away").Value);
					CrestronLogger.WriteToLog("Read_XML_Data: room close_when_away = " + Variables.room_data[k].close_when_away + "\n\r", 7);

					//Find root element for data for each shade in the room
					XElement root_shade = rm.Element("Shades");

					//create list of shades
					IEnumerable<XElement> shades = root_shade.Elements();

					foreach (XElement sh in shades)									//loop through xml elements
					{
						//create new shade instance
						Variables.shade_data[j] = new shade();

						Variables.shade_data[j].id = j;								//save unique id in the object

						//read data from xml file and add to object
						Variables.shade_data[j].name = sh.Element("name").Value;
						CrestronLogger.WriteToLog("Read_XML_Data: shade name = " + Variables.shade_data[j].name + "\n\r", 7);

						Variables.shade_data[j].note = sh.Element("note").Value;
						CrestronLogger.WriteToLog("Read_XML_Data: shade note = " + Variables.shade_data[j].note + "\n\r", 7);

						Variables.shade_data[j].east_horizon = Convert.ToDouble(sh.Element("east_horizon").Value);
						CrestronLogger.WriteToLog("Read_XML_Data: east_horizon = " + Variables.shade_data[j].east_horizon + "\n\r", 7);

						Variables.shade_data[j].west_horizon = Convert.ToDouble(sh.Element("west_horizon").Value);
						CrestronLogger.WriteToLog("Read_XML_Data: west_horizon = " + Variables.shade_data[j].west_horizon + "\n\r", 7);

						Variables.shade_data[j].angle_from_north = Convert.ToDouble(sh.Element("angle_from_north").Value);
						CrestronLogger.WriteToLog("Read_XML_Data: angle_from_north = " + Variables.shade_data[j].angle_from_north + "\n\r", 7);

						Variables.shade_data[j].eave_height = Convert.ToDouble(sh.Element("eave_height").Value);
						CrestronLogger.WriteToLog("Read_XML_Data: eave_height = " + Variables.shade_data[j].eave_height + "\n\r", 7);

						Variables.shade_data[j].eave_depth = Convert.ToDouble(sh.Element("eave_depth").Value);
						CrestronLogger.WriteToLog("Read_XML_Data: eave_depth = " + Variables.shade_data[j].eave_depth + "\n\r", 7);

						Variables.shade_data[j].max_eave_depth_low = Convert.ToDouble(sh.Element("max_eave_depth_low").Value);
						CrestronLogger.WriteToLog("Read_XML_Data: max_eave_depth_low = " + Variables.shade_data[j].max_eave_depth_low + "\n\r", 7);

						Variables.shade_data[j].max_eave_depth_high = Convert.ToDouble(sh.Element("max_eave_depth_high").Value);
						CrestronLogger.WriteToLog("Read_XML_Data: max_eave_depth_high = " + Variables.shade_data[j].max_eave_depth_high + "\n\r", 7);

						Variables.shade_data[j].height_floor_to_sill = Convert.ToDouble(sh.Element("height_floor_to_sill").Value);
						CrestronLogger.WriteToLog("Read_XML_Data: height_floor_to_sill = " + Variables.shade_data[j].height_floor_to_sill + "\n\r", 7);

						Variables.shade_data[j].window_height = Convert.ToDouble(sh.Element("window_height").Value);
						CrestronLogger.WriteToLog("Read_XML_Data: window_height = " + Variables.shade_data[j].window_height + "\n\r", 7);

						Variables.shade_data[j].option = Variables.To_Option(sh.Element("option").Value);
						CrestronLogger.WriteToLog("Read_XML_Data: option = " + Variables.shade_data[j].option + "\n\r", 7);

						Variables.shade_data[j].timed_actions = sh.Element("timed_actions").Value;
						CrestronLogger.WriteToLog("Read_XML_Data: timed_actions = " + Variables.shade_data[j].timed_actions + "\n\r", 7);

						Variables.shade_data[j].sunrise_action = Variables.To_Action(sh.Element("sunrise_action").Value);
						CrestronLogger.WriteToLog("Read_XML_Data: sunrise_action = " + Variables.shade_data[j].sunrise_action + "\n\r", 7);

						Variables.shade_data[j].sunset_action = Variables.To_Action(sh.Element("sunset_action").Value);
						CrestronLogger.WriteToLog("Read_XML_Data: sunset_action = " + Variables.shade_data[j].sunset_action + "\n\r", 7);

						Variables.shade_data[j].close_on_glare = Convert.ToBoolean(sh.Element("close_on_glare").Value);
						CrestronLogger.WriteToLog("Read_XML_Data: close_on_glare = " + Variables.shade_data[j].close_on_glare + "\n\r", 7);

						Variables.shade_data[j].serial_join = Convert.ToUInt32(sh.Element("serial_feedback_join").Value);
						CrestronLogger.WriteToLog("Read_XML_Data: serial_feedback_join = " + Variables.shade_data[j].serial_join + "\n\r", 7);

						Variables.shade_data[j].analog_join = Convert.ToUInt32(sh.Element("analog_feedback_join").Value);
						CrestronLogger.WriteToLog("Read_XML_Data: analog_feedback_join = " + Variables.shade_data[j].analog_join + "\n\r", 7);

						Variables.shade_data[j].group_name = sh.Element("group_name").Value.ToLower();
						CrestronLogger.WriteToLog("Read_XML_Data: group_name = " + Variables.shade_data[j].group_name + "\n\r", 7);
						Shade_Group.add(Variables.shade_data[j]);				//add this shade to its group
						
						Variables.shade_data[j].room = Variables.room_data[k];	//save what room the shade is in

						Variables.shade_data[j].hardware_address = sh.Element("hardware_address").Value;
						CrestronLogger.WriteToLog("Read_XML_Data: hardware_address = " + Variables.shade_data[j].hardware_address + "\n\r", 7);

						//match the shade controller to the shade and then save the reference to the shade in the hardware
						Variables.shade_data[j].hardware_interface = Shade_Controller_Setup(Variables.shade_data[j].hardware_address);
						Variables.shade_data[j].hardware_interface.Set_Shade(Variables.shade_data[j]);

						Variables.room_data[k].shade_list.Add(Variables.shade_data[j]);	//add shade data to containing room

						//report the shade name across the EISC
						Variables.EISC_Serial_Output(Variables.shade_data[j].serial_join, Variables.shade_data[j].name);

						j++;													//next shade
					}

					k++;														//next room
				}
				Variables.ShadeShowShades("log");								//write room and shade data to log

				Variables.ShadeShowGroups("log");								//write shade group data to log
				#endregion
			}
			catch (Exception e)
			{
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Read_XML_Data: " + e + "\n\r"));
				CrestronLogger.WriteToLog("Read_XML_Data: " + e + "\n\r", 0);
				Variables.ShadeShowShades("log");								//write room and shade data to log
				Variables.ShadeShowGroups("log");								//write shade group data to log
			}
		}

		//****************************************************************************************
		// 
		//  Shade_Controller_Setup	-	Configure the interface class between the shade objects and
		//								the shade hardware
		// 
		//****************************************************************************************
		private shade_interface Shade_Controller_Setup(string address)
		{
			string lc_adr = address.ToLower();

			foreach (shade_interface si in Variables.shade_hw)					//loop through all the shade interfaces to find the right one
			{
				if (si.id == lc_adr)											//see if this is the interface that matches the address in the xml file
				{
					return si;													//pass back the shade interface
				}
			}
		
			//if you got here there is a problem - couldn't locate entry
			Crestron.SimplSharp.ErrorLog.Error(string.Format("Shade_Controller_Setup: can't locate shade interface with matching address - " + address + "\n\r"));
			CrestronLogger.WriteToLog("Shade_Controller_Setup: can't locate shade interface with matching address - " + address + "\n\r", 0);

			return null;
		}

		//****************************************************************************************
		// 
		//  Parse_Shade_Action_Times	-	parse xml data for shade open/close times
		// 
		//****************************************************************************************
		private void Parse_Shade_Action_Times(shade sh)
		{
			char[] delimiterChars1 = { ',' };
			char[] delimiterChars2 = { '-' };
			string s = sh.timed_actions.ToLower();

			try
			{
				//check if there is anything todo
				if (s == "none")
				{
					return;
				}

				//split string into 
				string[] events = s.Split(delimiterChars1);

				//loop through the events
				foreach (string s1 in events)
				{
					string[] s2 = s1.Split(delimiterChars2);					//separate an event time-action into separate strings

					if (s2[1] == "open")										//open shade
					{
						Schedule_Shade_Timer(s2[0], sh, actions.schedule_open_full);	//create timer for the event
					}
					else if (s2[1] == "close")									// close shade
					{
						Schedule_Shade_Timer(s2[0], sh, actions.schedule_close_full);//create timer for the event
					}
					else if (s2[1] == "auto")									//set shade back to auto operation
					{
						Schedule_Shade_Timer(s2[0], sh, actions.schedule_unlock);//create timer for the event
					}
					else
					{
						CrestronLogger.WriteToLog("Parse_Shade_Action_Times: Error - invalid window action\n\r", 5);
						Crestron.SimplSharp.ErrorLog.Error("Parse_Shade_Action_Times: Error - invalid window action\n\r");
					}
				}
			}
			catch (Exception e)
			{
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Parse_Shade_Action_Times: " + e + "\n\r"));
				CrestronLogger.WriteToLog("Parse_Shade_Action_Times: " + e + "\n\r", 0);
			}
		}

		//****************************************************************************************
		// 
		//  Sun_Angle_Calc	-	Perform angle Calculations
		// 
		//****************************************************************************************
		private void Sun_Angle_Calc(double latitude, double longitude, out Boolean daytime, out double azimuth, out double elevation)
		{
			DateTime jan_1_1900 = DateTime.Parse("1/1/1900 00:00:00");
			double julian_day, julian_century;
			double GMLS;    //Geom Mean Long Sun (deg)
			double GMAS;    //Geom Mean Anom Sun (deg)
			double EEO;     //Eccent Earth Orbit
			double SEOC;    //Sun Eq of Ctr
			double STL;     //Sun True Long (deg)
			double STA;     //Sun True Anom (deg)
			double SRV;     //Sun True Anom (deg)
			double SAL;     //Sun App Long (deg)
			double MOE;     //Mean Obliq Ecliptic (deg)
			double OC;      //Obliq Corr (deg)
			double SRA;     //Sun Rt Ascen (deg)
			double SD;      //Sun Declin (deg)
			double var_y;
			double EOT;     //Eq of Time (minutes)
			double HAS;     //HA Sunrise (deg)
			double SN;      //Solar Noon (LST)
			double Sunrise_Time;
			double Sunset_Time;
			double Sunlight_Duration;
			double TST;     //True Solar Time (min)
			double HA;      //Hour Angle (deg)
			double SZA;     //Solar Zenith Angle (deg)
			double SEA;     //Solar Elevation Angle (deg)
			double SAA;     //Solar Azimuth Angle (deg cw from N)
			try
			{
				DateTime date = DateTime.Now;
				CrestronLogger.WriteToLog("date-time = " + date + "\n\r", 5);

				TimeZone tz = TimeZone.CurrentTimeZone;

				double hour = (double)date.Hour + ((double)date.Minute / 60) + ((double)date.Second / (60 * 60));
				CrestronLogger.WriteToLog("hour: " + hour + "\n\r", 9);

				CrestronLogger.WriteToLog("UTC: " + tz.GetUtcOffset(date).TotalHours + "\n\r", 9);
				CrestronLogger.WriteToLog("days since 1900: " + (Math.Floor((date - jan_1_1900).TotalDays) + 2) + "\n\r", 9);

				//Excel says there are 2 more days between jan 1,1900 and now so we add 2 to keep the calculations the same
				julian_day = (Math.Floor((date - jan_1_1900).TotalDays) + 2) + 2415018.5 + (hour / 24)
					- ((tz.GetUtcOffset(date).TotalHours) / 24);
				CrestronLogger.WriteToLog("Julian Day: " + julian_day + "\n\r", 9);

				julian_century = (julian_day - 2451545) / 36525;
				CrestronLogger.WriteToLog("Julian Century: " + julian_century + "\n\r", 9);

				GMLS = (280.46646 + julian_century * (36000.76983 + julian_century * 0.0003032)) % 360;
				CrestronLogger.WriteToLog("GMLS: " + GMLS + "\n\r", 9);

				GMAS = 357.52911 + julian_century * (35999.05029 - 0.0001537 * julian_century);
				CrestronLogger.WriteToLog("GMAS: " + GMAS + "\n\r", 9);

				EEO = 0.016708634 - julian_century * (0.000042037 + 0.0000001267 * julian_century);
				CrestronLogger.WriteToLog("EEO: " + EEO + "\n\r", 9);

				SEOC = Math.Sin(GMAS * radians) * (1.914602 - julian_century * (0.004817 + 0.000014 * julian_century))
					+ Math.Sin(2 * GMAS * radians) * (0.019993 - 0.000101 * julian_century) + Math.Sin(3 * GMAS * radians) * 0.000289;
				CrestronLogger.WriteToLog("SEOC: " + SEOC + "\n\r", 9);

				STL = GMLS + SEOC;
				CrestronLogger.WriteToLog("STL: " + STL + "\n\r", 9);

				STA = GMAS + SEOC;
				CrestronLogger.WriteToLog("STA: " + STA + "\n\r", 9);

				SRV = (1.000001018 * (1 - EEO * EEO)) / (1 + EEO * Math.Cos(STA * radians));
				CrestronLogger.WriteToLog("SRV: " + SRV + "\n\r", 9);

				SAL = STL - 0.00569 - 0.00478 * Math.Sin((125.04 - 1934.136 * julian_century) * radians);
				CrestronLogger.WriteToLog("SAL: " + SAL + "\n\r", 9);

				MOE = 23 + (26 + ((21.448 - julian_century * (46.815 + julian_century * (0.00059 - julian_century * 0.001813)))) / 60) / 60;
				CrestronLogger.WriteToLog("MOE: " + MOE + "\n\r", 9);

				OC = MOE + 0.00256 * Math.Cos((125.04 - 1934.136 * julian_century) * radians);
				CrestronLogger.WriteToLog("OC: " + OC + "\n\r", 9);

				SRA = (Math.Atan2((Math.Cos(OC * radians) * Math.Sin(SAL * radians)), Math.Cos(SAL * radians))) / radians;
				CrestronLogger.WriteToLog("SRA: " + SRA + "\n\r", 9);

				SD = (Math.Asin(Math.Sin(OC * radians) * Math.Sin(SAL * radians))) / radians;
				CrestronLogger.WriteToLog("SD: " + SD + "\n\r", 9);

				var_y = Math.Tan((OC / 2) * radians) * Math.Tan((OC / 2) * radians);
				CrestronLogger.WriteToLog("var_y: " + var_y + "\n\r", 9);

				EOT = 4 * (var_y * Math.Sin(2 * GMLS * radians) - 2 * EEO * Math.Sin(GMAS * radians) +
					4 * EEO * var_y * Math.Sin(GMAS * radians) * Math.Cos(2 * GMLS * radians) -
					0.5 * var_y * var_y * Math.Sin(4 * GMLS * radians) - 1.25 * EEO * EEO * Math.Sin(2 * GMAS * radians)) / radians;
				CrestronLogger.WriteToLog("EOT: " + EOT + "\n\r", 9);

				HAS = (Math.Acos(Math.Cos(90.833 * radians) / (Math.Cos(latitude * radians) * Math.Cos(SD * radians))
					- Math.Tan(latitude * radians) * Math.Tan(SD * radians))) / radians;
				CrestronLogger.WriteToLog("HAS: " + HAS + "\n\r", 9);

				SN = (720 - 4 * longitude - EOT + tz.GetUtcOffset(date).TotalHours * 60) / 1440;
				CrestronLogger.WriteToLog("SN: " + SN + "\n\r", 9);
				{
					int h = (int)(SN * 24);
					int m = (int)(((SN * 24) - h) * 60);
					int s = (int)(((((SN * 24) - h) * 60) - m) * 60);
					CrestronLogger.WriteToLog("SN: " + h + ":" + m + ":" + s + "\n\r", 9);
				}

				Sunrise_Time = SN - HAS * 4 / 1440;
				CrestronLogger.WriteToLog("Sunrise_Time: " + Sunrise_Time + "\n\r", 9);
				{
					int h = (int)(Sunrise_Time * 24);
					int m = (int)(((Sunrise_Time * 24) - h) * 60);
					int s = (int)(((((Sunrise_Time * 24) - h) * 60) - m) * 60);
					CrestronLogger.WriteToLog("Sunrise_Time: " + h + ":" + m + ":" + s + "\n\r", 9);
				}

				Sunset_Time = SN + HAS * 4 / 1440;
				CrestronLogger.WriteToLog("Sunset_Time: " + Sunset_Time + "\n\r", 9);
				{
					int h = (int)(Sunset_Time * 24);
					int m = (int)(((Sunset_Time * 24) - h) * 60);
					int s = (int)(((((Sunset_Time * 24) - h) * 60) - m) * 60);
					CrestronLogger.WriteToLog("Sunset_Time: " + h + ":" + m + ":" + s + "\n\r", 9);
				}

				if ((hour > (Sunrise_Time * 24)) && (hour < (Sunset_Time * 24)))
				{
					daytime = true;
				}
				else
				{
					daytime = false;
				}
				CrestronLogger.WriteToLog("daytime: " + daytime + "\n\r", 9);

				Sunlight_Duration = 8 * HAS;
				CrestronLogger.WriteToLog("Sunlight_Duration: " + Sunlight_Duration + "\n\r", 9);

				TST = (((hour / 24) * 1440) + EOT + (4 * longitude) - (60 * tz.GetUtcOffset(date).TotalHours)) % 1440;
				CrestronLogger.WriteToLog("TST: " + TST + "\n\r", 9);

				HA = ((TST / 4) < 0) ? ((TST / 4) + 180) : ((TST / 4) - 180);
				CrestronLogger.WriteToLog("HA: " + HA + "\n\r", 9);

				SZA = (Math.Acos(Math.Sin(latitude * radians) * Math.Sin(SD * radians) + Math.Cos(latitude * radians)
					* Math.Cos(SD * radians) * Math.Cos(HA * radians))) / radians;
				CrestronLogger.WriteToLog("SZA: " + SZA + "\n\r", 9);

				SEA = 90 - SZA;
				CrestronLogger.WriteToLog("SEA: " + SEA + "\n\r", 9);

				if (HA > 0)
				{
					SAA = ((Math.Acos(((Math.Sin(latitude * radians) * Math.Cos(SZA * radians)) - Math.Sin(SD * radians)) /
						(Math.Cos(latitude * radians) * Math.Sin(SZA * radians))) / radians) + 180) % 360;
				}
				else
				{
					SAA = (540 - ((Math.Acos(((Math.Sin(latitude * radians) * Math.Cos(SZA * radians)) - Math.Sin(SD * radians))
						/ (Math.Cos(latitude * radians) * Math.Sin(SZA * radians)))) / radians)) % 360;
				}
				CrestronLogger.WriteToLog("SEA: " + SEA + "\n\r", 9);

				azimuth = Variables.true_north_to_magnetic_north(SAA);
				elevation = SEA;
			}
			catch (Exception e)
			{
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Sun_Angle_Calc: " + e + "\n\r"));
				CrestronLogger.WriteToLog("Sun_Angle_Calc: " + e + "\n\r", 0);
				throw;
			}
		}

		//****************************************************************************************
		// 
		//  Calculate_Window_Eave_Angle	-	calculate angle to the eave based on dimensions
		//									and azimuth to the sun.  This routine is only called
		//									when the sun is on the window so the math is simplified
		// 
		//****************************************************************************************
		private double Calculate_Window_Eave_Angle(shade sh, double azimuth)
		{
			try
			{
				double eave_angle;

				//don't allow a divide by zero situation
				if (sh.eave_height == 0)
				{
					eave_angle = 90;
				}
				else
				{

					double window_angle_to_sun = Math.Abs(azimuth - sh.angle_from_north);

					CrestronLogger.WriteToLog("Window Angle to Sun: " + window_angle_to_sun + "\n\r", 5);

					double eave_depth_on_sun_angle = sh.eave_depth / (Math.Cos(window_angle_to_sun * radians));

					//check if calculated depth goes farther than the end of the eave and adjust if necessary
					if ((window_angle_to_sun <= 90) && (eave_depth_on_sun_angle > sh.max_eave_depth_low))
					{
						eave_depth_on_sun_angle = sh.max_eave_depth_low;
					}
					else if ((window_angle_to_sun > 90) && (eave_depth_on_sun_angle > sh.max_eave_depth_high))
					{
						eave_depth_on_sun_angle = sh.max_eave_depth_high;
					}

					CrestronLogger.WriteToLog("Eave Depth on Sun Angle: " + eave_depth_on_sun_angle + "\n\r", 5);

					eave_angle = (90 - ((Math.Atan(eave_depth_on_sun_angle / sh.eave_height)) / radians));
				}

				CrestronLogger.WriteToLog("Calculated eave angle: " + eave_angle + "\n\r", 5);

				return eave_angle;
			}
			catch (Exception e)
			{
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Calculate_Window_Eave_Angle: " + e + "\n\r"));
				CrestronLogger.WriteToLog("Calculate_Window_Eave_Angle: " + e + "\n\r", 0);

				return 90;
			}
		}

		//****************************************************************************************
		// 
		//  Evaluate_Shade_Action	-	evaluate if shades should be opened or closed based
		//								on options and whether sun is on window
		// 
		//****************************************************************************************
		private void Evaluate_Shade_Action(shade sh, double azimuth, double elevation)
		{
			Boolean sun_on_window;
			actions shade_action = actions.none;
			bool glare;

			//write to console and log for debugging
			CrestronLogger.WriteToLog("Solar Elevation Angle = " + elevation.ToString() + "\n\r", 5);
			CrestronLogger.WriteToLog("Azimuth Angle = " + azimuth.ToString() + "\n\r", 5);
			CrestronLogger.WriteToLog("forecast_high_temperature = " + forecast_high_temperature + "\n\r", 5);
			CrestronLogger.WriteToLog("room temperature = " + sh.room.Get_Room_Temperature() + "\n\r", 5);
			CrestronLogger.WriteToLog("room setpoint = " + sh.room.Get_Room_Setpoint() + "\n\r", 5);

			//clear action flag
			shade_action = actions.none;

			if (Evaluate_Window_Angles(sh, azimuth, elevation, out glare) == true)
			{
				sun_on_window = true;
				CrestronLogger.WriteToLog("Sun on Window\n\r", 5);
			}
			else
			{
				sun_on_window = false;
				CrestronLogger.WriteToLog("Sun NOT on Window\n\r", 5);
			}

			//tester - add what to do that there is glare

			//open or close the shade
			if (sh.option == options.none)
			{
				CrestronLogger.WriteToLog("No Automated Optimization\n\r", 5);
			}
			else if (sh.option == options.energy_save_optimal)
			{
				CrestronLogger.WriteToLog("Energy-Save-Optimal\n\r", 5);
				if (sh.room.Get_Room_Thermostat_Mode() == modes.cool)			//if cooling the room treat it like summer
				{
					shade_action = actions.sun_close_full;						//close shade for insulation
				}
				else if (sh.room.Get_Room_Thermostat_Mode() == modes.heat)		//if heating the room treat it like winter
				{
					if (Variables.cloudy == false)								//if this is a sunny day
					{
						if (sun_on_window == true)								//use shade to heat room
						{
							if (sh.room.Get_Room_Temperature() >= (sh.room.Get_Room_Setpoint() + (thermostat_deadband / 2)))//is the room too warm?
							{
								shade_action = actions.sun_close_full;			//close shade
							}
							else if (sh.room.Get_Room_Temperature() < (sh.room.Get_Room_Setpoint() - (thermostat_deadband / 2)))
							{
								shade_action = actions.sun_open_full;			//else open the shade
							}
						}
						else
						{
							shade_action = actions.sun_close_full;				//close shade if sun not on window for extra insulation
						}
					}
					else
					{
						shade_action = actions.sun_close_full;					//cloudy outside, cose shade for insulation
					}
				}
				else if (sh.room.Get_Room_Thermostat_Mode() == modes.auto)		//auto mode acts like heat
				{
					if (Variables.cloudy == false)								//if this is a sunny day
					{
						if (sun_on_window == true)								//use shade to heat room
						{
							if (sh.room.Get_Room_Temperature() >= (sh.room.Get_Room_Setpoint() + (thermostat_deadband / 2)))//is the room too warm?
							{
								shade_action = actions.sun_close_full;			//close shade
							}
							else if (sh.room.Get_Room_Temperature() < (sh.room.Get_Room_Setpoint() - (thermostat_deadband / 2)))
							{
								shade_action = actions.sun_open_full;			//else open the shade
							}
						}
						else
						{
							shade_action = actions.sun_close_full;				//close shade if sun not on window for extra insulation
						}
					}
					else
					{
						shade_action = actions.sun_close_full;					//cloudy outside, cose shade for insulation
					}
				}
				else if (forecast_high_temperature > sh.room.Get_Room_Setpoint())//Summer - Mode is off, use temperatures
				{
					shade_action = actions.sun_close_full;						//close shade for insulation
				}
				else															//Winter - Mode is off, use temperatures
				{
					if (Variables.cloudy == false)								//if this is a sunny day
					{
						if (sun_on_window == true)								//use shade to heat room
						{
							if (sh.room.Get_Room_Temperature() >= (sh.room.Get_Room_Setpoint() + (thermostat_deadband / 2)))//is the room too warm?
							{
								shade_action = actions.sun_close_full;			//close shade
							}
							else if (sh.room.Get_Room_Temperature() < (sh.room.Get_Room_Setpoint() - (thermostat_deadband / 2)))
							{
								shade_action = actions.sun_open_full;			//else open the shade
							}
						}
						else
						{
							shade_action = actions.sun_close_full;				//close shade if sun not on window for extra insulation
						}
					}
					else
					{
						shade_action = actions.sun_close_full;					//cloudy outside, cose shade for insulation
					}
				}
			}
			else if (sh.option == options.energy_save_aesthetics)
			{
				CrestronLogger.WriteToLog("Energy-Save-Aesthetics\n\r", 5);
				if (sh.room.Get_Room_Thermostat_Mode() == modes.cool)			//if cooling the room treat it like summer
				{
					if (Variables.cloudy == false)								//if this is a sunny day
					{
						if (sun_on_window == true)
						{
							shade_action = actions.sun_close_full;				//close shade if sun on window in summer
						}
						else
						{
							shade_action = actions.sun_open_full;				//open shade when sun isn't on window for the view
						}
					}
					else
					{
						shade_action = actions.sun_open_full;					//cloudy day, open the window for the view
					}
				}
				else if (sh.room.Get_Room_Thermostat_Mode() == modes.heat)		//if heating the room treat it like winter
				{
					if (Variables.cloudy == false)								//if this is a sunny day
					{
						if (sun_on_window == true)								//use shade to heat room
						{
							if (sh.room.Get_Room_Temperature() >= (sh.room.Get_Room_Setpoint() + (thermostat_deadband / 2)))//is the room too warm?
							{
								shade_action = actions.sun_close_full;			//close shade for insulation
							}
							else if (sh.room.Get_Room_Temperature() < (sh.room.Get_Room_Setpoint() - (thermostat_deadband / 2)))
							{
								shade_action = actions.sun_open_full;			//open the shade to heat the room
							}
						}
						else
						{
							shade_action = actions.sun_open_full;				//open the shade for the view
						}
					}
					else
					{
						shade_action = actions.sun_open_full;					//cloudy day, open shade for the view
					}
				}
				else if (sh.room.Get_Room_Thermostat_Mode() == modes.auto)		//if auto the room treat it like winter
				{
					if (Variables.cloudy == false)								//if this is a sunny day
					{
						if (sun_on_window == true)								//use shade to heat room
						{
							if (sh.room.Get_Room_Temperature() >= (sh.room.Get_Room_Setpoint() + (thermostat_deadband / 2)))//is the room too warm?
							{
								shade_action = actions.sun_close_full;			//close shade for insulation
							}
							else if (sh.room.Get_Room_Temperature() < (sh.room.Get_Room_Setpoint() - (thermostat_deadband / 2)))
							{
								shade_action = actions.sun_open_full;			//open the shade to heat the room
							}
						}
						else
						{
							shade_action = actions.sun_open_full;				//open the shade for the view
						}
					}
					else
					{
						shade_action = actions.sun_open_full;					//cloudy day, open shade for the view
					}
				}
				else if (forecast_high_temperature > sh.room.Get_Room_Setpoint())//Summer - Mode is off, use temperatures
				{
					if (Variables.cloudy == false)								//if this is a sunny day
					{
						if (sun_on_window == true)
						{
							shade_action = actions.sun_close_full;				//close shade if sun on window in summer
						}
						else
						{
							shade_action = actions.sun_open_full;				//open shade when sun isn't on window for the view
						}
					}
					else
					{
						shade_action = actions.sun_open_full;					//cloudy day, open the window for the view
					}
				}
				else															//Winter - Mode is off, use temperatures
				{
					if (Variables.cloudy == false)								//if this is a sunny day
					{
						if (sun_on_window == true)								//use shade to heat room
						{
							if (sh.room.Get_Room_Temperature() >= (sh.room.Get_Room_Setpoint() + (thermostat_deadband / 2)))//is the room too warm?
							{
								shade_action = actions.sun_close_full;			//close shade for insulation
							}
							else if (sh.room.Get_Room_Temperature() < (sh.room.Get_Room_Setpoint() - (thermostat_deadband / 2)))
							{
								shade_action = actions.sun_open_full;			//open the shade to heat the room
							}
						}
						else
						{
							shade_action = actions.sun_open_full;				//open the shade for the view
						}
					}
					else
					{
						shade_action = actions.sun_open_full;					//cloudy day, open shade for the view
					}
				}
			}
			else if (sh.option == options.art_save_optimal)						//darken room to conserve art if possibility sun on window
			{
				CrestronLogger.WriteToLog("Art-Save-Optimal\n\r", 5);
				if (sun_on_window == true)										//if the sun is on the window
				{
					shade_action = actions.sun_close_full;						//close the shade so the artwork won't be damaged
				}
				else
				{
					shade_action = actions.sun_open_full;						//open the shade if the sun isn't on the window
				}
			}
			else if (sh.option == options.art_save_aesthetics)					//darken room to conserve art if sun on window
			{
				CrestronLogger.WriteToLog("Art-Save-Aesthetics\n\r", 5);
				if (Variables.cloudy == false)									//if it is sunny outside
				{
					if (sun_on_window == true)									//if the sun is on the window
					{
						shade_action = actions.sun_close_full;					//close the shade
					}
					else
					{
						shade_action = actions.sun_open_full;					//if sun isn't on the window, open the shade
					}
				}
				else
				{
					shade_action = actions.sun_open_full;						//open the shade if it is cloudy
				}
			}
			else
			{
				CrestronLogger.WriteToLog("Evaluate_Shade_Action: Error - invalid window option set\n\r", 5);
				Crestron.SimplSharp.ErrorLog.Error("Evaluate_Shade_Action: Error - invalid window option set\n\r");
			}

			//check if we need to close window to reduce glare in the room
			if ((sh.close_on_glare == true)
				&& (glare == true))
			{
				shade_action = actions.sun_close_full;					//close the shade
				CrestronLogger.WriteToLog("Evaluate_Shade_Action: Closing shade to reduce glare\n\r", 5);
			}

			if (shade_action == actions.none)
			{
				CrestronLogger.WriteToLog("No Shade Action\n\r", 5);
			}
			else if (shade_action == actions.sun_close_full)
			{
				if (sh.group_name == "none")
				{
					CrestronLogger.WriteToLog("Close Shade\n\r", 5);
					sh.Shade_Move(actions.sun_close_full);							//close the shade
				}
				else
				{
					CrestronLogger.WriteToLog("Saving close action for group evaluation\n\r", 5);
					sh.group_action = actions.sun_close_full;
				}
			}
			else if (shade_action == actions.sun_open_full)
			{
				if (sh.group_name == "none")
				{
					CrestronLogger.WriteToLog("Open Shade\n\r", 5);
					sh.Shade_Move(actions.sun_open_full);							//open the shade
				}
				{
					CrestronLogger.WriteToLog("Saving open action for group evaluation\n\r", 5);
					sh.group_action = actions.sun_open_full;
				}
			}
			else
			{
				CrestronLogger.WriteToLog("Evaluate_Shade_Action: Error - Undefined shade action\n\r", 5);
			}

			//add extra blank line for clarity
			CrestronLogger.WriteToLog("\n\r", 5);
		}

		//****************************************************************************************
		// 
		//  Evaluate_Window_Angles	-	compare window angles to sun angles
		//								returns if sun shines in the window
		// 
		//****************************************************************************************
		private bool Evaluate_Window_Angles(shade sh, double azimuth, double elevation, out bool glare)
		{
			double sh1, sh2, elv;												//window direction limits
			double eave_angle;													//angle to the eave, 90 if no eave
			glare = false;														//default if we return before glare is determined

			CrestronLogger.WriteToLog("Evaluating Shade: " + sh.name + "\n\r", 5);

			if ((elevation < sh.east_horizon)									//stop evaluation if sun not above east horizon & west horizons
				|| (elevation > (180 - sh.west_horizon)))
			{
				CrestronLogger.WriteToLog("Sun Below Window Horizon\n\r", 5);
				return false;
			}

			//validate if sun on window from an azimuth perspective
			//sun on window if angle within 180 (+/- 90) degrees of window angle
			sh1 = sh.angle_from_north;
			sh1 -= 90;
			if (sh1 < 0)														//handle circular nature of angles
			{
				sh1 += 360;
			}
			sh2 = sh.angle_from_north;
			sh2 += 90;
			if (sh2 > 360)														//handle circular nature of angles
			{
				sh2 -= 360;
			}

			if (sh2 < sh1)
			{
				if ((azimuth > sh2) && (azimuth < sh1))							//case 1 - north facing window and sun to the south
				{
					CrestronLogger.WriteToLog("case 1 - north facing window and sun to the south\n\r", 5);
					return false;
				}
			}
			else if (sh1 == 0)													//case 2 - east facing window and sun to the west
			{
				if (azimuth > sh2)
				{
					CrestronLogger.WriteToLog("case 2 - east facing window and sun to the west\n\r", 5);
					return false;
				}
			}
			else if (sh2 == 0)													//case 3 - west facing window and sun to the east 
			{
				if (azimuth < sh1)
				{
					CrestronLogger.WriteToLog("case 3 - west facing window and sun to the east\n\r", 5);
					return false;
				}
			}
			else
			{
				if ((azimuth < sh1) || (azimuth > sh2))							//case 4 - southern facing window and sun to the east or west
				{
					CrestronLogger.WriteToLog("case 4 - southern facing window and sun to the east or west\n\r", 5);
					return false;
				}
			}

			//convert elevation angle to between 0 - 90 degrees
			elv = elevation;
			if (elv > 90)
			{
				elv = 180 - elv;
			}

			//check if sun above window

			//first calculate the eave angle based on the azimuth to the sun
			eave_angle = Calculate_Window_Eave_Angle(sh, azimuth);

			if (elv > eave_angle)
			{
				CrestronLogger.WriteToLog("Sun elevation > eave angle\n\r", 5);
				return false;
			}

			//determine if the sun is shing far enough into the room to create glare
			if (sh.close_on_glare == true)										//only bother with calculations if necessary
			{
				glare = Evaluate_Window_Glare(sh, azimuth, elevation, eave_angle);
			}
			else
			{
				glare = false;													//just pass back false if no glare reduction required
			}

			//add extra blank line for clarity
			CrestronLogger.WriteToLog("Window in Sun Angle\n\r", 5);
			return true;

		}

		//****************************************************************************************
		// 
		//  Evaluate_Window_Glare	-	compare window angles to sun angles
		//								returns if sun is causing glare in the room
		// 
		//****************************************************************************************
		private bool Evaluate_Window_Glare(shade sh, double azimuth, double elevation, double eave_angle)
		{
			double sh1, sh2, elv;												//window direction limits

			CrestronLogger.WriteToLog("Evaluating Shade: " + sh.name + "\n\r", 5);

			if ((elevation < sh.east_horizon)									//stop evaluation if sun not above east horizon & west horizons
				|| (elevation > (180 - sh.west_horizon)))
			{
				CrestronLogger.WriteToLog("Sun Below Window Horizon\n\r", 5);
				return false;
			}

			//validate if sun on window from an azimuth perspective
			//sun on window if angle within 120 (+/- 60) degrees of window angle
			sh1 = sh.angle_from_north;
			sh1 -= Variables.glare_azimuth;
			if (sh1 < 0)														//handle circular nature of angles
			{
				sh1 += 360;
			}
			sh2 = sh.angle_from_north;
			sh2 += Variables.glare_azimuth;
			if (sh2 > 360)														//handle circular nature of angles
			{
				sh2 -= 360;
			}

			if (sh2 < sh1)
			{
				if ((azimuth > sh2) && (azimuth < sh1))							//case 1 - north facing window and sun to the south
				{
					CrestronLogger.WriteToLog("case 1 - north facing window and sun to the south\n\r", 5);
					return false;
				}
			}
			else if (sh1 == 0)													//case 2 - east facing window and sun to the west
			{
				if (azimuth > sh2)
				{
					CrestronLogger.WriteToLog("case 2 - east facing window and sun to the west\n\r", 5);
					return false;
				}
			}
			else if (sh2 == 0)													//case 3 - west facing window and sun to the east 
			{
				if (azimuth < sh1)
				{
					CrestronLogger.WriteToLog("case 3 - west facing window and sun to the east\n\r", 5);
					return false;
				}
			}
			else
			{
				if ((azimuth < sh1) || (azimuth > sh2))							//case 4 - southern facing window and sun to the east or west
				{
					CrestronLogger.WriteToLog("case 4 - southern facing window and sun to the east or west\n\r", 5);
					return false;
				}
			}

			//convert elevation angle to between 0 - 90 degrees
			elv = elevation;
			if (elv > 90)
			{
				elv = 180 - elv;
			}

			//check if sun above window
			if (elv > eave_angle)
			{
				CrestronLogger.WriteToLog("Sun elevation > eave angle\n\r", 5);
				return false;
			}

			//calculate how far the sun is shining into the room
			double feet_into_room = how_far_is_sun_shining_into_the_room(sh, azimuth, elevation);
			if (feet_into_room < Variables.feet_into_room_for_glare)
			{
				CrestronLogger.WriteToLog("Sun not shining far enough into the room for glare\n\r", 5);
				return false;
			}

			CrestronLogger.WriteToLog("Glare!\n\r", 5);
			return true;

		}
		//****************************************************************************************
		// 
		//  how_far_is_sun_shining_into_the_room	-	returns how many feet the sun is shining
		//												into the room based on the sun shining
		//												through the window with the top edge of
		//												the window being the limiting factor
		// 
		//****************************************************************************************
		double how_far_is_sun_shining_into_the_room(shade sh, double azimuth, double elevation)
		{
			return (sh.window_height + sh.height_floor_to_sill) / Math.Tan(elevation * radians);
		}

		//****************************************************************************************
		// 
		//  Schedule_Shade_Timer	-	starts a timer for a window action at a specified time each day
		// 
		//****************************************************************************************
		private void Schedule_Shade_Timer(string time, shade sh, actions act)
		{
			char[] delimiterChars1 = { ':' };

			try
			{
				string[] s = time.Split(delimiterChars1);					//split the string into the command & argument list
				DateTime t = DateTime.Parse(time);
				CrestronLogger.WriteToLog("Schedule_Shade_Timer: scheduling for " + t.Hour.ToString("G2") + ":" + t.Minute.ToString("G2") + "\n\r", 5);
				timer_data t_data = new timer_data(sh, act, t.Hour, t.Minute);							//allocate memory for new timer object
				Variables.timer_list.Add(t_data);											//add the current timer to the list
				CrestronLogger.WriteToLog("Schedule_Shade_Timer: Timer for shade " + sh.name +
					" scheduled for " + t.TimeOfDay + "\n\r", 5);
			}
			catch (Exception e)
			{
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Schedule_Shade_Timer: " + e + "\n\r"));
				CrestronLogger.WriteToLog("Schedule_Shade_Timer: " + e + "\n\r", 0);
			}
		}

		//****************************************************************************************
		// 
		//  Timer_Thread	-	Thread that evaluates if "when" timers have expired
		//						and performs their action
		// 
		//****************************************************************************************
		private object Timer_Thread(object unused)
		{
			DateTime t;
			int hour;
			int minute;

			CurrentThread.Priority = Thread.ThreadPriority.LowestPriority;

			//wait so the thread runs every minute on the 30 second mark
			while (DateTime.Now.Second != 30)
			{
				Thread.Sleep(500);												//sleep 1/2 second
			}

			while (true)
			{
				t = DateTime.Now;

				hour = t.Hour;
				minute = t.Minute;

				Variables.timer_list.ForEach(delegate(timer_data td)
				{
					if ((td.Get_Expiration_Hour() == hour)						//see if the hours and minutes match
						&& (td.Get_Expiration_Minute() == minute))
					{
						//this is the correct time for the timer, figure out what to do and do it
						if (td.Get_Timer_Action() == actions.schedule_open_full)
						{
							CrestronLogger.WriteToLog("\n\r\n\rTimer_Thread: Open Shade " + 
								td.Get_Timer_Shade().name + " at " + DateTime.Now + "\n\r\n\r", 5);
							td.Get_Timer_Shade().Shade_Move(actions.schedule_open_full);
						}
						else if (td.Get_Timer_Action() == actions.schedule_close_full)
						{
							CrestronLogger.WriteToLog("\n\r\n\rTimer_Thread: Close Shade " 
								+ td.Get_Timer_Shade().name + " at " + DateTime.Now + "\n\r\n\r", 5);
							td.Get_Timer_Shade().Shade_Move(actions.schedule_close_full);
						}
						else if (td.Get_Timer_Action() == actions.schedule_unlock)
						{
							CrestronLogger.WriteToLog("\n\r\n\rTimer_Thread: unlock shade movement " 
								+ td.Get_Timer_Shade().name + " at " + DateTime.Now + "\n\r\n\r", 5);
							td.Get_Timer_Shade().Shade_Move(actions.schedule_unlock);
						}
						else
						{
							CrestronLogger.WriteToLog("\n\r\n\rTimer_Thread: No-Action Window " + 
								td.Get_Timer_Shade().name + " at " + DateTime.Now + "\n\r\n\r", 5);
						}
					}
				});
				//sleep for one minute before checking timers again
				Thread.Sleep(60 * 1000);
			}
		}

		//****************************************************************************************
		// 
		//  Schedule_One_AM_Timer	-	Schedule a timer for one AM each day.  The time
		//								will schedule sunrise sunset timers each day  
		// 
		//****************************************************************************************
		private void Schedule_One_AM_Timer()
		{
			try
			{
				DateTime now = DateTime.Now;
				DateTime one_am = DateTime.Parse("1:00 AM");					//get date/time of one AM
				one_am = one_am.AddDays(1);										//make this tomorrow

				CrestronLogger.WriteToLog("One AM Timer Set For: " + one_am + "\n\r", 5);
				one_am_timer = new CTimer(One_AM_Timer_Callback, null, ((long)(one_am - now).TotalMilliseconds), day_in_milliseconds);
			}
			catch (Exception e)
			{
				CrestronLogger.WriteToLog(string.Format("Schedule_One_AM_Timer: " + e + "\n\r"), 0);
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Schedule_One_AM_Timer: " + e + "\n\r"));
			}
		}

		//****************************************************************************************
		// 
		//  One_AM_Timer_Callback	-	Executes at One AM and schedules daily sunrise/sunset timers
		// 
		//****************************************************************************************
		private void One_AM_Timer_Callback(object o)
		{
			CrestronLogger.WriteToLog("One_AM_Timer_Callback: " + DateTime.Now + "\n\r", 5);

			try
			{
				//Schedule Sunrise & Sunset Timers
				Schedule_Sunrise_Sunset_Timers(DateTime.Now, latitude, longitude);
			}
			catch (Exception e)
			{
				CrestronLogger.WriteToLog(string.Format("One_AM_Timer_Callback: " + e + "\n\r"), 0);
				Crestron.SimplSharp.ErrorLog.Error(string.Format("One_AM_Timer_Callback: " + e + "\n\r"));
			}
		}

		//****************************************************************************************
		// 
		//  Schedule_Sunrise_Sunset_Timers - Calcuate Sunrise and Sunset times and schedule timers
		// 
		//****************************************************************************************
		private void Schedule_Sunrise_Sunset_Timers(DateTime date, double latitude, double longitude)
		{
			DateTime jan_1_1900 = DateTime.Parse("1/1/1900 00:00:00");
			double julian_day, julian_century;
			double GMLS;    //Geom Mean Long Sun (deg)
			double GMAS;    //Geom Mean Anom Sun (deg)
			double EEO;     //Eccent Earth Orbit
			double SEOC;    //Sun Eq of Ctr
			double STL;     //Sun True Long (deg)
			double STA;     //Sun True Anom (deg)
			double SRV;     //Sun True Anom (deg)
			double SAL;     //Sun App Long (deg)
			double MOE;     //Mean Obliq Ecliptic (deg)
			double OC;      //Obliq Corr (deg)
			double SRA;     //Sun Rt Ascen (deg)
			double SD;      //Sun Declin (deg)
			double var_y;
			double EOT;     //Eq of Time (minutes)
			double HAS;     //HA Sunrise (deg)
			double SN;      //Solar Noon (LST)
			double Sunrise_Time;
			double Sunset_Time;
			TimeZone tz = TimeZone.CurrentTimeZone;
			DateTime Sunrise;
			DateTime Sunset;

			double hour = (double)date.Hour + ((double)date.Minute / 60) + ((double)date.Second / (60 * 60));

			//Excel says there are 2 more days between jan 1,1900 and now so we add 2 to keep the calculations the same
			julian_day = (Math.Floor((date - jan_1_1900).TotalDays) + 2) + 2415018.5 + (hour / 24)
				- ((tz.GetUtcOffset(date).TotalHours) / 24);

			julian_century = (julian_day - 2451545) / 36525;

			GMLS = (280.46646 + julian_century * (36000.76983 + julian_century * 0.0003032)) % 360;

			GMAS = 357.52911 + julian_century * (35999.05029 - 0.0001537 * julian_century);

			EEO = 0.016708634 - julian_century * (0.000042037 + 0.0000001267 * julian_century);

			SEOC = Math.Sin(GMAS * radians) * (1.914602 - julian_century * (0.004817 + 0.000014 * julian_century))
				+ Math.Sin(2 * GMAS * radians) * (0.019993 - 0.000101 * julian_century) + Math.Sin(3 * GMAS * radians) * 0.000289;

			STL = GMLS + SEOC;

			STA = GMAS + SEOC;

			SRV = (1.000001018 * (1 - EEO * EEO)) / (1 + EEO * Math.Cos(STA * radians));

			SAL = STL - 0.00569 - 0.00478 * Math.Sin((125.04 - 1934.136 * julian_century) * radians);

			MOE = 23 + (26 + ((21.448 - julian_century * (46.815 + julian_century * (0.00059 - julian_century * 0.001813)))) / 60) / 60;

			OC = MOE + 0.00256 * Math.Cos((125.04 - 1934.136 * julian_century) * radians);

			SRA = (Math.Atan2((Math.Cos(OC * radians) * Math.Sin(SAL * radians)), Math.Cos(SAL * radians))) / radians;

			SD = (Math.Asin(Math.Sin(OC * radians) * Math.Sin(SAL * radians))) / radians;

			var_y = Math.Tan((OC / 2) * radians) * Math.Tan((OC / 2) * radians);

			EOT = 4 * (var_y * Math.Sin(2 * GMLS * radians) - 2 * EEO * Math.Sin(GMAS * radians) +
				4 * EEO * var_y * Math.Sin(GMAS * radians) * Math.Cos(2 * GMLS * radians) -
				0.5 * var_y * var_y * Math.Sin(4 * GMLS * radians) - 1.25 * EEO * EEO * Math.Sin(2 * GMAS * radians)) / radians;

			HAS = (Math.Acos(Math.Cos(90.833 * radians) / (Math.Cos(latitude * radians) * Math.Cos(SD * radians))
				- Math.Tan(latitude * radians) * Math.Tan(SD * radians))) / radians;

			SN = (720 - 4 * longitude - EOT + tz.GetUtcOffset(date).TotalHours * 60) / 1440;

			Sunrise_Time = SN - HAS * 4 / 1440;
			{
				int h = (int)(Sunrise_Time * 24);
				int m = (int)(((Sunrise_Time * 24) - h) * 60);
				int s = (int)(((((Sunrise_Time * 24) - h) * 60) - m) * 60);
				Sunrise = DateTime.Parse(h + ":" + m + ":" + s);
			}

			try
			{
				DateTime now = DateTime.Now;

				if (now < Sunrise)												//validate sunrise is after current time
				{
					CrestronLogger.WriteToLog("Sunrise Timer Set: " + Sunrise + "\n\r", 5);
					if (sunset_timer == null)									//check if we have created the timer yet

						sunrise_timer = new CTimer(Sunrise_Timer_Callback, null, ((long)(Sunrise - now).TotalMilliseconds), 0);
				}
				else
				{
					CrestronLogger.WriteToLog("Too Late, Sunrise Timer Not Set: " + Sunrise + "\n\r", 5);
				}
			}
			catch (Exception e)
			{
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Initialize Sunrise Timer: " + e + "\n\r"));
				CrestronLogger.WriteToLog("Initialize Sunrise Timer: " + e + "\n\r", 0);
			}

			Sunset_Time = SN + HAS * 4 / 1440;
			{
				int h = (int)(Sunset_Time * 24);
				int m = (int)(((Sunset_Time * 24) - h) * 60);
				int s = (int)(((((Sunset_Time * 24) - h) * 60) - m) * 60);
				Sunset = DateTime.Parse(h + ":" + m + ":" + s);
			}

			try
			{
				DateTime now = DateTime.Now;

				if (now < Sunset)												//validate sunset is after current time
				{
					CrestronLogger.WriteToLog("Sunset Timer Set: " + Sunset + "\n\r", 5);
					if (sunset_timer == null)									//check if we have created the timer yet
					{
						sunset_timer = new CTimer(Sunset_Timer_Callback, null, ((long)(Sunset - now).TotalMilliseconds), 0);
					}
					else														//reuse existing timer object
					{
						sunset_timer.Reset(((long)(Sunset - now).TotalMilliseconds), 0);
					}
				}
				else
				{
					CrestronLogger.WriteToLog("Too Late, Sunset Timer Not Set: " + Sunset + "\n\r", 5);
				}
			}
			catch (Exception e)
			{
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Schedule_Sunrise_Sunset_Timers: " + e + "\n\r"));
				CrestronLogger.WriteToLog("Schedule_Sunrise_Sunset_Timers: " + e + "\n\r", 0);
			}
		}

		//****************************************************************************************
		// 
		//  Sunrise_Timer_Callback	-	Executes at Sunrise
		// 
		//****************************************************************************************
		private void Sunrise_Timer_Callback(object o)
		{
			CrestronLogger.WriteToLog("Sunrise_Timer_Callback: " + DateTime.Now + "\n\r", 5);

			try
			{
				foreach (shade sh in Variables.shade_data)						//loop through all shades
				{
					if (sh.sunrise_action == actions.sun_open_full)				//should we open the shade?
					{
						sh.Shade_Move(actions.schedule_open_full);				//open the shade
					}
					else if (sh.sunrise_action == actions.sun_close_full)		//should we close the shade?
					{
						sh.Shade_Move(actions.schedule_close_full);				//close the shade
					}
					else if (sh.sunrise_action == actions.schedule_unlock)		//should we unlock the shade and allow automated movements
					{
						sh.Shade_Move(actions.schedule_unlock);					//unlock the shade
					}
				}
			}
			catch (Exception e)
			{
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Sunrise_Timer_Callback: " + e + "\n\r"));
				CrestronLogger.WriteToLog("Sunrise_Timer_Callback: " + e + "\n\r", 0);
			}
		}

		//****************************************************************************************
		// 
		//  Sunset_Timer_Callback	-	Executes at Sunset
		// 
		//****************************************************************************************
		private void Sunset_Timer_Callback(object o)
		{
			CrestronLogger.WriteToLog("Sunset_Timer_Callback: " + DateTime.Now + "\n\r", 5);

			try
			{
				foreach (shade sh in Variables.shade_data)						//loop through all shades
				{
					if (sh.sunset_action == actions.sun_open_full)				//should we open the shade?
					{
						sh.Shade_Move(actions.schedule_open_full);				//open the shade
					}
					else if (sh.sunset_action == actions.sun_close_full)		//should we close the shade?
					{
						sh.Shade_Move(actions.schedule_close_full);				//close the shade
					}
					else if (sh.sunset_action == actions.schedule_unlock)		//should we unlock the shade and allow automated movements
					{
						sh.Shade_Move(actions.schedule_unlock);					//unlock the shade
					}
				}
			}
			catch (Exception e)
			{
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Sunset_Timer_Callback: " + e + "\n\r"));
				CrestronLogger.WriteToLog("Sunset_Timer_Callback: " + e + "\n\r", 0);
			}
		}

		//****************************************************************************************
		// 
		//  Room_Temperature_Or_Setpoint_Change	-	handler when temperature in the room changes
		// 
		//****************************************************************************************
		private void Room_Temperature_Or_Setpoint_Change(room rm)
		{
			double azimuth, elevation;
			Boolean daytime;

			//don't do anything until system is up and running
			if (System_Running == false)
			{
				return;
			}

			try
			{
				Sun_Angle_Calc(latitude, longitude, out daytime, out azimuth, out elevation);

				//loop through all shades and compare to sun angle
				if (daytime == true)											//only perform evaluation during daytime
				{
					rm.shade_list.ForEach(delegate(shade sh)
					{
						sh.group_action = actions.none;							//clear group action before evaluating what to do
						Evaluate_Shade_Action(sh, azimuth, elevation);			//decide if shade should be opened or closed
					});
					CrestronLogger.WriteToLog("Room_Temperature_Or_Setpoint_Change - Evaluating Groups\n\r", 5);//tester
					Shade_Group.evaluate_group_actions();						//perform shade movements for groups.
				}
				else
				{
					CrestronLogger.WriteToLog("Night - no angle/elevation evaluation\n\r", 5);
				}
			}
			catch (Exception e)
			{
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Room_Temperature_Or_Setpoint_Change: " + e + "\n\r"));
				CrestronLogger.WriteToLog("Room_Temperature_Or_Setpoint_Change: " + e + "\n\r", 0);
			}
		}

		//****************************************************************************************
		// 
		//  parse_commands	-	parses commands from main A/V control program for manual operation,
		//						notices of motion detector movements, etc.  Commands are in the form
		//						of "command:room name[-device name]".  ie "open:master bedroom-east shade"
		//						or "motion:great room" 
		// 
		//****************************************************************************************
		private void Parse_Commands(string cmd)
		{
			char[] delimiterChars1 = { ':' };
			char[] delimiterChars2 = { '-' };
			room rm;
			shade sh;

			try
			{
				//check if there is anything todo
				if (cmd == "")
				{
					return;
				}

				//split string into 
				string[] s = cmd.Split(delimiterChars1);					//split the string into the command & argument list
				string command = s[0].ToLower();							//assure lower case for string comparisons
				string arguments = s[1].ToLower();

				if (command == "open full")
				{
					string[] args = arguments.Split(delimiterChars2);		//split the string into room name and shade name

					rm = Find_Room(args[0]);								//find the room with the specified name

					if (rm == null)											//no such room
					{
						Crestron.SimplSharp.ErrorLog.Error("Parse_Commands: invalid room name in " + cmd + "\n\r");
						CrestronLogger.WriteToLog("Parse_Commands: invalid room name in " + cmd + "\n\r", 0);
						return;
					}
					if (args[0] == "all")
					{
						CrestronLogger.WriteToLog("Parse_Commands: Executing Command - " + cmd + "\n\r", 5);
						foreach (shade sh1 in rm.shade_list)					//loop through all the shades in the room
						{
							sh1.Shade_Move(actions.manual_open_full);
						}
					}
					else
					{
						sh = Find_Shade_In_Room(rm, args[1]);					//find the shade with the specified name in the room
						if (sh == null)											//no such shade in that room
						{
							Crestron.SimplSharp.ErrorLog.Error("Parse_Commands: invalid shade name in " + cmd + "\n\r");
							CrestronLogger.WriteToLog("Parse_Commands: invalid shade name in " + cmd + "\n\r", 0);
							return;
						}
						CrestronLogger.WriteToLog("Parse_Commands: Executing Command - " + cmd + "\n\r", 5);
						sh.Shade_Move(actions.manual_open_full);
					}
				}
				else if (command == "close full")
				{
					string[] args = arguments.Split(delimiterChars2);		//split the string into room name and shade name
					rm = Find_Room(args[0]);								//find the room with the specified name
					if (rm == null)											//no such room
					{
						Crestron.SimplSharp.ErrorLog.Error("Parse_Commands: invalid room name in " + cmd + "\n\r");
						CrestronLogger.WriteToLog("Parse_Commands: invalid room name in " + cmd + "\n\r", 0);
						return;
					}
					if (args[0] == "all")
					{
						CrestronLogger.WriteToLog("Parse_Commands: Executing Command - " + cmd + "\n\r", 5);
						foreach (shade sh1 in rm.shade_list)					//loop through all the shades in the room
						{
							sh1.Shade_Move(actions.manual_close_full);
						}
					}
					else
					{
						sh = Find_Shade_In_Room(rm, args[1]);					//find the shade with the specified name in the room
						if (sh == null)											//no such shade in that room
						{
							Crestron.SimplSharp.ErrorLog.Error("Parse_Commands: invalid shade name in " + cmd + "\n\r");
							CrestronLogger.WriteToLog("Parse_Commands: invalid shade name in " + cmd + "\n\r", 0);
							return;
						}
						CrestronLogger.WriteToLog("Parse_Commands: Executing Command - " + cmd + "\n\r", 5);
						sh.Shade_Move(actions.manual_close_full);
					}
				}
				else if (command == "open")
				{
					string[] args = arguments.Split(delimiterChars2);		//split the string into room name and shade name
					rm = Find_Room(args[0]);								//find the room with the specified name
					if (rm == null)											//no such room
					{
						Crestron.SimplSharp.ErrorLog.Error("Parse_Commands: invalid room name in " + cmd + "\n\r");
						CrestronLogger.WriteToLog("Parse_Commands: invalid room name in " + cmd + "\n\r", 0);
						return;
					}
					if (args[0] == "all")
					{
						CrestronLogger.WriteToLog("Parse_Commands: Executing Command - " + cmd + "\n\r", 5);
						foreach (shade sh1 in rm.shade_list)					//loop through all the shades in the room
						{
							sh1.Shade_Move(actions.manual_open);
						}
					}
					else
					{
						sh = Find_Shade_In_Room(rm, args[1]);					//find the shade with the specified name in the room
						if (sh == null)											//no such shade in that room
						{
							Crestron.SimplSharp.ErrorLog.Error("Parse_Commands: invalid shade name in " + cmd + "\n\r");
							CrestronLogger.WriteToLog("Parse_Commands: invalid shade name in " + cmd + "\n\r", 0);
							return;
						}
						CrestronLogger.WriteToLog("Parse_Commands: Executing Command - " + cmd + "\n\r", 5);
						sh.Shade_Move(actions.manual_open);
					}
				}
				else if (command == "close")
				{
					string[] args = arguments.Split(delimiterChars2);		//split the string into room name and shade name
					rm = Find_Room(args[0]);								//find the room with the specified name
					if (rm == null)											//no such room
					{
						Crestron.SimplSharp.ErrorLog.Error("Parse_Commands: invalid room name in " + cmd + "\n\r");
						CrestronLogger.WriteToLog("Parse_Commands: invalid room name in " + cmd + "\n\r", 0);
						return;
					}
					if (args[0] == "all")
					{
						CrestronLogger.WriteToLog("Parse_Commands: Executing Command - " + cmd + "\n\r", 5);
						foreach (shade sh1 in rm.shade_list)					//loop through all the shades in the room
						{
							sh1.Shade_Move(actions.manual_close);
						}
					}
					else
					{
						sh = Find_Shade_In_Room(rm, args[1]);					//find the shade with the specified name in the room
						if (sh == null)											//no such shade in that room
						{
							Crestron.SimplSharp.ErrorLog.Error("Parse_Commands: invalid shade name in " + cmd + "\n\r");
							CrestronLogger.WriteToLog("Parse_Commands: invalid shade name in " + cmd + "\n\r", 0);
							return;
						}
						CrestronLogger.WriteToLog("Parse_Commands: Executing Command - " + cmd + "\n\r", 5);
						sh.Shade_Move(actions.manual_close);
					}
				}
				else if (command == "stop")
				{
					string[] args = arguments.Split(delimiterChars2);		//split the string into room name and shade name
					rm = Find_Room(args[0]);								//find the room with the specified name
					if (rm == null)											//no such room
					{
						Crestron.SimplSharp.ErrorLog.Error("Parse_Commands: invalid room name in " + cmd + "\n\r");
						CrestronLogger.WriteToLog("Parse_Commands: invalid room name in " + cmd + "\n\r", 0);
						return;
					}
					if (args[0] == "all")
					{
						CrestronLogger.WriteToLog("Parse_Commands: Executing Command - " + cmd + "\n\r", 5);
						foreach (shade sh1 in rm.shade_list)					//loop through all the shades in the room
						{
							sh1.Shade_Move(actions.manual_stop);
						}
					}
					else
					{
						sh = Find_Shade_In_Room(rm, args[1]);					//find the shade with the specified name in the room
						if (sh == null)											//no such shade in that room
						{
							Crestron.SimplSharp.ErrorLog.Error("Parse_Commands: invalid shade name in " + cmd + "\n\r");
							CrestronLogger.WriteToLog("Parse_Commands: invalid shade name in " + cmd + "\n\r", 0);
							return;
						}
						CrestronLogger.WriteToLog("Parse_Commands: Executing Command - " + cmd + "\n\r", 5);
						sh.Shade_Move(actions.manual_stop);
					}
				}
				else if (command == "unlock")
				{
					string[] args = arguments.Split(delimiterChars2);		//split the string into room name and shade name
					rm = Find_Room(args[0]);								//find the room with the specified name
					if (rm == null)											//no such room
					{
						Crestron.SimplSharp.ErrorLog.Error("Parse_Commands: invalid room name in " + cmd + "\n\r");
						CrestronLogger.WriteToLog("Parse_Commands: invalid room name in " + cmd + "\n\r", 0);
						return;
					}
					if (args[0] == "all")
					{
						CrestronLogger.WriteToLog("Parse_Commands: Executing Command - " + cmd + "\n\r", 5);
						foreach (shade sh1 in rm.shade_list)					//loop through all the shades in the room
						{
							sh1.Shade_Move(actions.manual_unlock);
						}
					}
					else
					{
						sh = Find_Shade_In_Room(rm, args[1]);					//find the shade with the specified name in the room
						if (sh == null)											//no such shade in that room
						{
							Crestron.SimplSharp.ErrorLog.Error("Parse_Commands: invalid shade name in " + cmd + "\n\r");
							CrestronLogger.WriteToLog("Parse_Commands: invalid shade name in " + cmd + "\n\r", 0);
							return;
						}
						CrestronLogger.WriteToLog("Parse_Commands: Executing Command - " + cmd + "\n\r", 5);
						sh.Shade_Move(actions.manual_unlock);
					}
				}
				else if (command == "motion")
				{
					rm = Find_Room(arguments);								//find the room with the specified name
					if (rm == null)											//no such room
					{
						Crestron.SimplSharp.ErrorLog.Error("Parse_Commands: invalid room name in " + cmd + "\n\r");
						CrestronLogger.WriteToLog("Parse_Commands: invalid room name in " + cmd + "\n\r", 0);
						return;
					}
					CrestronLogger.WriteToLog("Parse_Commands: Executing Command - " + cmd + "\n\r", 5);
					rm.Motion_In_Room();										//reset manual shade timers while people are in the room
				}
				else if (command == "group open")								//opens all shades in a group
				{
					Shade_Group grp = Shade_Group.find_group(arguments);		//find a pointer to the group by name
					if (grp == null)											//check for name not matching
					{
						Crestron.SimplSharp.ErrorLog.Error("Parse_Commands: invalid group name in " + cmd + "\n\r");
						CrestronLogger.WriteToLog("Parse_Commands: invalid group name in " + cmd + "\n\r", 0);
						return;
					}
					else
					{
						grp.group_action(actions.manual_open_full);				//open all the shades in the group
					}
				}
				else if (command == "group close")								//closes all shades in a group
				{
					Shade_Group grp = Shade_Group.find_group(arguments);		//find a pointer to the group by name
					if (grp == null)											//check for name not matching
					{
						Crestron.SimplSharp.ErrorLog.Error("Parse_Commands: invalid group name in " + cmd + "\n\r");
						CrestronLogger.WriteToLog("Parse_Commands: invalid group name in " + cmd + "\n\r", 0);
						return;
					}
					else
					{
						grp.group_action(actions.manual_close_full);			//unlocks all the shades in the group
					}
				}
				else if (command == "group unlock")								//closes all shades in a group
				{
					Shade_Group grp = Shade_Group.find_group(arguments);		//find a pointer to the group by name
					if (grp == null)											//check for name not matching
					{
						Crestron.SimplSharp.ErrorLog.Error("Parse_Commands: invalid group name in " + cmd + "\n\r");
						CrestronLogger.WriteToLog("Parse_Commands: invalid group name in " + cmd + "\n\r", 0);
						return;
					}
					else
					{
						grp.group_action(actions.manual_unlock);				//close all the shades in the group
					}
				}
				else															//invalid command
				{
					Crestron.SimplSharp.ErrorLog.Error(string.Format("Parse_Commands: invalid command in " + cmd + "\n\r"));
					CrestronLogger.WriteToLog("Parse_Commands: invalid command in " + cmd + "\n\r", 5);
				}
			}
			catch (Exception e)
			{
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Parse_Commands: " + e + "\n\r"));
				CrestronLogger.WriteToLog("Parse_Commands: " + e + "\n\r", 0);
			}
		}

		//****************************************************************************************
		// 
		//  Find_Room	-	finds a room with the specified name and returns a pointer to it
		// 
		//****************************************************************************************
		private room Find_Room(string name)
		{
			SimplSharpString s;

			foreach (room rm in Variables.room_data)							//loop through all the rooms to find the right one
			{
				s = rm.name.ToLower();											//convert to lower case for comparison

				if (s.ToString() == name)										//see if this is the room that matches the name we are looking for
				{
					return rm;													//pass back the room
				}
			}
			return null;														//couldn't find it - return null
		}

		//****************************************************************************************
		// 
		//  Find_Shade_In_Room	-	finds a shade with the specified name in a room 
		//							and returns a pointer to it
		// 
		//****************************************************************************************
		private shade Find_Shade_In_Room(room rm, string name)
		{
			SimplSharpString s;

			foreach (shade sh in rm.shade_list)									//loop through all the shades in the room to find the right one
			{
				s = sh.name.ToLower();											//convert to lower case for comparison

				if (s.ToString() == name)										//see if this is the shade that matches the name we are looking for
				{
					return sh;													//pass back the shade
				}
			}
			return null;														//couldn't find it - return null
		}

		//****************************************************************************************
		// 
		//  close_shades_when_away	-	close all the shades in rooms marked for shades to
		//								be closed when away
		// 
		//****************************************************************************************
		private void close_shades_when_away()
		{
			foreach (room rm in Variables.room_data)							//loop through all the rooms
			{
				if (rm.close_when_away == true)									//if room set for shades to be closed when away
				{
					foreach (shade sh in rm.shade_list)							//loop through all the shades in the room
					{
						sh.Shade_Move(actions.away_close);						//force each shade closed
					}
				}
			}
		}
		//****************************************************************************************
		// 
		//  find_gateway	-	find ex gateway by name
		// 
		//****************************************************************************************
		private gateway find_gateway(string name)
		{
			SimplSharpString s;

			foreach (gateway gw in Variables.gateway_data)						//loop through all the gateways to find the right one
			{
				s = gw.name.ToLower();											//convert to lower case for comparison

				if (s.ToString() == name)										//see if this is the room that matches the name we are looking for
				{
					return gw;													//pass back the gatway
				}
			}
			return null;														//couldn't find it - return null
		}
		#endregion
	}
}